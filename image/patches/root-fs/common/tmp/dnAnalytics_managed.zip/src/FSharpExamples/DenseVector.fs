﻿#light

open dnAnalytics.LinearAlgebra

/// Create a new 100 dimensional dence vector.
let v = DenseVector.init 100 (fun i -> float i / 100.0)

/// Perform some unary arithmetic on the vector.
let w = 4.0 * (Vector.map (fun x -> x ** 2.0) v)

/// Perform some binary arithmetic on vectors.
let x = v + w