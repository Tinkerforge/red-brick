#ifndef COMPLEX_FUNCTIONS_H	

#include "mkl_types.h"
#include <ipp.h>
#ifdef __cplusplus
extern "C" {
#endif	
	
	//double z_abs(Ipp64fc z);
	Ipp64fc z_acos(Ipp64fc z);
	Ipp64fc z_acosh(Ipp64fc z);
	//double z_arg(Ipp64fc z);
	Ipp64fc z_asin(Ipp64fc z);
	Ipp64fc z_asinh(Ipp64fc z);
	Ipp64fc z_atan(Ipp64fc z);
	Ipp64fc z_atanh(Ipp64fc z);
	Ipp64fc z_cos(Ipp64fc z);
	Ipp64fc z_cosh(Ipp64fc z);
	Ipp64fc z_sin(Ipp64fc z);
	Ipp64fc z_sinh(Ipp64fc z);
	Ipp64fc z_tan(Ipp64fc z);
	Ipp64fc z_tanh(Ipp64fc z);
	Ipp64fc z_log(Ipp64fc z);
	Ipp64fc z_exp(Ipp64fc z);
	Ipp64fc z_pow(Ipp64fc x, Ipp64fc y);
	Ipp64fc z_sqrt(Ipp64fc z);

	//float c_abs(Ipp32fc z);
	Ipp32fc c_acos(Ipp32fc z);
	Ipp32fc c_acosh(Ipp32fc z);
	//float c_arg(Ipp32fc z);
	Ipp32fc c_asin(Ipp32fc z);
	Ipp32fc c_asinh(Ipp32fc z);
	Ipp32fc c_atan(Ipp32fc z);
	Ipp32fc c_atanh(Ipp32fc z);
	Ipp32fc c_cos(Ipp32fc z);
	Ipp32fc c_cosh(Ipp32fc z);
	Ipp32fc c_sin(Ipp32fc z);
	Ipp32fc c_sinh(Ipp32fc z);
	Ipp32fc c_tan(Ipp32fc z);
	Ipp32fc c_tanh(Ipp32fc z);
	Ipp32fc c_log(Ipp32fc z);
	Ipp32fc c_exp(Ipp32fc z);
	Ipp32fc c_pow(Ipp32fc x, Ipp32fc y);
	Ipp32fc c_sqrt(Ipp32fc z);

#ifdef __cplusplus
}
#endif

#define COMPLEX_FUNCTIONS_H

#endif