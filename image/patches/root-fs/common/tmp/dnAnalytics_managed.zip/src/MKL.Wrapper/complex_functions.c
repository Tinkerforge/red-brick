#include "complex_functions.h"

Ipp64fc z_acos(Ipp64fc z){
	Ipp64fc ret;
	ippsAcos_64fc_A53(&z, &ret, 1);
	return ret;
}

Ipp64fc z_acosh(Ipp64fc z){
	Ipp64fc ret;
	ippsAcosh_64fc_A53(&z, &ret, 1);
	return ret;
}

Ipp64fc z_asin(Ipp64fc z){
	Ipp64fc ret;
	ippsAsin_64fc_A53(&z, &ret, 1);
	return ret;
}

Ipp64fc z_asinh(Ipp64fc z){
	Ipp64fc ret;
	ippsAsinh_64fc_A53(&z, &ret, 1);
	return ret;
}

Ipp64fc z_atan(Ipp64fc z){
	Ipp64fc ret;
	ippsAtan_64fc_A53(&z, &ret, 1);
	return ret;
}

Ipp64fc z_atanh(Ipp64fc z){
	Ipp64fc ret;
	ippsAtanh_64fc_A53(&z, &ret, 1);
	return ret;
}

Ipp64fc z_cos(Ipp64fc z){
	Ipp64fc ret;
	ippsCos_64fc_A53(&z, &ret, 1);
	return ret;
}

Ipp64fc z_cosh(Ipp64fc z){
	Ipp64fc ret;
	ippsCosh_64fc_A53(&z, &ret, 1);
	return ret;
}

Ipp64fc z_sin(Ipp64fc z){
	Ipp64fc ret;
	ippsSin_64fc_A53(&z, &ret, 1);
	return ret;
}

Ipp64fc z_sinh(Ipp64fc z){
	Ipp64fc ret;
	ippsSinh_64fc_A53(&z, &ret, 1);
	return ret;
}

Ipp64fc z_tan(Ipp64fc z){
	Ipp64fc ret;
	ippsTan_64fc_A53(&z, &ret, 1);
	return ret;
}

Ipp64fc z_tanh(Ipp64fc z){
	Ipp64fc ret;
	ippsTanh_64fc_A53(&z, &ret, 1);
	return ret;
}

Ipp64fc z_log(Ipp64fc z){
	Ipp64fc ret;
	ippsLn_64fc_A53(&z, &ret, 1);
	return ret;
}

Ipp64fc z_exp(Ipp64fc z){
	Ipp64fc ret;
	ippsExp_64fc_A53(&z, &ret, 1);
	return ret;
}

Ipp64fc z_pow(Ipp64fc x, Ipp64fc y){
	Ipp64fc ret;
	ippsPow_64fc_A53(&x, &y, &ret, 1);
	return ret;
}

Ipp64fc z_sqrt(Ipp64fc z){
	Ipp64fc ret;
	ippsSqrt_64fc_A53(&z, &ret, 1);
	return ret;
}

Ipp32fc c_acos(Ipp32fc z){
	Ipp32fc ret;
	ippsAcos_32fc_A24(&z, &ret, 1);
	return ret;
}

Ipp32fc c_acosh(Ipp32fc z){
	Ipp32fc ret;
	ippsAcosh_32fc_A24(&z, &ret, 1);
	return ret;
}

Ipp32fc c_asin(Ipp32fc z){
	Ipp32fc ret;
	ippsAsin_32fc_A24(&z, &ret, 1);
	return ret;
}

Ipp32fc c_asinh(Ipp32fc z){
	Ipp32fc ret;
	ippsAsinh_32fc_A24(&z, &ret, 1);
	return ret;
}

Ipp32fc c_atan(Ipp32fc z){
	Ipp32fc ret;
	ippsAtan_32fc_A24(&z, &ret, 1);
	return ret;
}

Ipp32fc c_atanh(Ipp32fc z){
	Ipp32fc ret;
	ippsAtanh_32fc_A24(&z, &ret, 1);
	return ret;
}

Ipp32fc c_cos(Ipp32fc z){
	Ipp32fc ret;
	ippsCos_32fc_A24(&z, &ret, 1);
	return ret;
}

Ipp32fc c_cosh(Ipp32fc z){
	Ipp32fc ret;
	ippsCosh_32fc_A24(&z, &ret, 1);
	return ret;
}

Ipp32fc c_sin(Ipp32fc z){
	Ipp32fc ret;
	ippsSin_32fc_A24(&z, &ret, 1);
	return ret;
}

Ipp32fc c_sinh(Ipp32fc z){
	Ipp32fc ret;
	ippsSinh_32fc_A24(&z, &ret, 1);
	return ret;
}

Ipp32fc c_tan(Ipp32fc z){
	Ipp32fc ret;
	ippsTan_32fc_A24(&z, &ret, 1);
	return ret;
}

Ipp32fc c_tanh(Ipp32fc z){
	Ipp32fc ret;
	ippsTanh_32fc_A24(&z, &ret, 1);
	return ret;
}

Ipp32fc c_log(Ipp32fc z){
	Ipp32fc ret;
	ippsLn_32fc_A24(&z, &ret, 1);
	return ret;
}

Ipp32fc c_exp(Ipp32fc z){
	Ipp32fc ret;
	ippsExp_32fc_A24(&z, &ret, 1);
	return ret;
}

Ipp32fc c_pow(Ipp32fc x, Ipp32fc y){
	Ipp32fc ret;
	ippsPow_32fc_A24(&x, &y, &ret, 1);
	return ret;
}

Ipp32fc c_sqrt(Ipp32fc z){
	Ipp32fc ret;
	ippsSqrt_32fc_A24(&z, &ret, 1);
	return ret;
}