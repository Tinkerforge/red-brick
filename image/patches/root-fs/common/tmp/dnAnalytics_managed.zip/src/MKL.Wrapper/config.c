#include "mkl.h"

void SetNumberThreads(int threads)
{
	mkl_set_num_threads(threads);
}


