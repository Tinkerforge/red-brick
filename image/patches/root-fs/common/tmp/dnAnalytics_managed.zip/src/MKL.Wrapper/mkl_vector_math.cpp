#include "mkl_vml.h"

#ifdef __cplusplus
extern "C" {
#endif	

	void d_vector_sqrt(const int n, const double data[], double result[]){
		vdsqrt(&n, data, result);
	}

	void d_vector_invert(const int n, const double data[], double result[]){
		vdinv(&n, data, result);
	}

	void d_vector_abs(const int n, const double data[], double result[]){
		vdabs(&n, data, result);
	}

	void d_vector_exp(const int n, const double data[], double result[]){
		vdexp(&n, data, result);
	}

	void d_vector_ln(const int n, const double data[], double result[]){
		vdln(&n, data, result);
	}

	void d_vector_log10(const int n, const double data[], double result[]){
		vdlog10(&n, data, result);
	}

	void d_vector_sin(const int n, const double data[], double result[]){
		vdsin(&n, data, result);
	}

	void d_vector_cos(const int n, const double data[], double result[]){
		vdcos(&n, data, result);
	}

	void d_vector_tan(const int n, const double data[], double result[]){
		vdtan(&n, data, result);
	}

	void d_vector_asin(const int n, const double data[], double result[]){
		vdasin(&n, data, result);
	}

	void d_vector_acos(const int n, const double data[], double result[]){
		vdacos(&n, data, result);
	}

	void d_vector_atan(const int n, const double data[], double result[]){
		vdatan(&n, data, result);
	}

	void d_vector_sinh(const int n, const double data[], double result[]){
		vdsinh(&n, data, result);
	}

	void d_vector_cosh(const int n, const double data[], double result[]){
		vdcosh(&n, data, result);
	}

	void d_vector_tanh(const int n, const double data[], double result[]){
		vdtanh(&n, data, result);
	}

	void d_vector_erf(const int n, const double data[], double result[]){
		vderf(&n, data, result);
	}

	void d_vector_erfc(const int n, const double data[], double result[]){
		vderfc(&n, data, result);
	}

	void d_vector_erfinv(const int n, const double data[], double result[]){
		vderfinv(&n, data, result);
	}

	void d_vector_erfcinv(const int n, const double data[], double result[]){
		vderfcinv(&n, data, result);
	}

	void d_vector_powx(const int n, const double data[], const double x, double result[]){
		vdpowx(&n, data, &x, result);
	}

#ifdef __cplusplus
}
#endif	