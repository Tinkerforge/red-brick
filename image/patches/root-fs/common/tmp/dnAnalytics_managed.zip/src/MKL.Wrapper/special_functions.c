//#include <mathimf.h>
#include <ipp.h>

#ifdef __cplusplus
extern "C" {
#endif	
double native_erf(double x){
	Ipp64f ret;
	ippsErf_64f_A53(&x, &ret,1);
	return ret;
}

double native_erfc(double x){
	Ipp64f ret;
	ippsErfc_64f_A53(&x, &ret,1);
	return ret;
}

double native_erfinv(double x){
	Ipp64f ret;
	ippsErfInv_64f_A53(&x, &ret,1);
	return ret;
}
#ifdef __cplusplus
}
#endif	



