(* Copyright 2007 dnAnalytics Project.
 *
 * Contributors to this file:
 * Jurgen Van Gael
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this 
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * * Neither the name of the dnAnalytics Project nor the names of its contributors
 *   may be used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *)
#light

namespace dnAnalytics.LinearAlgebra

open dnAnalytics.LinearAlgebra

/// A module which implements functional dense vector operations.
module DenseVector =

    /// Initialize a vector by calling a construction function for every element.
    /// <include file='../../../../FSharpExamples/DenseVector.xml' path='example'/> 
    let inline init (n: int) f =
        let v = new DenseVector(n)
        for i=0 to n-1 do
            v.[i] <- f i
        v
    
    /// Create a vector from a float list.
    let inline of_list (fl: float list) =
        let n = List.length fl
        let v = DenseVector(n)
        fl |> List.iteri (fun i f -> v.[i] <- f)
        v
    
    /// Create a vector from a sequences.
    let inline of_seq (fs: #seq<float>) =
        let n = Seq.length fs
        let v = DenseVector(n)
        fs |> Seq.iteri (fun i f -> v.[i] <- f)
        v
    
    /// Create a vector with evenly spaced entries: e.g. rangef -1.0 0.5 1.0 = [-1.0 -0.5 0.0 0.5 1.0]
    let inline rangef (start: float) (step: float) (stop: float) =
        let n = (int ((stop - start) / step)) + 1
        let v = new DenseVector(n)
        for i=0 to n-1 do
            v.[i] <- (float i) * step + start
        v
    
    /// Create a vector with integer entries in the given range.
    let inline range (start: int) (stop: int) =
        new DenseVector([| for i in [start .. stop] -> float i |])