﻿using dnAnalytics.LinearAlgebra;
using dnAnalytics.LinearAlgebra.IO;
using NUnit.Framework;

namespace dnAnalytics.Tests.LinearAlgebra.Decomposition
{
    [TestFixture]
    public class DenseHouseholderTests : HouseholderTests
    {
        protected override Matrix GetMatrix(string file)
        {
            MatrixMarketReader mmr = new MatrixMarketReader();
            return mmr.ReadMatrix(file, StorageType.Dense);
        }
        protected override Matrix GetMatrix(int rows, int cols)
        {
            return new DenseMatrix(rows, cols);
        }

        protected override Vector GetVector(int count)
        {
            return new DenseVector(count);
        }

        [Test]
        public void SolveBase_SquareMatrix()
        {
            Matrix squareMatrix = GetMatrix("./TestData/Matrices/random_real_general_array_100.mtx");
            Matrix identity =new BaseMatrix(squareMatrix.Rows, squareMatrix.Rows);
            for (int i = 0; i < identity.Rows; i++)
            {
                identity[i, i] = 1.0;
            }

            dnAnalytics.LinearAlgebra.Decomposition.Householder qr = new dnAnalytics.LinearAlgebra.Decomposition.Householder(squareMatrix);
            Matrix result = qr.Solve(identity);

            result = squareMatrix * result;

            for (int i = 0; i < result.Rows; i++)
            {
                for (int j = 0; j < result.Columns; j++)
                {
                    if (i == j)
                    {
                        Assert.AreEqual(1, result[i, j], Constants.AcceptableError);
                    }
                    else
                    {
                        Assert.AreEqual(0, result[i, j], Constants.AcceptableError);
                    }
                }
            }
        }
    }
}
