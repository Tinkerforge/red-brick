using dnAnalytics.Statistics.Distributions;
using NUnit.Framework;

namespace dnAnalytics.Tests.Statistics.Distributions
{
    [TestFixture]
    public class BernoulliTests
    {
        private const double mAcceptableError = 1e-12;

        [Test]
        public void Bernoulli()
        {
            Bernoulli bernoulli = new Bernoulli(0.3);

            Assert.AreEqual(0.3, bernoulli.Mean, mAcceptableError);
            Assert.AreEqual(0.45825756949558, bernoulli.StdDev, mAcceptableError);
            Assert.AreEqual(0.21, bernoulli.Variance, mAcceptableError);

            Assert.AreEqual(0.7, bernoulli.Probability(0), mAcceptableError);
            Assert.AreEqual(0.3, bernoulli.Probability(1), mAcceptableError);

            Assert.AreEqual(0.7, bernoulli.CumulativeDistribution(0), mAcceptableError);
            Assert.AreEqual(1.0, bernoulli.CumulativeDistribution(1), mAcceptableError);
        }

        [Test]
        public void GetSetRNG()
        {
            Bernoulli bernoulli = new Bernoulli(0.3);

            // Try getting the random number generator.
            System.Random rnd = bernoulli.RandomNumberGenerator;
            // Try setting the random number generator.
            bernoulli.RandomNumberGenerator = new System.Random();
        }
    }
}