﻿using dnAnalytics.Random;
using NUnit.Framework;

namespace dnAnalytics.Tests.Random
{
    [TestFixture]
    public class Mcg31m1Tests : RandomTests
    {
        public Mcg31m1Tests() : base(typeof(Mcg31m1)){}
    }
}
