using dnAnalytics.Math;
using NUnit.Framework;

namespace dnAnalytics.Tests.Math
{
    [TestFixture]
    public class ComplexMath_ExpTest
    {
        [Test]
        public void Exp()
        {
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(0.0, 1.19209289550780998537e-7)), new Complex(9.99999999999992894573e-1, 1.19209289550780716193e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(0.0, -1.19209289550780998537e-7)), new Complex(9.99999999999992894573e-1, -1.19209289550780716193e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(0.0, 5.0e-1)), new Complex(8.77582561890372716116e-1, 4.79425538604203000273e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(0.0, -5.0e-1)), new Complex(8.77582561890372716116e-1, -4.79425538604203000273e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(0.0, 1.0)), new Complex(5.40302305868139717401e-1, 8.41470984807896506653e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(0.0, -1.0)), new Complex(5.40302305868139717401e-1, -8.41470984807896506653e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(0.0, 2.0)), new Complex(-4.16146836547142386998e-1, 9.09297426825681695396e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(0.0, -2.0)), new Complex(-4.16146836547142386998e-1, -9.09297426825681695396e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(0.0, 8.388608e6)), new Complex(-9.01754673758759322321e-1, 4.32248202256797756659e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(0.0, -8.388608e6)), new Complex(-9.01754673758759322321e-1, -4.32248202256797756659e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.19209289550780998537e-7, 0.0)), new Complex(1.00000011920929665621, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.19209289550780998537e-7, 0.0)), new Complex(9.99999880790717554646e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.19209289550780998537e-7, 1.19209289550780998537e-7)), new Complex(1.00000011920928955078, 1.19209303761636278428e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.19209289550780998537e-7, -1.19209289550780998537e-7)), new Complex(1.00000011920928955078, -1.19209303761636278428e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.19209289550780998537e-7, 1.19209289550780998537e-7)), new Complex(9.9999988079071044922e-1, 1.19209275339926848024e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.19209289550780998537e-7, -1.19209289550780998537e-7)), new Complex(9.9999988079071044922e-1, -1.19209275339926848024e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.19209289550780998537e-7, 5.0e-1)), new Complex(8.77582666506372676821e-1, 4.79425595756184256304e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.19209289550780998537e-7, -5.0e-1)), new Complex(8.77582666506372676821e-1, -4.79425595756184256304e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.19209289550780998537e-7, 5.0e-1)), new Complex(8.7758245727438522661e-1, 4.79425481452228557289e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.19209289550780998537e-7, -5.0e-1)), new Complex(8.7758245727438522661e-1, -4.79425481452228557289e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.19209289550780998537e-7, 1.0)), new Complex(5.4030237027719758167e-1, 8.41471085119060762209e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.19209289550780998537e-7, -1.0)), new Complex(5.4030237027719758167e-1, -8.41471085119060762209e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.19209289550780998537e-7, 1.0)), new Complex(5.4030224145908953129e-1, 8.41470884496744209118e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.19209289550780998537e-7, -1.0)), new Complex(5.4030224145908953129e-1, -8.41470884496744209118e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.19209289550780998537e-7, 2.0)), new Complex(-4.16146886155714077489e-1, 9.09297535222388398586e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.19209289550780998537e-7, -2.0)), new Complex(-4.16146886155714077489e-1, -9.09297535222388398586e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.19209289550780998537e-7, 2.0)), new Complex(-4.16146786938576610309e-1, 9.092973184289879141e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.19209289550780998537e-7, -2.0)), new Complex(-4.16146786938576610309e-1, -9.092973184289879141e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.19209289550780998537e-7, 8.388608e6)), new Complex(-9.01754781256299737552e-1, 4.32248253784801928603e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.19209289550780998537e-7, -8.388608e6)), new Complex(-9.01754781256299737552e-1, -4.32248253784801928603e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.19209289550780998537e-7, 8.388608e6)), new Complex(-9.01754566261231721795e-1, 4.32248150728799727332e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.19209289550780998537e-7, -8.388608e6)), new Complex(-9.01754566261231721795e-1, -4.32248150728799727332e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(5.0e-1, 0.0)), new Complex(1.64872127070012814685, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-5.0e-1, 0.0)), new Complex(6.06530659712633423604e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(5.0e-1, 1.19209289550780998537e-7)), new Complex(1.64872127070011643198, 1.96542891347422690873e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(5.0e-1, -1.19209289550780998537e-7)), new Complex(1.64872127070011643198, -1.96542891347422690873e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-5.0e-1, 1.19209289550780998537e-7)), new Complex(6.06530659712629113944e-1, 7.23040890351093658948e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-5.0e-1, -1.19209289550780998537e-7)), new Complex(6.06530659712629113944e-1, -7.23040890351093658948e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(5.0e-1, 5.0e-1)), new Complex(1.44688903658416915805, 7.90439083213614911843e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(5.0e-1, -5.0e-1)), new Complex(1.44688903658416915805, -7.90439083213614911843e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-5.0e-1, 5.0e-1)), new Complex(5.32280730215670714837e-1, 2.90786288212691848864e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-5.0e-1, -5.0e-1)), new Complex(5.32280730215670714837e-1, -2.90786288212691848864e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(5.0e-1, 1.0)), new Complex(8.90807904293128619556e-1, 1.3873511113297633557), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(5.0e-1, -1.0)), new Complex(8.90807904293128619556e-1, -1.3873511113297633557), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-5.0e-1, 1.0)), new Complex(3.27709914022459831911e-1, 5.10377951544572805351e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-5.0e-1, -1.0)), new Complex(3.27709914022459831911e-1, -5.10377951544572805351e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(5.0e-1, 2.0)), new Complex(-6.8611014114984312465e-1, 1.49917800900039471583), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(5.0e-1, -2.0)), new Complex(-6.8611014114984312465e-1, -1.49917800900039471583), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-5.0e-1, 2.0)), new Complex(-2.52405815308263701403e-1, 5.51516768167580735186e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-5.0e-1, -2.0)), new Complex(-2.52405815308263701403e-1, -5.51516768167580735186e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(5.0e-1, 8.388608e6)), new Complex(-1.48674211157932117217, 7.12656805282673596317e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(5.0e-1, -8.388608e6)), new Complex(-1.48674211157932117217, -7.12656805282673596317e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-5.0e-1, 8.388608e6)), new Complex(-5.46941857173850819201e-1, 2.62171787274415346797e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-5.0e-1, -8.388608e6)), new Complex(-5.46941857173850819201e-1, -2.62171787274415346797e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.0, 0.0)), new Complex(2.71828182845904523536, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.0, 0.0)), new Complex(3.67879441171442321596e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.0, 1.19209289550780998537e-7)), new Complex(2.71828182845902592081, 3.24044445569399960419e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.0, -1.19209289550780998537e-7)), new Complex(2.71828182845902592081, -3.24044445569399960419e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.0, 1.19209289550780998537e-7)), new Complex(3.67879441171439707655e-1, 4.38546468223858683429e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.0, -1.19209289550780998537e-7)), new Complex(3.67879441171439707655e-1, -4.38546468223858683429e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.0, 5.0e-1)), new Complex(2.38551673095913557604, 1.30321372968699550927), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.0, -5.0e-1)), new Complex(2.38551673095913557604, -1.30321372968699550927), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.0, 5.0e-1)), new Complex(3.22844582450033009889e-1, 1.76370799225031947362e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.0, -5.0e-1)), new Complex(3.22844582450033009889e-1, -1.76370799225031947362e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.0, 1.0)), new Complex(1.46869393991588515714, 2.28735528717884239121), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.0, -1.0)), new Complex(1.46869393991588515714, -2.28735528717884239121), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.0, 1.0)), new Complex(1.98766110346412940629e-1, 3.09559875653112198444e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.0, -1.0)), new Complex(1.98766110346412940629e-1, -3.09559875653112198444e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.0, 2.0)), new Complex(-1.13120438375681363843, 2.47172667200481892762), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.0, -2.0)), new Complex(-1.13120438375681363843, -2.47172667200481892762), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.0, 2.0)), new Complex(-1.53091865674226291258e-1, 3.34511829239262248422e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.0, -2.0)), new Complex(-1.53091865674226291258e-1, -3.34511829239262248422e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.0, 8.388608e6)), new Complex(-2.45122334340645010814, 1.17497243357874340914), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(1.0, -8.388608e6)), new Complex(-2.45122334340645010814, -1.17497243357874340914), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.0, 8.388608e6)), new Complex(-3.31737005456108663128e-1, 1.5901522709359133247e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-1.0, -8.388608e6)), new Complex(-3.31737005456108663128e-1, -1.5901522709359133247e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(2.0, 0.0)), new Complex(7.38905609893065022723, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-2.0, 0.0)), new Complex(1.35335283236612691894e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(2.0, 1.19209289550780998537e-7)), new Complex(7.38905609893059772483, 8.80844128004386084053e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(2.0, -1.19209289550780998537e-7)), new Complex(7.38905609893059772483, -8.80844128004386084053e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-2.0, 1.19209289550780998537e-7)), new Complex(1.35335283236611730279e-1, 1.61332229657902819963e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-2.0, -1.19209289550780998537e-7)), new Complex(1.35335283236611730279e-1, -1.61332229657902819963e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(2.0, 5.0e-1)), new Complex(6.48450678125124333615, 3.54250220000649807404), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(2.0, -5.0e-1)), new Complex(6.48450678125124333615, -3.54250220000649807404), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-2.0, 5.0e-1)), new Complex(1.18767884576945778839e-1, 6.48831910578654052833e-2), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-2.0, -5.0e-1)), new Complex(1.18767884576945778839e-1, -6.48831910578654052833e-2), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(2.0, 1.0)), new Complex(3.99232404844127142651, 6.21767631236796820425), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(2.0, -1.0)), new Complex(3.99232404844127142651, -6.21767631236796820425), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-2.0, 1.0)), new Complex(7.3121965598059632366e-2, 1.13880714064368089229e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-2.0, -1.0)), new Complex(7.3121965598059632366e-2, -1.13880714064368089229e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(2.0, 2.0)), new Complex(-3.07493232063935886711, 6.71884969742824997127), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(2.0, -2.0)), new Complex(-3.07493232063935886711, -6.71884969742824997127), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-2.0, 2.0)), new Complex(-5.63193499921278810042e-2, 1.23060024805776735808e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-2.0, -2.0)), new Complex(-5.63193499921278810042e-2, -1.23060024805776735808e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(2.0, 8.388608e6)), new Complex(-6.66311587187637934355, 3.19390621513740071345), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(2.0, -8.388608e6)), new Complex(-6.66311587187637934355, -3.19390621513740071345), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-2.0, 8.388608e6)), new Complex(-1.22039224183080967401e-1, 5.84984328809403737736e-2), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-2.0, -8.388608e6)), new Complex(-1.22039224183080967401e-1, -5.84984328809403737736e-2), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-8.388608e6, 0.0)), new Complex(6.83518898007422449157e-3643127, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-8.388608e6, 1.19209289550780998537e-7)), new Complex(6.83518898007417592464e-3643127, 8.14818022259973750625e-3643134), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-8.388608e6, -1.19209289550780998537e-7)), new Complex(6.83518898007417592464e-3643127, -8.14818022259973750625e-3643134), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-8.388608e6, 5.0e-1)), new Complex(5.99844265613838167676e-3643127, 3.276964158233598046e-3643127), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-8.388608e6, -5.0e-1)), new Complex(5.99844265613838167676e-3643127, -3.276964158233598046e-3643127), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-8.388608e6, 1.0)), new Complex(3.69306836697860159343e-3643127, 5.75161320241113937527e-3643127), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-8.388608e6, -1.0)), new Complex(3.69306836697860159343e-3643127, -5.75161320241113937527e-3643127), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-8.388608e6, 2.0)), new Complex(-2.84444227125977718146e-3643127, 6.21521975144874804455e-3643127), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-8.388608e6, -2.0)), new Complex(-2.84444227125977718146e-3643127, -6.21521975144874804455e-3643127), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-8.388608e6, 8.388608e6)), new Complex(-6.16366360880629918059e-3643127, 2.95449814872255855945e-3643127), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex(-8.388608e6, -8.388608e6)), new Complex(-6.16366360880629918059e-3643127, -2.95449814872255855945e-3643127), 13);
        }
    }
}