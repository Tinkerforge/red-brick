using dnAnalytics.Statistics.Distributions;
using NUnit.Framework;

namespace dnAnalytics.Tests.Statistics.Distributions
{
    [TestFixture]
    public class ContinuousUniformTests
    {
        private const double mAcceptableError = 1e-12;

        [Test]
        public void ContinuousUniform()
        {
            ContinuousUniform cu = new ContinuousUniform(2.0, 5.0);

            Assert.AreEqual((5.0 + 2.0) / 2.0, cu.Mean, mAcceptableError);
            Assert.AreEqual((5.0 - 2.0) / System.Math.Sqrt(12.0), cu.StdDev, mAcceptableError);
            Assert.AreEqual((5.0 - 2.0) * (5.0 - 2.0)/12.0, cu.Variance, mAcceptableError);

            Assert.AreEqual(1.0 / 3.0, cu.Density(3.0), mAcceptableError);
        }

        [Test]
        public void GetSetRNG()
        {
            ContinuousUniform cu = new ContinuousUniform(2.0, 5.0);

            // Try getting the random number generator.
            System.Random rnd = cu.RandomNumberGenerator;
            // Try setting the random number generator.
            cu.RandomNumberGenerator = new System.Random();
        }
    }
}