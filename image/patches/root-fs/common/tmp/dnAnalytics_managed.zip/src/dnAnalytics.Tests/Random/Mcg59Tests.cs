﻿using dnAnalytics.Random;
using NUnit.Framework;

namespace dnAnalytics.Tests.Random
{
    [TestFixture]
    public class Mcg59Tests : RandomTests
    {
        public Mcg59Tests() : base(typeof(Mcg59)) { }
    }
}
