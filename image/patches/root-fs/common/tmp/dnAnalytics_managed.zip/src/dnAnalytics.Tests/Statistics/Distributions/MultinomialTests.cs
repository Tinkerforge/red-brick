using dnAnalytics.Statistics;
using dnAnalytics.Statistics.Distributions;
using NUnit.Framework;

namespace dnAnalytics.Tests.Statistics.Distributions
{
    [TestFixture]
    public class MultinomialTests
    {
        private const double mAcceptableError = 1e-12;

        [Test]
        public void MultinomialFromProbabilities()
        {
            Multinomial m = new Multinomial(new double[] {0.2, 0.2, 0.4, 0.2});

            Assert.AreEqual(m.P(true)[0], 0.2, mAcceptableError);
            Assert.AreEqual(m.P(true)[2], 0.4, mAcceptableError);
        }

        [Test]
        public void MultinomialFromRatios()
        {
            Multinomial m = new Multinomial(new double[] { 2.0, 2.0, 4.0, 2.0 });

            Assert.AreEqual(m.P(true)[0], 0.2, mAcceptableError);
            Assert.AreEqual(m.P(true)[2], 0.4, mAcceptableError);
        }

        [Test]
        public void MultinomialFromHistogram()
        {
            Multinomial m = new Multinomial(new Histogram(new double[] {0.2, 0.2, 0.4, 0.2}, 2, 0.0, 0.5));

            Assert.AreEqual(m.P(true)[0], 0.75, mAcceptableError);
            Assert.AreEqual(m.P(true)[1], 0.25, mAcceptableError);
        }

        [Test]
        public void GetSetRNG()
        {
            Multinomial m = new Multinomial(new double[] { 0.2, 0.2, 0.4, 0.2 });

            // Try getting the random number generator.
            System.Random rnd = m.RandomNumberGenerator;
            // Try setting the random number generator.
            m.RandomNumberGenerator = new System.Random();
        }
    }
}