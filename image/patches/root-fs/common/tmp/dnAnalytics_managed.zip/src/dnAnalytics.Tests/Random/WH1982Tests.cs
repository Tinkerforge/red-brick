﻿using dnAnalytics.Random;
using NUnit.Framework;

namespace dnAnalytics.Tests.Random
{
    [TestFixture]
    public class WH1982Tests : RandomTests
    {
        public WH1982Tests()
            : base(typeof (WH1982))
        {
        }
    }
}