﻿using dnAnalytics.LinearAlgebra;
using dnAnalytics.LinearAlgebra.IO;
using NUnit.Framework;

namespace dnAnalytics.Tests.LinearAlgebra.Decomposition
{
    [TestFixture]
    public class BaseSvdTests : SvdTests
    {
        public override Vector GetVector(int size)
        {
            return new BaseVector(size);
        }

        public override Matrix GetMatrix(int order)
        {
            return new BaseMatrix(order);
        }

        public override Matrix GetMatrix(int rows, int columns)
        {
            return new BaseMatrix(rows, columns);
        }

        public override Matrix GetMatrix(string matrixFile)
        {
            MatrixMarketReader mmr = new MatrixMarketReader();
            Matrix matrix = mmr.ReadMatrix(matrixFile, StorageType.Dense);
            return new BaseMatrix(matrix);
        }
    }
}