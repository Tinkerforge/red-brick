using dnAnalytics.Math;
using NUnit.Framework;

namespace dnAnalytics.Tests.Math
{
    [TestFixture]
    public class ComplexMath_CosTest32
    {
        [Test]
        public void Cos()
        {
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(0.0f, 1.19209289550780998537e-7f)), new Complex32(1.00000000000000710543f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(0.0f, -1.19209289550780998537e-7f)), new Complex32(1.00000000000000710543f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(0.0f, 5.0e-1f)), new Complex32(1.12762596520638078523f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(0.0f, -5.0e-1f)), new Complex32(1.12762596520638078523f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(0.0f, 1.0f)), new Complex32(1.54308063481524377848f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(0.0f, -1.0f)), new Complex32(1.54308063481524377848f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(0.0f, 2.0f)), new Complex32(3.76219569108363145956f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(0.0f, -2.0f)), new Complex32(3.76219569108363145956f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(1.19209289550780998537e-7f, 0.0f)), new Complex32(9.99999999999992894573e-1f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-1.19209289550780998537e-7f, 0.0f)), new Complex32(9.99999999999992894573e-1f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(1.19209289550780998537e-7f, 1.19209289550780998537e-7f)), new Complex32(1.0f, -1.4210854715201943764e-14f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(1.19209289550780998537e-7f, -1.19209289550780998537e-7f)), new Complex32(1.0f, 1.4210854715201943764e-14f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-1.19209289550780998537e-7f, 1.19209289550780998537e-7f)), new Complex32(1.0f, 1.4210854715201943764e-14f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-1.19209289550780998537e-7f, -1.19209289550780998537e-7f)), new Complex32(1.0f, -1.4210854715201943764e-14f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(1.19209289550780998537e-7f, 5.0e-1f)), new Complex32(1.12762596520637277296f, -6.21194011561566624892e-8f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(1.19209289550780998537e-7f, -5.0e-1f)), new Complex32(1.12762596520637277296f, 6.21194011561566624892e-8f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-1.19209289550780998537e-7f, 5.0e-1f)), new Complex32(1.12762596520637277296f, 6.21194011561566624892e-8f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-1.19209289550780998537e-7f, -5.0e-1f)), new Complex32(1.12762596520637277296f, -6.21194011561566624892e-8f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(1.19209289550780998537e-7f, 1.0f)), new Complex32(1.54308063481523281423f, -1.40094899373507046038e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(1.19209289550780998537e-7f, -1.0f)), new Complex32(1.54308063481523281423f, 1.40094899373507046038e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-1.19209289550780998537e-7f, 1.0f)), new Complex32(1.54308063481523281423f, 1.40094899373507046038e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-1.19209289550780998537e-7f, -1.0f)), new Complex32(1.54308063481523281423f, -1.40094899373507046038e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(1.19209289550780998537e-7f, 2.0f)), new Complex32(3.76219569108360472755f, -4.32355452519297901029e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(1.19209289550780998537e-7f, -2.0f)), new Complex32(3.76219569108360472755f, 4.32355452519297901029e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-1.19209289550780998537e-7f, 2.0f)), new Complex32(3.76219569108360472755f, 4.32355452519297901029e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-1.19209289550780998537e-7f, -2.0f)), new Complex32(3.76219569108360472755f, -4.32355452519297901029e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(5.0e-1f, 0.0f)), new Complex32(8.77582561890372716116e-1f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-5.0e-1f, 0.0f)), new Complex32(8.77582561890372716116e-1f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(5.0e-1f, 1.19209289550780998537e-7f)), new Complex32(8.77582561890378951715e-1f, -5.71519778495077043139e-8f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(5.0e-1f, -1.19209289550780998537e-7f)), new Complex32(8.77582561890378951715e-1f, 5.71519778495077043139e-8f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-5.0e-1f, 1.19209289550780998537e-7f)), new Complex32(8.77582561890378951715e-1f, 5.71519778495077043139e-8f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-5.0e-1f, -1.19209289550780998537e-7f)), new Complex32(8.77582561890378951715e-1f, -5.71519778495077043139e-8f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(5.0e-1f, 5.0e-1f)), new Complex32(9.89584883399919936444e-1f, -2.4982639750046153149e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(5.0e-1f, -5.0e-1f)), new Complex32(9.89584883399919936444e-1f, 2.4982639750046153149e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-5.0e-1f, 5.0e-1f)), new Complex32(9.89584883399919936444e-1f, 2.4982639750046153149e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-5.0e-1f, -5.0e-1f)), new Complex32(9.89584883399919936444e-1f, -2.4982639750046153149e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(5.0e-1f, 1.0f)), new Complex32(1.35418065670458429296f, -5.63421465230981780955e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(5.0e-1f, -1.0f)), new Complex32(1.35418065670458429296f, 5.63421465230981780955e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-5.0e-1f, 1.0f)), new Complex32(1.35418065670458429296f, 5.63421465230981780955e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-5.0e-1f, -1.0f)), new Complex32(1.35418065670458429296f, -5.63421465230981780955e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(5.0e-1f, 2.0f)), new Complex32(3.30163733291409455749f, -1.73880950447431633438f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(5.0e-1f, -2.0f)), new Complex32(3.30163733291409455749f, 1.73880950447431633438f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-5.0e-1f, 2.0f)), new Complex32(3.30163733291409455749f, 1.73880950447431633438f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-5.0e-1f, -2.0f)), new Complex32(3.30163733291409455749f, -1.73880950447431633438f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(1.0f, 0.0f)), new Complex32(5.40302305868139717401e-1f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-1.0f, 0.0f)), new Complex32(5.40302305868139717401e-1f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(1.0f, 1.19209289550780998537e-7f)), new Complex32(5.4030230586814355648e-1f, -1.00311158276545610981e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(1.0f, -1.19209289550780998537e-7f)), new Complex32(5.4030230586814355648e-1f, 1.00311158276545610981e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-1.0f, 1.19209289550780998537e-7f)), new Complex32(5.4030230586814355648e-1f, 1.00311158276545610981e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-1.0f, -1.19209289550780998537e-7f)), new Complex32(5.4030230586814355648e-1f, -1.00311158276545610981e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(1.0f, 5.0e-1f)), new Complex32(6.09258909157794225734e-1f, -4.38486579892595275173e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(1.0f, -5.0e-1f)), new Complex32(6.09258909157794225734e-1f, 4.38486579892595275173e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-1.0f, 5.0e-1f)), new Complex32(6.09258909157794225734e-1f, 4.38486579892595275173e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-1.0f, -5.0e-1f)), new Complex32(6.09258909157794225734e-1f, -4.38486579892595275173e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(1.0f, 1.0f)), new Complex32(8.33730025131149048884e-1f, -9.88897705762865096382e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(1.0f, -1.0f)), new Complex32(8.33730025131149048884e-1f, 9.88897705762865096382e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-1.0f, 1.0f)), new Complex32(8.33730025131149048884e-1f, 9.88897705762865096382e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-1.0f, -1.0f)), new Complex32(8.33730025131149048884e-1f, -9.88897705762865096382e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(1.0f, 2.0f)), new Complex32(2.03272300701966552944f, -3.05189779915180005751f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(1.0f, -2.0f)), new Complex32(2.03272300701966552944f, 3.05189779915180005751f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-1.0f, 2.0f)), new Complex32(2.03272300701966552944f, 3.05189779915180005751f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-1.0f, -2.0f)), new Complex32(2.03272300701966552944f, -3.05189779915180005751f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(2.0f, 0.0f)), new Complex32(-4.16146836547142386998e-1f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-2.0f, 0.0f)), new Complex32(-4.16146836547142386998e-1f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(2.0f, 1.19209289550780998537e-7f)), new Complex32(-4.16146836547145343899e-1f, -1.08396700242243043298e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(2.0f, -1.19209289550780998537e-7f)), new Complex32(-4.16146836547145343899e-1f, 1.08396700242243043298e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-2.0f, 1.19209289550780998537e-7f)), new Complex32(-4.16146836547145343899e-1f, 1.08396700242243043298e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-2.0f, -1.19209289550780998537e-7f)), new Complex32(-4.16146836547145343899e-1f, -1.08396700242243043298e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(2.0f, 5.0e-1f)), new Complex32(-4.69257978229053413027e-1f, -4.73830620416406990321e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(2.0f, -5.0e-1f)), new Complex32(-4.69257978229053413027e-1f, 4.73830620416406990321e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-2.0f, 5.0e-1f)), new Complex32(-4.69257978229053413027e-1f, 4.73830620416406990321e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-2.0f, -5.0e-1f)), new Complex32(-4.69257978229053413027e-1f, -4.73830620416406990321e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(2.0f, 1.0f)), new Complex32(-6.42148124715519964845e-1f, -1.0686074213827783396f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(2.0f, -1.0f)), new Complex32(-6.42148124715519964845e-1f, 1.0686074213827783396f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-2.0f, 1.0f)), new Complex32(-6.42148124715519964845e-1f, 1.0686074213827783396f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-2.0f, -1.0f)), new Complex32(-6.42148124715519964845e-1f, -1.0686074213827783396f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(2.0f, 2.0f)), new Complex32(-1.56562583531574337406f, -3.29789483631123661773f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(2.0f, -2.0f)), new Complex32(-1.56562583531574337406f, 3.29789483631123661773f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-2.0f, 2.0f)), new Complex32(-1.56562583531574337406f, 3.29789483631123661773f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-2.0f, -2.0f)), new Complex32(-1.56562583531574337406f, -3.29789483631123661773f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(8.388608e6f, 0.0f)), new Complex32(-9.01754673758759322321e-1f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-8.388608e6f, 0.0f)), new Complex32(-9.01754673758759322321e-1f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(8.388608e6f, 1.19209289550780998537e-7f)), new Complex32(-9.01754673758765729674e-1f, -5.15280011006352744858e-8f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(8.388608e6f, -1.19209289550780998537e-7f)), new Complex32(-9.01754673758765729674e-1f, 5.15280011006352744858e-8f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-8.388608e6f, 1.19209289550780998537e-7f)), new Complex32(-9.01754673758765729674e-1f, 5.15280011006352744858e-8f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-8.388608e6f, -1.19209289550780998537e-7f)), new Complex32(-9.01754673758765729674e-1f, -5.15280011006352744858e-8f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(8.388608e6f, 5.0e-1f)), new Complex32(-1.01684198437658599569f, -2.2524250900412912476e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(8.388608e6f, -5.0e-1f)), new Complex32(-1.01684198437658599569f, 2.2524250900412912476e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-8.388608e6f, 5.0e-1f)), new Complex32(-1.01684198437658599569f, 2.2524250900412912476e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-8.388608e6f, -5.0e-1f)), new Complex32(-1.01684198437658599569f, -2.2524250900412912476e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(8.388608e6f, 1.0f)), new Complex32(-1.39148017443127938564f, -5.07978603242576038333e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(8.388608e6f, -1.0f)), new Complex32(-1.39148017443127938564f, 5.07978603242576038333e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-8.388608e6f, 1.0f)), new Complex32(-1.39148017443127938564f, 5.07978603242576038333e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-8.388608e6f, -1.0f)), new Complex32(-1.39148017443127938564f, -5.07978603242576038333e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(8.388608e6f, 2.0f)), new Complex32(-3.39257754802973015548f, -1.56770389112823016984f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(8.388608e6f, -2.0f)), new Complex32(-3.39257754802973015548f, 1.56770389112823016984f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-8.388608e6f, 2.0f)), new Complex32(-3.39257754802973015548f, 1.56770389112823016984f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Cos(new Complex32(-8.388608e6f, -2.0f)), new Complex32(-3.39257754802973015548f, -1.56770389112823016984f), 7);
        }
    }
}