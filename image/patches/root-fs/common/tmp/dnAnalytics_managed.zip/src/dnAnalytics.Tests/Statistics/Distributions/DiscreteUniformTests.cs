using dnAnalytics.Statistics.Distributions;
using NUnit.Framework;

namespace dnAnalytics.Tests.Statistics.Distributions
{
    [TestFixture]
    public class DiscreteUniformTests
    {
        private const double mAcceptableError = 1e-12;

        [Test]
        public void DiscreteUniform()
        {
            DiscreteUniform du = new DiscreteUniform(2, 5);

            Assert.AreEqual((5.0 + 2.0) / 2.0, du.Mean, mAcceptableError);
            Assert.AreEqual(15.0 / 12.0, du.Variance, mAcceptableError);
            Assert.AreEqual(System.Math.Sqrt(15.0 / 12.0), du.StdDev, mAcceptableError);

            Assert.AreEqual(1.0 / 4.0, du.Probability(3), mAcceptableError);
        }

        [Test]
        public void GetSetRNG()
        {
            DiscreteUniform du = new DiscreteUniform(2, 5);

            // Try getting the random number generator.
            System.Random rnd = du.RandomNumberGenerator;
            // Try setting the random number generator.
            du.RandomNumberGenerator = new System.Random();
        }
    }
}