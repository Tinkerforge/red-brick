﻿using dnAnalytics.LinearAlgebra;
using dnAnalytics.LinearAlgebra.IO;
using NUnit.Framework;

namespace dnAnalytics.Tests.LinearAlgebra.Decomposition
{
    [TestFixture]
    public class DenseSvdTests : SvdTests
    {
        public override Vector GetVector(int size)
        {
            return new DenseVector(size);
        }

        public override Matrix GetMatrix(int order)
        {
            return new DenseMatrix(order);
        }

        public override Matrix GetMatrix(int rows, int columns)
        {
            return new DenseMatrix(rows, columns);
        }

        public override Matrix GetMatrix(string matrixFile)
        {
            MatrixMarketReader mmr = new MatrixMarketReader();
            return mmr.ReadMatrix(matrixFile, StorageType.Dense);
        }
    }
}