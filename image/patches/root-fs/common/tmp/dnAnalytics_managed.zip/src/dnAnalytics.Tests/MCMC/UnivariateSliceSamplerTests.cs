﻿using System;
using dnAnalytics.Mcmc;
using dnAnalytics.Statistics.Distributions;
using NUnit.Framework;

namespace dnAnalytics.Tests.MCMC
{
    [TestFixture]
    public class UnivariateSliceSamplerTests
    {
        [Test]
        public void ConstructorTest()
        {
            var ss = new UnivariateSliceSampler(0.1, x => -0.5 * x * x, 5, 1.0);
        }

        [Test]
        public void SampleTest()
        {
            var ss = new UnivariateSliceSampler(0.1, x => -0.5 * x * x, 5, 1.0);
            double sample = ss.Sample();
        }

        [Test]
        public void SampleArrayTest()
        {
            var ss = new UnivariateSliceSampler(0.1, x => -0.5 * x * x, 5, 1.0);
            double[] sample = ss.Sample(5);
        }

        [Test]
        public void RNGTest()
        {
            var ss = new UnivariateSliceSampler(0.1, x => -0.5 * x * x, 5, 1.0);

            Assert.IsNotNull(ss.RandomNumberGenerator);
            ss.RandomNumberGenerator = new System.Random();
            Assert.IsNotNull(ss.RandomNumberGenerator);
        }

        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void InvalidScale()
        {
            var ss = new UnivariateSliceSampler(0.1, x => -0.5 * x * x, 5, -1.0);
        }

        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void InvalidBurn()
        {
            var ss = new UnivariateSliceSampler(0.1, x => -0.5 * x * x, -5, 1.0);
        }
    }
}
