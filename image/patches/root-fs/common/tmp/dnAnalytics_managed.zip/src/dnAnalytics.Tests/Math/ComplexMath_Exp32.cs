using dnAnalytics.Math;
using NUnit.Framework;

namespace dnAnalytics.Tests.Math
{
    [TestFixture]
    public class ComplexMath_Exp32Test
    {
        [Test]
        public void Exp()
        {
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(0.0f, 1.19209289550780998537e-7f)), new Complex32(9.99999999999992894573e-1f, 1.19209289550780716193e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(0.0f, -1.19209289550780998537e-7f)), new Complex32(9.99999999999992894573e-1f, -1.19209289550780716193e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(0.0f, 5.0e-1f)), new Complex32(8.77582561890372716116e-1f, 4.79425538604203000273e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(0.0f, -5.0e-1f)), new Complex32(8.77582561890372716116e-1f, -4.79425538604203000273e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(0.0f, 1.0f)), new Complex32(5.40302305868139717401e-1f, 8.41470984807896506653e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(0.0f, -1.0f)), new Complex32(5.40302305868139717401e-1f, -8.41470984807896506653e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(0.0f, 2.0f)), new Complex32(-4.16146836547142386998e-1f, 9.09297426825681695396e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(0.0f, -2.0f)), new Complex32(-4.16146836547142386998e-1f, -9.09297426825681695396e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(0.0f, 8.388608e6f)), new Complex32(-9.01754673758759322321e-1f, 4.32248202256797756659e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(0.0f, -8.388608e6f)), new Complex32(-9.01754673758759322321e-1f, -4.32248202256797756659e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.19209289550780998537e-7f, 0.0f)), new Complex32(1.00000011920929665621f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.19209289550780998537e-7f, 0.0f)), new Complex32(9.99999880790717554646e-1f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.19209289550780998537e-7f, 1.19209289550780998537e-7f)), new Complex32(1.00000011920928955078f, 1.19209303761636278428e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.19209289550780998537e-7f, -1.19209289550780998537e-7f)), new Complex32(1.00000011920928955078f, -1.19209303761636278428e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.19209289550780998537e-7f, 1.19209289550780998537e-7f)), new Complex32(9.9999988079071044922e-1f, 1.19209275339926848024e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.19209289550780998537e-7f, -1.19209289550780998537e-7f)), new Complex32(9.9999988079071044922e-1f, -1.19209275339926848024e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.19209289550780998537e-7f, 5.0e-1f)), new Complex32(8.77582666506372676821e-1f, 4.79425595756184256304e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.19209289550780998537e-7f, -5.0e-1f)), new Complex32(8.77582666506372676821e-1f, -4.79425595756184256304e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.19209289550780998537e-7f, 5.0e-1f)), new Complex32(8.7758245727438522661e-1f, 4.79425481452228557289e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.19209289550780998537e-7f, -5.0e-1f)), new Complex32(8.7758245727438522661e-1f, -4.79425481452228557289e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.19209289550780998537e-7f, 1.0f)), new Complex32(5.4030237027719758167e-1f, 8.41471085119060762209e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.19209289550780998537e-7f, -1.0f)), new Complex32(5.4030237027719758167e-1f, -8.41471085119060762209e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.19209289550780998537e-7f, 1.0f)), new Complex32(5.4030224145908953129e-1f, 8.41470884496744209118e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.19209289550780998537e-7f, -1.0f)), new Complex32(5.4030224145908953129e-1f, -8.41470884496744209118e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.19209289550780998537e-7f, 2.0f)), new Complex32(-4.16146886155714077489e-1f, 9.09297535222388398586e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.19209289550780998537e-7f, -2.0f)), new Complex32(-4.16146886155714077489e-1f, -9.09297535222388398586e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.19209289550780998537e-7f, 2.0f)), new Complex32(-4.16146786938576610309e-1f, 9.092973184289879141e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.19209289550780998537e-7f, -2.0f)), new Complex32(-4.16146786938576610309e-1f, -9.092973184289879141e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.19209289550780998537e-7f, 8.388608e6f)), new Complex32(-9.01754781256299737552e-1f, 4.32248253784801928603e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.19209289550780998537e-7f, -8.388608e6f)), new Complex32(-9.01754781256299737552e-1f, -4.32248253784801928603e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.19209289550780998537e-7f, 8.388608e6f)), new Complex32(-9.01754566261231721795e-1f, 4.32248150728799727332e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.19209289550780998537e-7f, -8.388608e6f)), new Complex32(-9.01754566261231721795e-1f, -4.32248150728799727332e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(5.0e-1f, 0.0f)), new Complex32(1.64872127070012814685f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-5.0e-1f, 0.0f)), new Complex32(6.06530659712633423604e-1f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(5.0e-1f, 1.19209289550780998537e-7f)), new Complex32(1.64872127070011643198f, 1.96542891347422690873e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(5.0e-1f, -1.19209289550780998537e-7f)), new Complex32(1.64872127070011643198f, -1.96542891347422690873e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-5.0e-1f, 1.19209289550780998537e-7f)), new Complex32(6.06530659712629113944e-1f, 7.23040890351093658948e-8f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-5.0e-1f, -1.19209289550780998537e-7f)), new Complex32(6.06530659712629113944e-1f, -7.23040890351093658948e-8f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(5.0e-1f, 5.0e-1f)), new Complex32(1.44688903658416915805f, 7.90439083213614911843e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(5.0e-1f, -5.0e-1f)), new Complex32(1.44688903658416915805f, -7.90439083213614911843e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-5.0e-1f, 5.0e-1f)), new Complex32(5.32280730215670714837e-1f, 2.90786288212691848864e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-5.0e-1f, -5.0e-1f)), new Complex32(5.32280730215670714837e-1f, -2.90786288212691848864e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(5.0e-1f, 1.0f)), new Complex32(8.90807904293128619556e-1f, 1.3873511113297633557f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(5.0e-1f, -1.0f)), new Complex32(8.90807904293128619556e-1f, -1.3873511113297633557f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-5.0e-1f, 1.0f)), new Complex32(3.27709914022459831911e-1f, 5.10377951544572805351e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-5.0e-1f, -1.0f)), new Complex32(3.27709914022459831911e-1f, -5.10377951544572805351e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(5.0e-1f, 2.0f)), new Complex32(-6.8611014114984312465e-1f, 1.49917800900039471583f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(5.0e-1f, -2.0f)), new Complex32(-6.8611014114984312465e-1f, -1.49917800900039471583f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-5.0e-1f, 2.0f)), new Complex32(-2.52405815308263701403e-1f, 5.51516768167580735186e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-5.0e-1f, -2.0f)), new Complex32(-2.52405815308263701403e-1f, -5.51516768167580735186e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(5.0e-1f, 8.388608e6f)), new Complex32(-1.48674211157932117217f, 7.12656805282673596317e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(5.0e-1f, -8.388608e6f)), new Complex32(-1.48674211157932117217f, -7.12656805282673596317e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-5.0e-1f, 8.388608e6f)), new Complex32(-5.46941857173850819201e-1f, 2.62171787274415346797e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-5.0e-1f, -8.388608e6f)), new Complex32(-5.46941857173850819201e-1f, -2.62171787274415346797e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.0f, 0.0f)), new Complex32(2.71828182845904523536f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.0f, 0.0f)), new Complex32(3.67879441171442321596e-1f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.0f, 1.19209289550780998537e-7f)), new Complex32(2.71828182845902592081f, 3.24044445569399960419e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.0f, -1.19209289550780998537e-7f)), new Complex32(2.71828182845902592081f, -3.24044445569399960419e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.0f, 1.19209289550780998537e-7f)), new Complex32(3.67879441171439707655e-1f, 4.38546468223858683429e-8f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.0f, -1.19209289550780998537e-7f)), new Complex32(3.67879441171439707655e-1f, -4.38546468223858683429e-8f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.0f, 5.0e-1f)), new Complex32(2.38551673095913557604f, 1.30321372968699550927f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.0f, -5.0e-1f)), new Complex32(2.38551673095913557604f, -1.30321372968699550927f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.0f, 5.0e-1f)), new Complex32(3.22844582450033009889e-1f, 1.76370799225031947362e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.0f, -5.0e-1f)), new Complex32(3.22844582450033009889e-1f, -1.76370799225031947362e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.0f, 1.0f)), new Complex32(1.46869393991588515714f, 2.28735528717884239121f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.0f, -1.0f)), new Complex32(1.46869393991588515714f, -2.28735528717884239121f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.0f, 1.0f)), new Complex32(1.98766110346412940629e-1f, 3.09559875653112198444e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.0f, -1.0f)), new Complex32(1.98766110346412940629e-1f, -3.09559875653112198444e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.0f, 2.0f)), new Complex32(-1.13120438375681363843f, 2.47172667200481892762f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.0f, -2.0f)), new Complex32(-1.13120438375681363843f, -2.47172667200481892762f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.0f, 2.0f)), new Complex32(-1.53091865674226291258e-1f, 3.34511829239262248422e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.0f, -2.0f)), new Complex32(-1.53091865674226291258e-1f, -3.34511829239262248422e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.0f, 8.388608e6f)), new Complex32(-2.45122334340645010814f, 1.17497243357874340914f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(1.0f, -8.388608e6f)), new Complex32(-2.45122334340645010814f, -1.17497243357874340914f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.0f, 8.388608e6f)), new Complex32(-3.31737005456108663128e-1f, 1.5901522709359133247e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-1.0f, -8.388608e6f)), new Complex32(-3.31737005456108663128e-1f, -1.5901522709359133247e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(2.0f, 0.0f)), new Complex32(7.38905609893065022723f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-2.0f, 0.0f)), new Complex32(1.35335283236612691894e-1f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(2.0f, 1.19209289550780998537e-7f)), new Complex32(7.38905609893059772483f, 8.80844128004386084053e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(2.0f, -1.19209289550780998537e-7f)), new Complex32(7.38905609893059772483f, -8.80844128004386084053e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-2.0f, 1.19209289550780998537e-7f)), new Complex32(1.35335283236611730279e-1f, 1.61332229657902819963e-8f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-2.0f, -1.19209289550780998537e-7f)), new Complex32(1.35335283236611730279e-1f, -1.61332229657902819963e-8f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(2.0f, 5.0e-1f)), new Complex32(6.48450678125124333615f, 3.54250220000649807404f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(2.0f, -5.0e-1f)), new Complex32(6.48450678125124333615f, -3.54250220000649807404f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-2.0f, 5.0e-1f)), new Complex32(1.18767884576945778839e-1f, 6.48831910578654052833e-2f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-2.0f, -5.0e-1f)), new Complex32(1.18767884576945778839e-1f, -6.48831910578654052833e-2f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(2.0f, 1.0f)), new Complex32(3.99232404844127142651f, 6.21767631236796820425f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(2.0f, -1.0f)), new Complex32(3.99232404844127142651f, -6.21767631236796820425f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-2.0f, 1.0f)), new Complex32(7.3121965598059632366e-2f, 1.13880714064368089229e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-2.0f, -1.0f)), new Complex32(7.3121965598059632366e-2f, -1.13880714064368089229e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(2.0f, 2.0f)), new Complex32(-3.07493232063935886711f, 6.71884969742824997127f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(2.0f, -2.0f)), new Complex32(-3.07493232063935886711f, -6.71884969742824997127f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-2.0f, 2.0f)), new Complex32(-5.63193499921278810042e-2f, 1.23060024805776735808e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-2.0f, -2.0f)), new Complex32(-5.63193499921278810042e-2f, -1.23060024805776735808e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(2.0f, 8.388608e6f)), new Complex32(-6.66311587187637934355f, 3.19390621513740071345f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(2.0f, -8.388608e6f)), new Complex32(-6.66311587187637934355f, -3.19390621513740071345f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-2.0f, 8.388608e6f)), new Complex32(-1.22039224183080967401e-1f, 5.84984328809403737736e-2f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-2.0f, -8.388608e6f)), new Complex32(-1.22039224183080967401e-1f, -5.84984328809403737736e-2f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-8.388608e6f, 0.0f)), new Complex32(6.83518898007422449157e-3643127f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-8.388608e6f, 1.19209289550780998537e-7f)), new Complex32(6.83518898007417592464e-3643127f, 8.14818022259973750625e-3643134f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-8.388608e6f, -1.19209289550780998537e-7f)), new Complex32(6.83518898007417592464e-3643127f, -8.14818022259973750625e-3643134f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-8.388608e6f, 5.0e-1f)), new Complex32(5.99844265613838167676e-3643127f, 3.276964158233598046e-3643127f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-8.388608e6f, -5.0e-1f)), new Complex32(5.99844265613838167676e-3643127f, -3.276964158233598046e-3643127f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-8.388608e6f, 1.0f)), new Complex32(3.69306836697860159343e-3643127f, 5.75161320241113937527e-3643127f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-8.388608e6f, -1.0f)), new Complex32(3.69306836697860159343e-3643127f, -5.75161320241113937527e-3643127f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-8.388608e6f, 2.0f)), new Complex32(-2.84444227125977718146e-3643127f, 6.21521975144874804455e-3643127f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-8.388608e6f, -2.0f)), new Complex32(-2.84444227125977718146e-3643127f, -6.21521975144874804455e-3643127f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-8.388608e6f, 8.388608e6f)), new Complex32(-6.16366360880629918059e-3643127f, 2.95449814872255855945e-3643127f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Exp(new Complex32(-8.388608e6f, -8.388608e6f)), new Complex32(-6.16366360880629918059e-3643127f, -2.95449814872255855945e-3643127f), 6);
        }
    }
}