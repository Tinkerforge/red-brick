using System;

namespace dnAnalytics.Tests
{
    /// <summary>
    /// A little program to calculate the floating points within a certain range of ULPS from a central value.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            int ulps = 10;
            double[] centers = new double[] { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0 };
            
            foreach (double center in centers)
	        {
                Console.WriteLine(string.Format("Range around {0} with {1} ULPS: [{2};{3}]", 
                center, 
                ulps,
                BitConverter.Int64BitsToDouble(BitConverter.DoubleToInt64Bits(center) - ulps).ToString("R"),
                BitConverter.Int64BitsToDouble(BitConverter.DoubleToInt64Bits(center) + ulps).ToString("R")));
	        }

            Console.ReadLine();
        }
    }
}