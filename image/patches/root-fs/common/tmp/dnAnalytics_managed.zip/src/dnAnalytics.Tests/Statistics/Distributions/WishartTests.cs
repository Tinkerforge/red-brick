using NUnit.Framework;
using dnAnalytics.LinearAlgebra;
using dnAnalytics.Statistics.Distributions;

namespace dnAnalytics.Tests.Statistics.Distributions
{
    [TestFixture]
    public class WishartTests
    {
        private const double mAcceptableError = 1e-12;

        [Test]
        public void Wishart()
        {
            Matrix S = new DenseMatrix(new double[,] { { 1.0, 0.0, 0.0 }, { 0.0, 2.0, 0.0 }, { 0.0, 0.0, 3.0 } });
            Wishart w = new Wishart(5.0, S);

            Assert.AreEqual(5.0, w.Mean[0, 0], mAcceptableError);
            Assert.AreEqual(10.0, w.Mean[1, 1], mAcceptableError);
            Assert.AreEqual(15.0, w.Mean[2, 2], mAcceptableError);
            Assert.AreEqual(0.0, w.Mean[1, 0], mAcceptableError);
            Assert.AreEqual(0.0, w.Mean[2, 0], mAcceptableError);
            Assert.AreEqual(0.0, w.Mean[0, 1], mAcceptableError);
            Assert.AreEqual(0.0, w.Mean[0, 2], mAcceptableError);
        }

        [Test]
        public void GetSetRNG()
        {
            Matrix S = new DenseMatrix(new double[,] { { 1.0, 0.0, 0.0 }, { 0.0, 2.0, 0.0 }, { 0.0, 0.0, 3.0 } });
            Wishart w = new Wishart(5.0, S);

            // Try getting the random number generator.
            System.Random rnd = w.RandomNumberGenerator;
            // Try setting the random number generator.
            w.RandomNumberGenerator = new System.Random();
        }
    }
}