﻿using dnAnalytics.Random;
using NUnit.Framework;

namespace dnAnalytics.Tests.Random
{
    [TestFixture]
    public class SystemCryptoRandomNumberGeneratorTests : RandomTests
    {
        public SystemCryptoRandomNumberGeneratorTests() : base(typeof (SystemCryptoRandomNumberGenerator))
        {
        }
    }
}