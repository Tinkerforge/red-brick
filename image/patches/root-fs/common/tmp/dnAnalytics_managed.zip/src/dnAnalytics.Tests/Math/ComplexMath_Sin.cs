using dnAnalytics.Math;
using NUnit.Framework;

namespace dnAnalytics.Tests.Math
{
    [TestFixture]
    public class ComplexMath_SinTest
    {
        [Test]
        public void Sin()
        {
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(0.0, 1.19209289550780998537e-7)), new Complex(0.0, 1.19209289550781280881e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(0.0, -1.19209289550780998537e-7)), new Complex(0.0, -1.19209289550781280881e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(0.0, 5.0e-1)), new Complex(0.0, 5.21095305493747361622e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(0.0, -5.0e-1)), new Complex(0.0, -5.21095305493747361622e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(0.0, 1.0)), new Complex(0.0, 1.17520119364380145688), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(0.0, -1.0)), new Complex(0.0, -1.17520119364380145688), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(0.0, 2.0)), new Complex(0.0, 3.62686040784701876767), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(0.0, -2.0)), new Complex(0.0, -3.62686040784701876767), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(1.19209289550780998537e-7, 0.0)), new Complex(1.19209289550780716193e-7, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-1.19209289550780998537e-7, 0.0)), new Complex(-1.19209289550780716193e-7, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(1.19209289550780998537e-7, 1.19209289550780998537e-7)), new Complex(1.19209289550781563226e-7, 1.19209289550780433848e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(1.19209289550780998537e-7, -1.19209289550780998537e-7)), new Complex(1.19209289550781563226e-7, -1.19209289550780433848e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-1.19209289550780998537e-7, 1.19209289550780998537e-7)), new Complex(-1.19209289550781563226e-7, 1.19209289550780433848e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-1.19209289550780998537e-7, -1.19209289550780998537e-7)), new Complex(-1.19209289550781563226e-7, -1.19209289550780433848e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(1.19209289550780998537e-7, 5.0e-1)), new Complex(1.34423490191266028384e-7, 5.21095305493743659018e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(1.19209289550780998537e-7, -5.0e-1)), new Complex(1.34423490191266028384e-7, -5.21095305493743659018e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-1.19209289550780998537e-7, 5.0e-1)), new Complex(-1.34423490191266028384e-7, 5.21095305493743659018e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-1.19209289550780998537e-7, -5.0e-1)), new Complex(-1.34423490191266028384e-7, -5.21095305493743659018e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(1.19209289550780998537e-7, 1.0)), new Complex(1.83949546195892914381e-7, 1.17520119364379310658), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(1.19209289550780998537e-7, -1.0)), new Complex(1.83949546195892914381e-7, -1.17520119364379310658), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-1.19209289550780998537e-7, 1.0)), new Complex(-1.83949546195892914381e-7, 1.17520119364379310658), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-1.19209289550780998537e-7, -1.0)), new Complex(-1.83949546195892914381e-7, -1.17520119364379310658), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(1.19209289550780998537e-7, 2.0)), new Complex(4.48488675485088183025e-7, 3.62686040784699299728), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(1.19209289550780998537e-7, -2.0)), new Complex(4.48488675485088183025e-7, -3.62686040784699299728), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-1.19209289550780998537e-7, 2.0)), new Complex(-4.48488675485088183025e-7, 3.62686040784699299728), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-1.19209289550780998537e-7, -2.0)), new Complex(-4.48488675485088183025e-7, -3.62686040784699299728), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(5.0e-1, 0.0)), new Complex(4.79425538604203000273e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-5.0e-1, 0.0)), new Complex(-4.79425538604203000273e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(5.0e-1, 1.19209289550780998537e-7)), new Complex(4.79425538604206406797e-1, 1.0461599372510587495e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(5.0e-1, -1.19209289550780998537e-7)), new Complex(4.79425538604206406797e-1, -1.0461599372510587495e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-5.0e-1, 1.19209289550780998537e-7)), new Complex(-4.79425538604206406797e-1, 1.0461599372510587495e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-5.0e-1, -1.19209289550780998537e-7)), new Complex(-4.79425538604206406797e-1, -1.0461599372510587495e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(5.0e-1, 5.0e-1)), new Complex(5.40612685713153380354e-1, 4.57304153184249221608e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(5.0e-1, -5.0e-1)), new Complex(5.40612685713153380354e-1, -4.57304153184249221608e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-5.0e-1, 5.0e-1)), new Complex(-5.40612685713153380354e-1, 4.57304153184249221608e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-5.0e-1, -5.0e-1)), new Complex(-5.40612685713153380354e-1, -4.57304153184249221608e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(5.0e-1, 1.0)), new Complex(7.39792264456013728317e-1, 1.03133607425455128307), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(5.0e-1, -1.0)), new Complex(7.39792264456013728317e-1, -1.03133607425455128307), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-5.0e-1, 1.0)), new Complex(-7.39792264456013728317e-1, 1.03133607425455128307), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-5.0e-1, -1.0)), new Complex(-7.39792264456013728317e-1, -1.03133607425455128307), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(5.0e-1, 2.0)), new Complex(1.80369269553218173966, 3.18286944833714877865), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(5.0e-1, -2.0)), new Complex(1.80369269553218173966, -3.18286944833714877865), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-5.0e-1, 2.0)), new Complex(-1.80369269553218173966, 3.18286944833714877865), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-5.0e-1, -2.0)), new Complex(-1.80369269553218173966, -3.18286944833714877865), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(1.0, 0.0)), new Complex(8.41470984807896506653e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-1.0, 0.0)), new Complex(-8.41470984807896506653e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(1.0, 1.19209289550780998537e-7)), new Complex(8.41470984807902485663e-1, 6.44090540251898595533e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(1.0, -1.19209289550780998537e-7)), new Complex(8.41470984807902485663e-1, -6.44090540251898595533e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-1.0, 1.19209289550780998537e-7)), new Complex(-8.41470984807902485663e-1, 6.44090540251898595533e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-1.0, -1.19209289550780998537e-7)), new Complex(-8.41470984807902485663e-1, -6.44090540251898595533e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(1.0, 5.0e-1)), new Complex(9.48864531437168080524e-1, 2.81548995135334393823e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(1.0, -5.0e-1)), new Complex(9.48864531437168080524e-1, -2.81548995135334393823e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-1.0, 5.0e-1)), new Complex(-9.48864531437168080524e-1, 2.81548995135334393823e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-1.0, -5.0e-1)), new Complex(-9.48864531437168080524e-1, -2.81548995135334393823e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(1.0, 1.0)), new Complex(1.29845758141597729483, 6.34963914784736108255e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(1.0, -1.0)), new Complex(1.29845758141597729483, -6.34963914784736108255e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-1.0, 1.0)), new Complex(-1.29845758141597729483, 6.34963914784736108255e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-1.0, -1.0)), new Complex(-1.29845758141597729483, -6.34963914784736108255e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(1.0, 2.0)), new Complex(3.16577851321616814674, 1.95960104142160589707), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(1.0, -2.0)), new Complex(3.16577851321616814674, -1.95960104142160589707), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-1.0, 2.0)), new Complex(-3.16577851321616814674, 1.95960104142160589707), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-1.0, -2.0)), new Complex(-3.16577851321616814674, -1.95960104142160589707), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(2.0, 0.0)), new Complex(9.09297426825681695396e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-2.0, 0.0)), new Complex(-9.09297426825681695396e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(2.0, 1.19209289550780998537e-7)), new Complex(9.09297426825688156343e-1, -4.96085687335899466039e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(2.0, -1.19209289550780998537e-7)), new Complex(9.09297426825688156343e-1, 4.96085687335899466039e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-2.0, 1.19209289550780998537e-7)), new Complex(-9.09297426825688156343e-1, -4.96085687335899466039e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-2.0, -1.19209289550780998537e-7)), new Complex(-9.09297426825688156343e-1, 4.96085687335899466039e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(2.0, 5.0e-1)), new Complex(1.02534738858398772551, -2.16852162920789711624e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(2.0, -5.0e-1)), new Complex(1.02534738858398772551, 2.16852162920789711624e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-2.0, 5.0e-1)), new Complex(-1.02534738858398772551, -2.16852162920789711624e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-2.0, -5.0e-1)), new Complex(-1.02534738858398772551, 2.16852162920789711624e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(2.0, 1.0)), new Complex(1.40311925062204058802, -4.89056259041293673586e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(2.0, -1.0)), new Complex(1.40311925062204058802, 4.89056259041293673586e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-2.0, 1.0)), new Complex(-1.40311925062204058802, -4.89056259041293673586e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-2.0, -1.0)), new Complex(-1.40311925062204058802, 4.89056259041293673586e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(2.0, 2.0)), new Complex(3.42095486111701335354, -1.50930648532361549305), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(2.0, -2.0)), new Complex(3.42095486111701335354, 1.50930648532361549305), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-2.0, 2.0)), new Complex(-3.42095486111701335354, -1.50930648532361549305), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-2.0, -2.0)), new Complex(-3.42095486111701335354, 1.50930648532361549305), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(8.388608e6, 0.0)), new Complex(4.32248202256797756659e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-8.388608e6, 0.0)), new Complex(-4.32248202256797756659e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(8.388608e6, 1.19209289550780998537e-7)), new Complex(4.32248202256800827967e-1, -1.0749753400787825059e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(8.388608e6, -1.19209289550780998537e-7)), new Complex(4.32248202256800827967e-1, 1.0749753400787825059e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-8.388608e6, 1.19209289550780998537e-7)), new Complex(-4.32248202256800827967e-1, -1.0749753400787825059e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-8.388608e6, -1.19209289550780998537e-7)), new Complex(-4.32248202256800827967e-1, 1.0749753400787825059e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(8.388608e6, 5.0e-1)), new Complex(4.87414296278544471557e-1, -4.69900127202735176486e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(8.388608e6, -5.0e-1)), new Complex(4.87414296278544471557e-1, 4.69900127202735176486e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-8.388608e6, 5.0e-1)), new Complex(-4.87414296278544471557e-1, -4.69900127202735176486e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-8.388608e6, -5.0e-1)), new Complex(-4.87414296278544471557e-1, 4.69900127202735176486e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(8.388608e6, 1.0)), new Complex(6.66993830336167370804e-1, -1.05974316897517072251), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(8.388608e6, -1.0)), new Complex(6.66993830336167370804e-1, 1.05974316897517072251), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-8.388608e6, 1.0)), new Complex(-6.66993830336167370804e-1, -1.05974316897517072251), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-8.388608e6, -1.0)), new Complex(-6.66993830336167370804e-1, 1.05974316897517072251), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(8.388608e6, 2.0)), new Complex(1.62620232400917054361, -3.27053832384664918808), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(8.388608e6, -2.0)), new Complex(1.62620232400917054361, 3.27053832384664918808), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-8.388608e6, 2.0)), new Complex(-1.62620232400917054361, -3.27053832384664918808), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex(-8.388608e6, -2.0)), new Complex(-1.62620232400917054361, 3.27053832384664918808), 13);
        }
    }
}