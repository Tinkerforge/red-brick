using dnAnalytics.Statistics.Distributions;
using NUnit.Framework;

namespace dnAnalytics.Tests.Statistics.Distributions
{
    [TestFixture]
    public class BinomialTests
    {
        private const double mAcceptableError = 1e-12;

        [Test]
        public void Binomial()
        {
            Binomial bin = new Binomial(0.3, 10);

            Assert.AreEqual(3.0, bin.Mean, mAcceptableError);
            Assert.AreEqual(1.4491376746189400, bin.StdDev, mAcceptableError);
            Assert.AreEqual(2.1, bin.Variance, mAcceptableError);

            Assert.AreEqual(System.Math.Pow(0.7, 10.0), bin.Probability(0), mAcceptableError);
            Assert.AreEqual(10.0 * 0.3 * System.Math.Pow(0.7, 9.0), bin.Probability(1), mAcceptableError);
        }

        [Test]
        public void GetSetRNG()
        {
            Binomial bin = new Binomial(0.3, 10);

            // Try getting the random number generator.
            System.Random rnd = bin.RandomNumberGenerator;
            // Try setting the random number generator.
            bin.RandomNumberGenerator = new System.Random();
        }
    }
}