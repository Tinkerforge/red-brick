using dnAnalytics.Statistics.Distributions;
using NUnit.Framework;

namespace dnAnalytics.Tests.Statistics.Distributions
{
    [TestFixture]
    public class ExponentialTests
    {
        private const double mAcceptableError = 1e-12;

        [Test]
        public void Exponential()
        {
            Exponential exponential = new Exponential(1.0);

            Assert.AreEqual(1.0, exponential.Mean, mAcceptableError);
            Assert.AreEqual(1.0, exponential.StdDev, mAcceptableError);
            Assert.AreEqual(1.0, exponential.Variance, mAcceptableError);

            Assert.AreEqual(0.13533528323661, exponential.Density(2.0), mAcceptableError);

            Assert.AreEqual(0.86466471676339, exponential.CumulativeDistribution(2.0), mAcceptableError);
        }

        [Test]
        public void GetSetRNG()
        {
            Exponential exponential = new Exponential(1.0);

            // Try getting the random number generator.
            System.Random rnd = exponential.RandomNumberGenerator;
            // Try setting the random number generator.
            exponential.RandomNumberGenerator = new System.Random();
        }
    }
}