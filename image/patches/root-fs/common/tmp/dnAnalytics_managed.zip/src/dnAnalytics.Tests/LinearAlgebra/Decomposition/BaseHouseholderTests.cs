﻿using dnAnalytics.LinearAlgebra;
using dnAnalytics.LinearAlgebra.IO;
using NUnit.Framework;

namespace dnAnalytics.Tests.LinearAlgebra.Decomposition
{
    [TestFixture]
    public class BaseHouseholderTests : HouseholderTests
    {
        protected override Matrix GetMatrix(string file)
        {
            MatrixMarketReader mmr = new MatrixMarketReader();
            Matrix matrix = mmr.ReadMatrix(file, StorageType.Dense);
            return new BaseMatrix(matrix);
        }


        protected override Matrix GetMatrix(int rows, int cols)
        {
            return new BaseMatrix(rows, cols);
        }

        protected override Vector GetVector(int count)
        {
            return new BaseVector(count);
        }
    }
}