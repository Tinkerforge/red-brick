﻿using dnAnalytics.Random;
using NUnit.Framework;

namespace dnAnalytics.Tests.Random
{
    [TestFixture]
    public class Mrg32k3aTests : RandomTests
    {
        public Mrg32k3aTests() : base(typeof (Mrg32k3a))
        {
        }
    }
}