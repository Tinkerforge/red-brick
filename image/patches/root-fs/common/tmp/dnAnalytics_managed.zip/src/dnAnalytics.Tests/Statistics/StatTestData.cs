﻿using System.Collections.Generic;
using System.IO;
using dnAnalytics.LinearAlgebra;

namespace dnAnalytics.Tests.Statistics
{
    internal class StatTestData
    {
        public readonly Vector Data;
        public readonly double?[] DataWithNulls;

        public readonly double Mean;
        public readonly double StandardDeviation;

        public StatTestData(string file)
        {
            using (StreamReader reader = new StreamReader(file))
            {
                string line = reader.ReadLine().Trim();

                while (!line.StartsWith("--"))
                {
                    if (line.StartsWith("Sample Mean"))
                    {
                        Mean = GetValue(line);
                    }
                    else if (line.StartsWith("Sample Standard Deviation"))
                    {
                        StandardDeviation = GetValue(line);
                    }
                    line = reader.ReadLine().Trim();
                }

                line = reader.ReadLine();
                
                IList<double> list = new List<double>();
                while (line != null)
                {
                    line = line.Trim();
                    if (!line.Equals(string.Empty))
                    {
                        list.Add(double.Parse(line));
                    }
                    line = reader.ReadLine();
                }

                Data = new DenseVector(list);
            }

            DataWithNulls = new double?[Data.Count + 2];
            for (int i = 0; i < Data.Count; i++)
            {
                DataWithNulls[i + 1] = Data[i];
            }
        }

        private static double GetValue(string str)
        {
            int start = str.IndexOf(":");
            string value = str.Substring(start + 1).Trim();
            if (value.Equals("NaN"))
            {
                return 0;
            }
            return double.Parse(str.Substring(start + 1).Trim());
        }
    }
}