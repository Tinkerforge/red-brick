using NUnit.Framework;
using dnAnalytics.LinearAlgebra;
using dnAnalytics.Statistics.Distributions;

namespace dnAnalytics.Tests.Statistics.Distributions
{
    [TestFixture]
    public class MatrixNormalTests
    {
        private const double mAcceptableError = 1e-12;

        [Test]
        public void StandardNormal()
        {
            // Create an identity matrix.
            Matrix I = new DenseMatrix(5);
            for (int i = 0; i < 5; i++)
            {
                I[i, i] = 1.0;
            }

            MatrixNormal normal = new MatrixNormal(I, I, I);

            // Test the mean.
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    if (i == j)
                    {
                        Assert.AreEqual(1.0, normal.Mean[i, j]);
                    }
                    else
                    {
                        Assert.AreEqual(0.0, normal.Mean[i, j]);
                    }
                }
            }
        }

        [Test]
        public void GetSetRNG()
        {
            // Create an identity matrix.
            Matrix I = new DenseMatrix(5);
            for (int i = 0; i < 5; i++)
            {
                I[i, i] = 1.0;
            }

            MatrixNormal normal = new MatrixNormal(I, I, I);

            // Try getting the random number generator.
            System.Random rnd = normal.RandomNumberGenerator;
            // Try setting the random number generator.
            normal.RandomNumberGenerator = new System.Random();
        }
    }
}