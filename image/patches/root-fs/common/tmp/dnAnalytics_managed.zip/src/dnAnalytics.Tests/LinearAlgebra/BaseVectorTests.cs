using dnAnalytics.LinearAlgebra;
using NUnit.Framework;

namespace dnAnalytics.Tests.LinearAlgebra
{
    internal class BaseVector : Vector
    {
        private readonly double[] _data;

        public BaseVector(double[] data): base(data.Length)
        {
            _data = data;
        }
        
        public BaseVector(int size): base(size)
        {
            _data = new double[size];
        }

        public override double this[int index]
        {
            get { return _data[index]; }
            set { _data[index] = value; }
        }

        protected override Vector CreateVector(int size)
        {
            return new BaseVector(size);
        }
        public override Matrix CreateMatrix(int rows, int columns)
        {
            return new BaseMatrix(rows, columns);
        }
    }


    [TestFixture]
    public class BaseVectorTests : VectorTest
    {
        public override Vector GetVector(int order)
        {
            return new BaseVector(order);
        }

        public override Vector GetVector(int order, double value)
        {
            BaseVector vector = new BaseVector(order);
            for (int i = 0; i < order; i++)
            {
                vector[i] = value;
            }
            return vector;
        }

        public override Vector GetVector(double[] data)
        {
            BaseVector vector = new BaseVector(data.Length);
            for (int i = 0; i < data.Length; i++)
            {
                vector[i] = data[i];
            }
            return vector;
        }

        public override Matrix GetMatrix(int rows, int columns)
        {
            return new BaseMatrix(rows, columns);
        }
    }
}