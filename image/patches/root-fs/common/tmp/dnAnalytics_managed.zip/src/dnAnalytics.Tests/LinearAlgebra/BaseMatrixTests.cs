using dnAnalytics.LinearAlgebra;
using NUnit.Framework;

namespace dnAnalytics.Tests.LinearAlgebra
{
    internal class BaseMatrix : Matrix
    {
        private readonly double[,] _data;

        public BaseMatrix(double[,] data) : base(data.GetLength(0),data.GetLength(1))
        {
            _data = data;
        }


        public BaseMatrix(int order): this(order, order)
        {
            
        }

        public BaseMatrix(int rows, int columns) : base(rows, columns)
        {
            _data = new double[rows,columns];
        }

        public BaseMatrix(Matrix other) : base(other.Rows, other.Columns)
        {
            _data = new double[other.Rows,other.Columns];
            for (int i = 0; i < other.Rows; i++)
            {
                for (int j = 0; j < other.Columns; j++)
                {
                    _data[i, j] = other[i, j];
                }
            }
        }

        protected override double ValueAt(int row, int column)
        {
            return _data[row, column];
        }

        protected override void ValueAt(int row, int column, double value)
        {
            _data[row, column] = value;
        }

        protected override Matrix CreateMatrix(int numberOfRows, int numberOfColumns)
        {
            return new BaseMatrix(numberOfRows, numberOfColumns);
        }

        protected override Vector CreateVector(int size)
        {
            return new BaseVector(size);
        }
    }

    [TestFixture]
    public class BaseMatrixTests : MatrixTests
    {
        public override Matrix GetMatrix(int order)
        {
            return new BaseMatrix(order, order);
        }

        public override Matrix GetMatrix(int m, int n)
        {
            return new BaseMatrix(m, n);
        }

        public override Matrix GetMatrix(double[,] data)
        {
            BaseMatrix matrix = new BaseMatrix(data.GetLength(0), data.GetLength(1));
            for (int i = 0; i < data.GetLength(0); i++)
            {
                for (int j = 0; j < data.GetLength(1); j++)
                {
                    matrix[i, j] = data[i, j];
                }
            }
            return matrix;
        }

        public override Vector GetVector(int size)
        {
            return new BaseVector(size);
        }

        public override Vector GetVector(double[] data)
        {
            BaseVector vector = new BaseVector(data.Length);
            for (int i = 0; i < data.Length; i++)
            {
                vector[i] = data[i];
            }
            return vector;
        }
    }
}