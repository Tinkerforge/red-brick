using dnAnalytics.Statistics.Distributions;
using NUnit.Framework;

namespace dnAnalytics.Tests.Statistics.Distributions
{
    [TestFixture]
    public class BetaTests
    {
        private const double mAcceptableError = 1e-12;

        [Test]
        public void Beta()
        {
            Beta beta = new Beta(10.0, 3.0);

            Assert.AreEqual(beta.A, 10.0);
            Assert.AreEqual(beta.B, 3.0);

            Assert.AreEqual(10.0 / 13.0, beta.Mean, mAcceptableError);
            double var = 10.0 * 3.0 / (13.0 * 13.0 * 14.0);
            Assert.AreEqual(System.Math.Sqrt(var), beta.StdDev, mAcceptableError);
            Assert.AreEqual(var, beta.Variance, mAcceptableError);

            Assert.AreEqual(5.346000000000012e-007, beta.Density(0.1), mAcceptableError);
            Assert.AreEqual(3.543348019200010, beta.Density(0.8), mAcceptableError);
        }

        [Test]
        public void GetSetRNG()
        {
            Beta beta = new Beta(10.0, 3.0);

            // Try getting the random number generator.
            System.Random rnd = beta.RandomNumberGenerator;
            // Try setting the random number generator.
            beta.RandomNumberGenerator = new System.Random();
        }
    }
}