using dnAnalytics.Statistics.Distributions;
using NUnit.Framework;

namespace dnAnalytics.Tests.Statistics.Distributions
{
    [TestFixture]
    public class PoissonTests
    {
        private const double mAcceptableError = 1e-12;

        [Test]
        public void Poisson()
        {
            Poisson poisson = new Poisson(4.5);

            Assert.AreEqual(4.5, poisson.Lambda);

            Assert.AreEqual(4.5, poisson.Mean, mAcceptableError);
            Assert.AreEqual(System.Math.Sqrt(4.5), poisson.StdDev, mAcceptableError);
            Assert.AreEqual(4.5, poisson.Variance, mAcceptableError);

            Assert.AreEqual(0.011108996538242, poisson.Probability(0), mAcceptableError);
            Assert.AreEqual(0.049990484422090, poisson.Probability(1), mAcceptableError);
            Assert.AreEqual(0.170826858486112, poisson.Probability(5), mAcceptableError);
            Assert.AreEqual(5.337807738237451e-005, poisson.Probability(15), mAcceptableError);
        }

        [Test]
        public void GetSetRNG()
        {
            Poisson poisson = new Poisson(4.5);

            // Try getting the random number generator.
            System.Random rnd = poisson.RandomNumberGenerator;
            // Try setting the random number generator.
            poisson.RandomNumberGenerator = new System.Random();
        }
    }
}