using NUnit.Framework;
using dnAnalytics.LinearAlgebra;
using dnAnalytics.Statistics.Distributions;

namespace dnAnalytics.Tests.Statistics.Distributions
{
    [TestFixture]
    public class InverseWishartTests
    {
        private const double mAcceptableError = 1e-12;

        [Test]
        public void InverseWishart()
        {
            Matrix S = new DenseMatrix(new double[,] { { 1.0, 0.0, 0.0 }, { 0.0, 1.0, 0.0 }, { 0.0, 0.0, 1.0 } });
            InverseWishart iw = new InverseWishart(1.0, S);

            Assert.AreEqual(1.0 / (1.0 - S.Rows - 1.0), iw.Mean[0, 0], mAcceptableError);
            Assert.AreEqual(1.0 / (1.0 - S.Rows - 1.0), iw.Mean[1, 1], mAcceptableError);
            Assert.AreEqual(1.0 / (1.0 - S.Rows - 1.0), iw.Mean[2, 2], mAcceptableError);
            Assert.AreEqual(0.0, iw.Mean[1, 0], mAcceptableError);
            Assert.AreEqual(0.0, iw.Mean[2, 0], mAcceptableError);
            Assert.AreEqual(0.0, iw.Mean[0, 1], mAcceptableError);
            Assert.AreEqual(0.0, iw.Mean[0, 2], mAcceptableError);
        }

        [Test]
        public void GetSetRNG()
        {
            Matrix S = new DenseMatrix(new double[,] { { 1.0, 0.0, 0.0 }, { 0.0, 1.0, 0.0 }, { 0.0, 0.0, 1.0 } });
            InverseWishart iw = new InverseWishart(1.0, S);

            // Try getting the random number generator.
            System.Random rnd = iw.RandomNumberGenerator;
            // Try setting the random number generator.
            iw.RandomNumberGenerator = new System.Random();
        }
    }
}