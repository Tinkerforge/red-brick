﻿using dnAnalytics.LinearAlgebra;
using dnAnalytics.LinearAlgebra.IO;
using NUnit.Framework;

namespace dnAnalytics.Tests.LinearAlgebra.Solvers.Direct
{
    [TestFixture]
    public class DenseCholeskySolverTests : CholeskySolverTests
    {
        protected override Matrix GetMatrix(string file)
        {
            MatrixMarketReader mmr = new MatrixMarketReader();
            return mmr.ReadMatrix(file, StorageType.Dense);
        }

        protected override Matrix GetIdentityMatrix(int size)
        {
            Matrix ret = new DenseMatrix(size);
            for (int i = 0; i < size; i++)
            {
                ret[i, i] = 1.0;
            }
            return ret;
        }

        protected override Vector GetVector(int count)
        {
            return new DenseVector(count);
        }
    }
}