using dnAnalytics.LinearAlgebra;
using dnAnalytics.LinearAlgebra.IO;
using NUnit.Framework;

namespace dnAnalytics.Tests.LinearAlgebra.IO
{
    [TestFixture]
    public class MatrixMarketReaderTests
    {
        [Test]
        public void ReadMatrixGeneralArray()
        {
            MatrixMarketReader mmr = new MatrixMarketReader();
            Matrix matrix = mmr.ReadMatrix("./TestData/Matrices/random_real_general_array_10_20.mtx", StorageType.Dense);
            Assert.AreEqual(10, matrix.Rows);
            Assert.AreEqual(20, matrix.Columns);
            double expected = 851.83805;
            double actual = matrix.FrobeniusNorm();
            double error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);
        }

        [Test]
        public void ReadMatrixGeneralCoordinate()
        {
            MatrixMarketReader mmr = new MatrixMarketReader();
            Matrix matrix = mmr.ReadMatrix("./TestData/Matrices/random_real_general_coordinate_10_20.mtx", StorageType.Dense);
            Assert.AreEqual(10, matrix.Rows);
            Assert.AreEqual(20, matrix.Columns);
            double expected = 402.07342;
            double actual = matrix.FrobeniusNorm();
            double error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);
        }

        [Test]
        public void ReadMatrixGeneralSymmetricArray()
        {
            MatrixMarketReader mmr = new MatrixMarketReader();
            Matrix matrix = mmr.ReadMatrix("./TestData/Matrices/hilbert_real_symmetric_array_10.mtx", StorageType.Dense);
            Assert.AreEqual(10, matrix.Rows);
            Assert.AreEqual(10, matrix.Columns);
            double expected = 1.78552;
            double actual = matrix.FrobeniusNorm();
            double error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);
        }

        [Test]
        public void ReadMatrixPatternSymmetricArray()
        {
            MatrixMarketReader mmr = new MatrixMarketReader();
            Matrix matrix =
                mmr.ReadMatrix("./TestData/Matrices/can24_pattern_symmetric_coordinate_24.mtx", StorageType.Dense);
            Assert.AreEqual(24, matrix.Rows);
            Assert.AreEqual(24, matrix.Columns);
        }
    }
}