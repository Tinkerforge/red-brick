/* Copyright 2007-2008 dnAnalytics Project.
 *
 * Contributors to this file:
 * Patrick van der Velde
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this 
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * * Neither the name of the dnAnalytics Project nor the names of its contributors
 *   may be used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

using System;
using System.Diagnostics;
using dnAnalytics.LinearAlgebra;
using NUnit.Framework;

namespace dnAnalytics.Tests.LinearAlgebra.Solvers.Preconditioners
{
    //[TestFixture]
    //[Category("Managed")]
    //public sealed class IlutpHeapSorterTest
    //{
    //    [Test]
    //    public void HeapSortWithIncreasingIntergerArray()
    //    {
    //        int[] sortedIndices = new int[10] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
    //        IlutpHeapSorter.SortIntegersDecreasing(sortedIndices);
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            Assert.AreEqual(sortedIndices.Length - 1 - i, sortedIndices[i], "#01-" + i.ToString());
    //        }
    //    }

    //    [Test]
    //    public void HeapSortWithDecreasingIntegerArray()
    //    {
    //        int[] sortedIndices = new int[10] { 9, 8, 7, 6, 5, 4, 3, 2, 1, 0 };
    //        IlutpHeapSorter.SortIntegersDecreasing(sortedIndices);
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            Assert.AreEqual(sortedIndices.Length - 1 - i, sortedIndices[i], "#01-" + i.ToString());
    //        }
    //    }

    //    [Test]
    //    public void HeapSortWithRandomIntegerArray()
    //    {
    //        int[] sortedIndices = new int[10] { 5, 2, 8, 6, 0, 4, 1, 7, 3, 9 };
    //        IlutpHeapSorter.SortIntegersDecreasing(sortedIndices);
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            Assert.AreEqual(sortedIndices.Length - 1 - i, sortedIndices[i], "#01-" + i.ToString());
    //        }
    //    }

    //    [Test]
    //    public void HeapSortWithDuplicateEntries()
    //    {
    //        int[] sortedIndices = new int[10] { 1, 1, 1, 1, 2, 2, 2, 2, 3, 4 };
    //        IlutpHeapSorter.SortIntegersDecreasing(sortedIndices);
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            if (i == 0)
    //            {
    //                Assert.AreEqual(4, sortedIndices[i], "#01-" + i.ToString());
    //            }
    //            else
    //            {
    //                if (i == 1)
    //                {
    //                    Assert.AreEqual(3, sortedIndices[i], "#01-" + i.ToString());
    //                }
    //                else
    //                {
    //                    if (i < 6)
    //                    {
    //                        if (sortedIndices[i] != 2)
    //                        {
    //                            Assert.Fail("#01-" + i.ToString());
    //                        }
    //                    }
    //                    else
    //                    {
    //                        if (sortedIndices[i] != 1)
    //                        {
    //                            Assert.Fail("#01-" + i.ToString());
    //                        }
    //                    }
    //                }
    //            }
    //        }
    //    }

    //    [Test]
    //    public void HeapSortWithSpecialConstructedIntegerArray()
    //    {
    //        int[] sortedIndices = new int[10] { 0, 0, 0, 0, 0, 1, 0, 0, 0, 0 };
    //        IlutpHeapSorter.SortIntegersDecreasing(sortedIndices);
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            if (i == 0)
    //            {
    //                Assert.AreEqual(1, sortedIndices[i], "#01-" + i.ToString());
    //                break;
    //            }
    //        }

    //        sortedIndices = new int[10] { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
    //        IlutpHeapSorter.SortIntegersDecreasing(sortedIndices);
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            if (i == 0)
    //            {
    //                Assert.AreEqual(1, sortedIndices[i], "#02-" + i.ToString());
    //                break;
    //            }
    //        }

    //        sortedIndices = new int[10] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };
    //        IlutpHeapSorter.SortIntegersDecreasing(sortedIndices);
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            if (i == 0)
    //            {
    //                Assert.AreEqual(1, sortedIndices[i], "#03-" + i.ToString());
    //                break;
    //            }
    //        }

    //        sortedIndices = new int[10] { 1, 1, 1, 0, 1, 1, 1, 1, 1, 1 };
    //        IlutpHeapSorter.SortIntegersDecreasing(sortedIndices);
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            if (i == 9)
    //            {
    //                Assert.AreEqual(0, sortedIndices[i], "#04-" + i.ToString());
    //                break;
    //            }
    //        }
    //    }

    //    [Test]
    //    public void HeapSortWithIncreasingDoubleArray()
    //    {
    //        int[] sortedIndices = new int[10];
    //        Vector values = VectorBuilder.CreateVector(10);
    //        values[0] = 0;
    //        values[1] = 1;
    //        values[2] = 2;
    //        values[3] = 3;
    //        values[4] = 4;
    //        values[5] = 5;
    //        values[6] = 6;
    //        values[7] = 7;
    //        values[8] = 8;
    //        values[9] = 9;
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            sortedIndices[i] = i;
    //        }

    //        IlutpHeapSorter.SortDoubleIndicesDecreasing(0, sortedIndices.Length - 1, sortedIndices, values);
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            Assert.AreEqual(sortedIndices.Length - 1 - i, sortedIndices[i], "#01-" + i.ToString());
    //        }
    //    }

    //    [Test]
    //    public void HeapSortWithDecreasingDoubleArray()
    //    {
    //        int[] sortedIndices = new int[10];
    //        Vector values = VectorBuilder.CreateVector(10);
    //        values[0] = 9;
    //        values[1] = 8;
    //        values[2] = 7;
    //        values[3] = 6;
    //        values[4] = 5;
    //        values[5] = 4;
    //        values[6] = 3;
    //        values[7] = 2;
    //        values[8] = 1;
    //        values[9] = 0;
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            sortedIndices[i] = i;
    //        }

    //        IlutpHeapSorter.SortDoubleIndicesDecreasing(0, sortedIndices.Length - 1, sortedIndices, values);
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            Assert.AreEqual(i, sortedIndices[i], "#01-" + i.ToString());
    //        }
    //    }

    //    [Test]
    //    public void HeapSortWithRandomDoubleArray()
    //    {
    //        int[] sortedIndices = new int[10];
    //        Vector values = VectorBuilder.CreateVector(10);
    //        values[0] = 5;
    //        values[1] = 2;
    //        values[2] = 8;
    //        values[3] = 6;
    //        values[4] = 0;
    //        values[5] = 4;
    //        values[6] = 1;
    //        values[7] = 7;
    //        values[8] = 3;
    //        values[9] = 9;
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            sortedIndices[i] = i;
    //        }

    //        IlutpHeapSorter.SortDoubleIndicesDecreasing(0, sortedIndices.Length - 1, sortedIndices, values);
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            switch (i)
    //            {
    //                case 0:
    //                    Assert.AreEqual(9, sortedIndices[i], "#01-" + i.ToString());
    //                    break;
    //                case 1:
    //                    Assert.AreEqual(2, sortedIndices[i], "#01-" + i.ToString());
    //                    break;
    //                case 2:
    //                    Assert.AreEqual(7, sortedIndices[i], "#01-" + i.ToString());
    //                    break;
    //                case 3:
    //                    Assert.AreEqual(3, sortedIndices[i], "#01-" + i.ToString());
    //                    break;
    //                case 4:
    //                    Assert.AreEqual(0, sortedIndices[i], "#01-" + i.ToString());
    //                    break;
    //                case 5:
    //                    Assert.AreEqual(5, sortedIndices[i], "#01-" + i.ToString());
    //                    break;
    //                case 6:
    //                    Assert.AreEqual(8, sortedIndices[i], "#01-" + i.ToString());
    //                    break;
    //                case 7:
    //                    Assert.AreEqual(1, sortedIndices[i], "#01-" + i.ToString());
    //                    break;
    //                case 8:
    //                    Assert.AreEqual(6, sortedIndices[i], "#01-" + i.ToString());
    //                    break;
    //                case 9:
    //                    Assert.AreEqual(4, sortedIndices[i], "#01-" + i.ToString());
    //                    break;
    //            }
    //        }
    //    }

    //    [Test]
    //    public void HeapSortWithDuplicateDoubleEntries()
    //    {
    //        int[] sortedIndices = new int[10];
    //        Vector values = VectorBuilder.CreateVector(10);
    //        values[0] = 1;
    //        values[1] = 1;
    //        values[2] = 1;
    //        values[3] = 1;
    //        values[4] = 2;
    //        values[5] = 2;
    //        values[6] = 2;
    //        values[7] = 2;
    //        values[8] = 3;
    //        values[9] = 4;

    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            sortedIndices[i] = i;
    //        }
    //        IlutpHeapSorter.SortDoubleIndicesDecreasing(0, sortedIndices.Length - 1, sortedIndices, values);
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            if (i == 0)
    //            {
    //                Assert.AreEqual(9, sortedIndices[i], "#01-" + i.ToString());
    //            }
    //            else
    //            {
    //                if (i == 1)
    //                {
    //                    Assert.AreEqual(8, sortedIndices[i], "#01-" + i.ToString());
    //                }
    //                else
    //                {
    //                    if (i < 6)
    //                    {
    //                        if ((sortedIndices[i] != 4) &&
    //                            (sortedIndices[i] != 5) &&
    //                            (sortedIndices[i] != 6) &&
    //                            (sortedIndices[i] != 7))
    //                        {
    //                            Assert.Fail("#01-" + i.ToString());
    //                        }
    //                    }
    //                    else
    //                    {
    //                        if ((sortedIndices[i] != 0) &&
    //                            (sortedIndices[i] != 1) &&
    //                            (sortedIndices[i] != 2) &&
    //                            (sortedIndices[i] != 3))
    //                        {
    //                            Assert.Fail("#01-" + i.ToString());
    //                        }
    //                    }
    //                }
    //            }
    //        }
    //    }

    //    [Test]
    //    public void HeapSortWithSpecialConstructedDoubleArray()
    //    {
    //        int[] sortedIndices = new int[10];
    //        Vector values = VectorBuilder.CreateVector(10);
    //        values[0] = 0;
    //        values[1] = 0;
    //        values[2] = 0;
    //        values[3] = 0;
    //        values[4] = 0;
    //        values[5] = 1;
    //        values[6] = 0;
    //        values[7] = 0;
    //        values[8] = 0;
    //        values[9] = 0;
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            sortedIndices[i] = i;
    //        }
    //        IlutpHeapSorter.SortDoubleIndicesDecreasing(0, sortedIndices.Length - 1, sortedIndices, values);
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            if (i == 0)
    //            {
    //                Assert.AreEqual(5, sortedIndices[i], "#01-" + i.ToString());
    //                break;
    //            }
    //        }

    //        values[0] = 1;
    //        values[1] = 0;
    //        values[2] = 0;
    //        values[3] = 0;
    //        values[4] = 0;
    //        values[5] = 0;
    //        values[6] = 0;
    //        values[7] = 0;
    //        values[8] = 0;
    //        values[9] = 0;
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            sortedIndices[i] = i;
    //        }
    //        IlutpHeapSorter.SortDoubleIndicesDecreasing(0, sortedIndices.Length - 1, sortedIndices, values);
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            if (i == 0)
    //            {
    //                Assert.AreEqual(0, sortedIndices[i], "#02-" + i.ToString());
    //                break;
    //            }
    //        }

    //        values[0] = 0;
    //        values[1] = 0;
    //        values[2] = 0;
    //        values[3] = 0;
    //        values[4] = 0;
    //        values[5] = 0;
    //        values[6] = 0;
    //        values[7] = 0;
    //        values[8] = 0;
    //        values[9] = 1;
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            sortedIndices[i] = i;
    //        }
    //        IlutpHeapSorter.SortDoubleIndicesDecreasing(0, sortedIndices.Length - 1, sortedIndices, values);
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            if (i == 0)
    //            {
    //                Assert.AreEqual(9, sortedIndices[i], "#03-" + i.ToString());
    //                break;
    //            }
    //        }

    //        values[0] = 1;
    //        values[1] = 1;
    //        values[2] = 1;
    //        values[3] = 0;
    //        values[4] = 1;
    //        values[5] = 1;
    //        values[6] = 1;
    //        values[7] = 1;
    //        values[8] = 1;
    //        values[9] = 1;
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            sortedIndices[i] = i;
    //        }
    //        IlutpHeapSorter.SortDoubleIndicesDecreasing(0, sortedIndices.Length - 1, sortedIndices, values);
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            if (i == 9)
    //            {
    //                Assert.AreEqual(3, sortedIndices[i], "#04-" + i.ToString());
    //                break;
    //            }
    //        }
    //    }

    //    [Test]
    //    public void HeapSortWithIncreasingDoubleArrayWithLowerBound()
    //    {
    //        int[] sortedIndices = new int[10];
    //        Vector values = VectorBuilder.CreateVector(10);
    //        values[0] = 0;
    //        values[1] = 1;
    //        values[2] = 2;
    //        values[3] = 3;
    //        values[4] = 4;
    //        values[5] = 5;
    //        values[6] = 6;
    //        values[7] = 7;
    //        values[8] = 8;
    //        values[9] = 9;
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            sortedIndices[i] = i;
    //        }

    //        IlutpHeapSorter.SortDoubleIndicesDecreasing(4, sortedIndices.Length - 1, sortedIndices, values);
    //        for (int i = 0; i < sortedIndices.Length - 4; i++)
    //        {
    //            Assert.AreEqual(sortedIndices.Length - 1 - i, sortedIndices[i], "#01-" + i.ToString());
    //        }
    //    }

    //    [Test]
    //    public void HeapSortWithIncreasingDoubleArrayWithUpperBound()
    //    {
    //        int[] sortedIndices = new int[10];
    //        Vector values = VectorBuilder.CreateVector(10);
    //        values[0] = 0;
    //        values[1] = 1;
    //        values[2] = 2;
    //        values[3] = 3;
    //        values[4] = 4;
    //        values[5] = 5;
    //        values[6] = 6;
    //        values[7] = 7;
    //        values[8] = 8;
    //        values[9] = 9;
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            sortedIndices[i] = i;
    //        }

    //        IlutpHeapSorter.SortDoubleIndicesDecreasing(0, sortedIndices.Length - 5, sortedIndices, values);
    //        for (int i = 0; i < sortedIndices.Length - 5; i++)
    //        {
    //            Assert.AreEqual(sortedIndices.Length - 5 - i, sortedIndices[i], "#01-" + i.ToString());
    //        }
    //    }

    //    [Test]
    //    public void HeapSortWithIncreasingDoubleArrayWithLowerAndUpperBound()
    //    {
    //        int[] sortedIndices = new int[10];
    //        Vector values = VectorBuilder.CreateVector(10);
    //        values[0] = 0;
    //        values[1] = 1;
    //        values[2] = 2;
    //        values[3] = 3;
    //        values[4] = 4;
    //        values[5] = 5;
    //        values[6] = 6;
    //        values[7] = 7;
    //        values[8] = 8;
    //        values[9] = 9;
    //        for (int i = 0; i < sortedIndices.Length; i++)
    //        {
    //            sortedIndices[i] = i;
    //        }

    //        IlutpHeapSorter.SortDoubleIndicesDecreasing(2, sortedIndices.Length - 3, sortedIndices, values);
    //        for (int i = 0; i < sortedIndices.Length - 4; i++)
    //        {
    //            Assert.AreEqual(sortedIndices.Length - 3 - i, sortedIndices[i], "#01-" + i.ToString());
    //        }
    //    }
    //}
}
