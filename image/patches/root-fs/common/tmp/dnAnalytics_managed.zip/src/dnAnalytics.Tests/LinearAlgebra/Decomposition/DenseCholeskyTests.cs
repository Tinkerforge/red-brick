﻿using dnAnalytics.LinearAlgebra;
using dnAnalytics.LinearAlgebra.IO;
using NUnit.Framework;

namespace dnAnalytics.Tests.LinearAlgebra.Decomposition
{
    [TestFixture]
    public class DenseCholeskyTests : CholeskyTests
    {
        protected override Matrix GetMatrix(string file)
        {
            MatrixMarketReader mmr = new MatrixMarketReader();
            return mmr.ReadMatrix(file, StorageType.Dense);
        }

        protected override Matrix GetMatrix(int size)
        {
            return new DenseMatrix(size);
        }

        protected override Matrix GetMatrix(int rows, int columns)
        {
            return new DenseMatrix(rows, columns);
        }

        protected override Matrix GetIdentityMatrix(int size)
        {
            DenseMatrix ret = new DenseMatrix(size);
            for (int i = 0; i < size; i++)
            {
                ret[i, i] = 1.0;
            }
            return ret;
        }

        protected override Vector GetVector(int size)
        {
            return new DenseVector(size);
        }
    }
}