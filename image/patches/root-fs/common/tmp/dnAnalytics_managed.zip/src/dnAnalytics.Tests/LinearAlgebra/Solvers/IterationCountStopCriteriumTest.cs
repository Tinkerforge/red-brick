/* Copyright 2007-2008 dnAnalytics Project.
 *
 * Contributors to this file:
 * Patrick van der Velde
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this 
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * * Neither the name of the dnAnalytics Project nor the names of its contributors
 *   may be used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

using System;
using System.Diagnostics;
using NUnit.Framework;
using dnAnalytics.LinearAlgebra.Solvers;
using dnAnalytics.LinearAlgebra;

namespace dnAnalytics.Tests.LinearAlgebra.Solvers
{
    [TestFixture]
    public sealed class IterationCountStopCriteriumTest
    {
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void CreateWithIllegalMinimumIterations()
        {
            IterationCountStopCriterium criterium = new IterationCountStopCriterium(-1);
            Assert.Fail();
        }

        [Test]
        public void Create()
        {
            IterationCountStopCriterium criterium = new IterationCountStopCriterium(10);
            Assert.IsNotNull(criterium, "A criterium should have been created");
        }

        [Test]
        public void ResetMaximumIterations()
        {
            IterationCountStopCriterium criterium = new IterationCountStopCriterium(10);
            Assert.IsNotNull(criterium, "A criterium should have been created");
            Assert.AreEqual(10, criterium.MaximumNumberOfIterations, "Incorrect maximum number of iterations");

            criterium.ResetMaximumNumberOfIterationsToDefault();
            Assert.AreNotEqual(10, criterium.MaximumNumberOfIterations, "Should have reset");
            Assert.AreEqual(IterationCountStopCriterium.DefaultMaximumNumberOfIterations, criterium.MaximumNumberOfIterations, "Reset to the wrong value");
        }

        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void DetermineStatusWithIllegalIterationNumber()
        {
            IterationCountStopCriterium criterium = new IterationCountStopCriterium(10);
            Assert.IsNotNull(criterium, "A criterium should have been created");

            criterium.DetermineStatus(-1, new DenseVector(3, 1), new DenseVector(3, 2), new DenseVector(3,3));
            Assert.Fail();
        }
        
        [Test]
        public void DetermineStatus()
        {
            IterationCountStopCriterium criterium = new IterationCountStopCriterium(10);
            Assert.IsNotNull(criterium, "A criterium should have been created");

            criterium.DetermineStatus(5, new DenseVector(3, 1), new DenseVector(3, 2), new DenseVector(3, 3));
            Assert.IsInstanceOfType(typeof(CalculationRunning), criterium.Status, "Should be running");

            criterium.DetermineStatus(10, new DenseVector(3, 1), new DenseVector(3, 2), new DenseVector(3, 3));
            Assert.IsInstanceOfType(typeof(CalculationStoppedWithoutConvergence), criterium.Status, "Should be finished");
        }

        [Test]
        public void ResetCalculationState()
        {
            IterationCountStopCriterium criterium = new IterationCountStopCriterium(10);
            Assert.IsNotNull(criterium, "A criterium should have been created");

            criterium.DetermineStatus(5, new DenseVector(3, 1), new DenseVector(3, 2), new DenseVector(3, 3));
            Assert.IsInstanceOfType(typeof(CalculationRunning), criterium.Status, "Should be running");

            criterium.ResetToPrecalculationState();
            Assert.IsInstanceOfType(typeof(CalculationIndetermined), criterium.Status, "Should not have started");
        }

        [Test]
        public void Clone()
        {
            IterationCountStopCriterium criterium = new IterationCountStopCriterium(10);
            Assert.IsNotNull(criterium, "A criterium should have been created");
            Assert.AreEqual(10, criterium.MaximumNumberOfIterations, "Incorrect maximum");

            IIterationStopCriterium clone = criterium.Clone();
            Assert.IsInstanceOfType(typeof(IterationCountStopCriterium), clone, "Wrong criterium type");

            IterationCountStopCriterium clonedCriterium = clone as IterationCountStopCriterium;
            Assert.AreEqual(criterium.MaximumNumberOfIterations, clonedCriterium.MaximumNumberOfIterations, "Clone failed");
        }
    }
}
