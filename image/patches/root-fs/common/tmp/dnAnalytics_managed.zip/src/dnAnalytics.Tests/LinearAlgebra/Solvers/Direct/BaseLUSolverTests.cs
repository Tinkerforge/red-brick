﻿using dnAnalytics.LinearAlgebra;
using dnAnalytics.LinearAlgebra.IO;
using NUnit.Framework;

namespace dnAnalytics.Tests.LinearAlgebra.Solvers.Direct
{
    [TestFixture]
    public class BaseLUSolverTests : LUSolverTests
    {
        protected override Matrix GetMatrix(string file)
        {
            MatrixMarketReader mmr = new MatrixMarketReader();
            return new BaseMatrix(mmr.ReadMatrix(file, StorageType.Dense));
        }

        protected override Vector GetVector(int count)
        {
            return new BaseVector(count);
        }

        protected override Matrix GetIdentityMatrix(int size)
        {
            Matrix ret = new BaseMatrix(size);
            for (int i = 0; i < size; i++)
            {
                ret[i, i] = 1.0;
            }
            return ret;
        }
    }
}