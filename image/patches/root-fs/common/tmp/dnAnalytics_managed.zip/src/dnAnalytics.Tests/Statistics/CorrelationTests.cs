﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using dnAnalytics.Statistics;
using dnAnalytics.LinearAlgebra;

namespace dnAnalytics.Tests.Statistics
{
    [TestFixture]
    public class CorrelationTests
    {
        private readonly IDictionary<string, StatTestData> mData = new Dictionary<string, StatTestData>();
        public CorrelationTests()
        {
            StatTestData lottery = new StatTestData("./TestData/NIST/Lottery.dat");
            mData.Add("lottery", lottery);
            StatTestData lew = new StatTestData("./TestData/NIST/Lew.dat");
            mData.Add("lew", lew);
        }

        [Test]
        public void PearsonCorrelationTest()
        {
            Vector dataA = mData["lottery"].Data.GetSubVector(0, 200);
            Vector dataB = mData["lew"].Data.GetSubVector(0, 200);

            double corr = dnAnalytics.Statistics.Correlation.Pearson(dataA, dataB);
            TestHelper.TestSignificantDigits(corr, -0.029470861580726, 13);
        }

        [Test]
        public void PearsonCorrelationTest_Fail()
        {
            Vector dataA = mData["lottery"].Data;
            Vector dataB = mData["lew"].Data;

            Assert.Throws<ArgumentOutOfRangeException>(() => dnAnalytics.Statistics.Correlation.Pearson(dataA, dataB));
        }
    }
}
