﻿using dnAnalytics.Random;
using NUnit.Framework;

namespace dnAnalytics.Tests.Random
{
    [TestFixture]
    public class WH2006Tests : RandomTests
    {
        public WH2006Tests()
            : base(typeof(WH2006))
        {
        }
    }
}