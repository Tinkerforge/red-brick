using System.IO;
using dnAnalytics.LinearAlgebra;
using dnAnalytics.LinearAlgebra.IO;
using NUnit.Framework;

namespace dnAnalytics.Tests.LinearAlgebra.IO
{
    [TestFixture]
    public class DelimitedMatrixReaderTest
    {
        [Test]
        public void ReadMatrixString()
        {
            //white space
            DelimitedMatrixReader dmr = new DelimitedMatrixReader();
            Matrix matrix = dmr.ReadMatrix("./TestData/Matrices/random_real_general_dense_10_20.space", StorageType.Dense);
            Assert.AreEqual(10, matrix.Rows);
            Assert.AreEqual(20, matrix.Columns);
            double expected = 767.35692;
            double actual = matrix.FrobeniusNorm();
            double error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);

            //tabs
            dmr = new DelimitedMatrixReader("\t+");
            matrix = dmr.ReadMatrix("./TestData/Matrices/random_real_general_dense_10_20.tab", StorageType.Dense);
            Assert.AreEqual(10, matrix.Rows);
            Assert.AreEqual(20, matrix.Columns);
            actual = matrix.FrobeniusNorm();
            error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);

            dmr = new DelimitedMatrixReader(",");
            matrix = dmr.ReadMatrix("./TestData/Matrices/random_real_general_dense_10_20.comma", StorageType.Dense);
            Assert.AreEqual(10, matrix.Rows);
            Assert.AreEqual(20, matrix.Columns);
            actual = matrix.FrobeniusNorm();
            error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);
        }

        [Test]
        public void ReadMatrixStream()
        {
            //white space
            DelimitedMatrixReader dmr = new DelimitedMatrixReader();
            Matrix matrix = dmr.ReadMatrix(File.OpenRead("./TestData/Matrices/random_real_general_dense_10_20.space"), StorageType.Dense);
            Assert.AreEqual(10, matrix.Rows);
            Assert.AreEqual(20, matrix.Columns);
            double expected = 767.35692;
            double actual = matrix.FrobeniusNorm();
            double error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);

            //tabs
            dmr = new DelimitedMatrixReader("\t+");
            matrix = dmr.ReadMatrix(File.OpenRead("./TestData/Matrices/random_real_general_dense_10_20.tab"), StorageType.Dense);
            Assert.AreEqual(10, matrix.Rows);
            Assert.AreEqual(20, matrix.Columns);
            actual = matrix.FrobeniusNorm();
            error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);

            //commas
            dmr = new DelimitedMatrixReader(",");
            matrix = dmr.ReadMatrix(File.OpenRead("./TestData/Matrices/random_real_general_dense_10_20.comma"), StorageType.Dense);
            Assert.AreEqual(10, matrix.Rows);
            Assert.AreEqual(20, matrix.Columns);
            actual = matrix.FrobeniusNorm();
            error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);
        }
    }
}