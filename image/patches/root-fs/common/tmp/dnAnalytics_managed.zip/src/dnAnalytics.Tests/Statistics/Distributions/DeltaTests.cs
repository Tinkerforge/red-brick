using dnAnalytics.Statistics.Distributions;
using NUnit.Framework;

namespace dnAnalytics.Tests.Statistics.Distributions
{
    [TestFixture]
    public class DeltaTests
    {
        private const double mAcceptableError = 1e-12;

        [Test]
        public void Delta()
        {
            Delta delta = new Delta(0.3);

            Assert.AreEqual(0.3, delta.Mean);
            Assert.AreEqual(0.0, delta.StdDev);
            Assert.AreEqual(0.0, delta.Variance);
            Assert.AreEqual(0.0, delta.Entropy);
            Assert.AreEqual(0.3, delta.Mode);
            Assert.AreEqual(0.3, delta.Median);

            Assert.AreEqual(0.0, delta.Density(0.0));
            Assert.AreEqual(System.Double.PositiveInfinity, delta.Density(0.3));

            Assert.AreEqual(0.0, delta.CumulativeDistribution(0.0));
            Assert.AreEqual(1.0, delta.CumulativeDistribution(0.3));
            Assert.AreEqual(1.0, delta.CumulativeDistribution(0.3));

            Assert.AreEqual(0.3, delta.Sample());
            Assert.AreEqual(new double[2] {0.3, 0.3}, delta.Sample(2));
        }

        [Test]
        public void GetSetRNG()
        {
            Delta delta = new Delta(0.3);

            // Try getting the random number generator.
            System.Random rnd = delta.RandomNumberGenerator;
            // Try setting the random number generator.
            delta.RandomNumberGenerator = new System.Random();
        }
    }
}