﻿using dnAnalytics.Math;
using NUnit.Framework;

namespace dnAnalytics.Tests.Math
{
    [TestFixture]
    public class ComplexMath_AtanhTest32
    {
        [Test]
        public void Atanh()
        {
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(0.0f, 1.19209289550780998537e-7f)), new Complex32(0.0f, 1.19209289550780433848e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(0.0f, -1.19209289550780998537e-7f)), new Complex32(0.0f, -1.19209289550780433848e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(0.0f, 5.0e-1f)), new Complex32(0.0f, 4.63647609000806116214e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(0.0f, -5.0e-1f)), new Complex32(0.0f, -4.63647609000806116214e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(0.0f, 1.0f)), new Complex32(0.0f, 7.85398163397448309616e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(0.0f, -1.0f)), new Complex32(0.0f, -7.85398163397448309616e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(0.0f, 2.0f)), new Complex32(0.0f, 1.10714871779409050302f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(0.0f, -2.0f)), new Complex32(0.0f, -1.10714871779409050302f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(0.0f, 8.388608e6f)), new Complex32(0.0f, 1.57079620758560706845f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(0.0f, -8.388608e6f)), new Complex32(0.0f, -1.57079620758560706845f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(1.19209289550780998537e-7f, 0.0f)), new Complex32(1.19209289550781563226e-7f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-1.19209289550780998537e-7f, 0.0f)), new Complex32(-1.19209289550781563226e-7f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(1.19209289550780998537e-7f, 1.19209289550780998537e-7f)), new Complex32(1.1920928955077986916e-7f, 1.19209289550782127914e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(1.19209289550780998537e-7f, -1.19209289550780998537e-7f)), new Complex32(1.1920928955077986916e-7f, -1.19209289550782127914e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-1.19209289550780998537e-7f, 1.19209289550780998537e-7f)), new Complex32(-1.1920928955077986916e-7f, 1.19209289550782127914e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-1.19209289550780998537e-7f, -1.19209289550780998537e-7f)), new Complex32(-1.1920928955077986916e-7f, -1.19209289550782127914e-7f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(1.19209289550780998537e-7f, 5.0e-1f)), new Complex32(9.53674316406248711098e-8f, 4.63647609000810663688e-1f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(1.19209289550780998537e-7f, -5.0e-1f)), new Complex32(9.53674316406248711098e-8f, -4.63647609000810663688e-1f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(-1.19209289550780998537e-7f, 5.0e-1f)), new Complex32(-9.53674316406248711098e-8f, 4.63647609000810663688e-1f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(-1.19209289550780998537e-7f, -5.0e-1f)), new Complex32(-9.53674316406248711098e-8f, -4.63647609000810663688e-1f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(-1.19209289550780998537e-7f, 1.0f)), new Complex32(-5.96046447753903580964e-8f, 7.85398163397451862329e-1f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(-1.19209289550780998537e-7f, -1.0f)), new Complex32(-5.96046447753903580964e-8f, -7.85398163397451862329e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(1.19209289550780998537e-7f, 2.0f)), new Complex32(2.38418579101561500148e-8f, 1.10714871779409163989f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(1.19209289550780998537e-7f, -2.0f)), new Complex32(2.38418579101561500148e-8f, -1.10714871779409163989f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-1.19209289550780998537e-7f, 2.0f)), new Complex32(-2.38418579101561500148e-8f, 1.10714871779409163989f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-1.19209289550780998537e-7f, -2.0f)), new Complex32(-2.38418579101561500148e-8f, -1.10714871779409163989f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(1.19209289550780998537e-7f, 8.388608e6f)), new Complex32(1.69406589450857303051e-21f, 1.57079620758560706845f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(1.19209289550780998537e-7f, -8.388608e6f)), new Complex32(1.69406589450857303051e-21f, -1.57079620758560706845f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-1.19209289550780998537e-7f, 8.388608e6f)), new Complex32(-1.69406589450857303051e-21f, 1.57079620758560706845f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-1.19209289550780998537e-7f, -8.388608e6f)), new Complex32(-1.69406589450857303051e-21f, -1.57079620758560706845f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(5.0e-1f, 0.0f)), new Complex32(5.49306144334054845698e-1f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-5.0e-1f, 0.0f)), new Complex32(-5.49306144334054845698e-1f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(5.0e-1f, 1.19209289550780998537e-7f)), new Complex32(5.49306144334042213827e-1f, 1.58945719401038988971e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(5.0e-1f, -1.19209289550780998537e-7f)), new Complex32(5.49306144334042213827e-1f, -1.58945719401038988971e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-5.0e-1f, 1.19209289550780998537e-7f)), new Complex32(-5.49306144334042213827e-1f, 1.58945719401038988971e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-5.0e-1f, -1.19209289550780998537e-7f)), new Complex32(-5.49306144334042213827e-1f, -1.58945719401038988971e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(5.0e-1f, 5.0e-1f)), new Complex32(4.0235947810852509365e-1f, 5.53574358897045251509e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(5.0e-1f, -5.0e-1f)), new Complex32(4.0235947810852509365e-1f, -5.53574358897045251509e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-5.0e-1f, 5.0e-1f)), new Complex32(-4.0235947810852509365e-1f, 5.53574358897045251509e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-5.0e-1f, -5.0e-1f)), new Complex32(-4.0235947810852509365e-1f, -5.53574358897045251509e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(5.0e-1f, 1.0f)), new Complex32(2.38877861256859090363e-1f, 8.47575660670829027131e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(5.0e-1f, -1.0f)), new Complex32(2.38877861256859090363e-1f, -8.47575660670829027131e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-5.0e-1f, 1.0f)), new Complex32(-2.38877861256859090363e-1f, 8.47575660670829027131e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-5.0e-1f, -1.0f)), new Complex32(-2.38877861256859090363e-1f, -8.47575660670829027131e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(5.0e-1f, 2.0f)), new Complex32(9.6415620202996167238e-2f, 1.12655644083482234874f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(5.0e-1f, -2.0f)), new Complex32(9.6415620202996167238e-2f, -1.12655644083482234874f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-5.0e-1f, 2.0f)), new Complex32(-9.6415620202996167238e-2f, 1.12655644083482234874f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-5.0e-1f, -2.0f)), new Complex32(-9.6415620202996167238e-2f, -1.12655644083482234874f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(5.0e-1f, 8.388608e6f)), new Complex32(7.10542735760087564097e-15f, 1.57079620758560706845f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(5.0e-1f, -8.388608e6f)), new Complex32(7.10542735760087564097e-15f, -1.57079620758560706845f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-5.0e-1f, 8.388608e6f)), new Complex32(-7.10542735760087564097e-15f, 1.57079620758560706845f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-5.0e-1f, -8.388608e6f)), new Complex32(-7.10542735760087564097e-15f, -1.57079620758560706845f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(1.0f, 1.19209289550780998537e-7f)), new Complex32(8.3177661667193456559f, 7.85398193199770697311e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(1.0f, -1.19209289550780998537e-7f)), new Complex32(8.3177661667193456559f, -7.85398193199770697311e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-1.0f, 1.19209289550780998537e-7f)), new Complex32(-8.3177661667193456559f, 7.85398193199770697311e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-1.0f, -1.19209289550780998537e-7f)), new Complex32(-8.3177661667193456559f, -7.85398193199770697311e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(1.0f, 5.0e-1f)), new Complex32(7.08303336014054020062e-1f, 9.07887494960880386702e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(1.0f, -5.0e-1f)), new Complex32(7.08303336014054020062e-1f, -9.07887494960880386702e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-1.0f, 5.0e-1f)), new Complex32(-7.08303336014054020062e-1f, 9.07887494960880386702e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-1.0f, -5.0e-1f)), new Complex32(-7.08303336014054020062e-1f, -9.07887494960880386702e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(1.0f, 1.0f)), new Complex32(4.0235947810852509365e-1f, 1.01722196789785136772f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(1.0f, -1.0f)), new Complex32(4.0235947810852509365e-1f, -1.01722196789785136772f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-1.0f, 1.0f)), new Complex32(-4.0235947810852509365e-1f, 1.01722196789785136772f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-1.0f, -1.0f)), new Complex32(-4.0235947810852509365e-1f, -1.01722196789785136772f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(1.0f, 2.0f)), new Complex32(1.73286795139986327354e-1f, 1.17809724509617246442f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(1.0f, -2.0f)), new Complex32(1.73286795139986327354e-1f, -1.17809724509617246442f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-1.0f, 2.0f)), new Complex32(-1.73286795139986327354e-1f, 1.17809724509617246442f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-1.0f, -2.0f)), new Complex32(-1.73286795139986327354e-1f, -1.17809724509617246442f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(1.0f, 8.388608e6f)), new Complex32(1.42108547152015998206e-14f, 1.57079620758560706845f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(1.0f, -8.388608e6f)), new Complex32(1.42108547152015998206e-14f, -1.57079620758560706845f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-1.0f, 8.388608e6f)), new Complex32(-1.42108547152015998206e-14f, 1.57079620758560706845f), 6);
            //            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(-1.0f, -8.388608e6f)), new Complex32(-1.42108547152015998206e-14f, -1.57079620758560706845f), 6);
            //TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(-2.0f, 0.0f)), new Complex32(-5.49306144334054845698e-1f, 1.57079632679489661923f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(2.0f, 1.19209289550780998537e-7f)), new Complex32(5.4930614433405168773e-1f, 1.57079628705846676897f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(2.0f, -1.19209289550780998537e-7f)), new Complex32(5.4930614433405168773e-1f, -1.57079628705846676897f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-2.0f, 1.19209289550780998537e-7f)), new Complex32(-5.4930614433405168773e-1f, 1.57079628705846676897f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-2.0f, -1.19209289550780998537e-7f)), new Complex32(-5.4930614433405168773e-1f, -1.57079628705846676897f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(2.0f, 5.0e-1f)), new Complex32(5.00370000052531017442e-1f, 1.42154686100180698026f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(2.0f, -5.0e-1f)), new Complex32(5.00370000052531017442e-1f, -1.42154686100180698026f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-2.0f, 5.0e-1f)), new Complex32(-5.00370000052531017442e-1f, 1.42154686100180698026f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-2.0f, -5.0e-1f)), new Complex32(-5.00370000052531017442e-1f, -1.42154686100180698026f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(2.0f, 1.0f)), new Complex32(4.0235947810852509365e-1f, 1.33897252229449356112f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(2.0f, -1.0f)), new Complex32(4.0235947810852509365e-1f, -1.33897252229449356112f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-2.0f, 1.0f)), new Complex32(-4.0235947810852509365e-1f, 1.33897252229449356112f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-2.0f, -1.0f)), new Complex32(-4.0235947810852509365e-1f, -1.33897252229449356112f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(2.0f, 2.0f)), new Complex32(2.38877861256859090363e-1f, 1.31122326967163514335f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(2.0f, -2.0f)), new Complex32(2.38877861256859090363e-1f, -1.31122326967163514335f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-2.0f, 2.0f)), new Complex32(-2.38877861256859090363e-1f, 1.31122326967163514335f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-2.0f, -2.0f)), new Complex32(-2.38877861256859090363e-1f, -1.31122326967163514335f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(2.0f, 8.388608e6f)), new Complex32(2.84217094304019879509e-14f, 1.57079620758560706846f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(2.0f, -8.388608e6f)), new Complex32(2.84217094304019879509e-14f, -1.57079620758560706846f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-2.0f, 8.388608e6f)), new Complex32(-2.84217094304019879509e-14f, 1.57079620758560706846f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Atanh(new Complex32(-2.0f, -8.388608e6f)), new Complex32(-2.84217094304019879509e-14f, -1.57079620758560706846f), 6);
            //TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(-8.388608e6f, 0.0f)), new Complex32(-1.19209289550781814689e-7f, 1.57079632679489661923f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(8.388608e6f, 1.19209289550780998537e-7f)), new Complex32(1.19209289550781814689e-7f, 1.57079632679489661923f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(8.388608e6f, -1.19209289550780998537e-7f)), new Complex32(1.19209289550781814689e-7f, -1.57079632679489661923f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(-8.388608e6f, 1.19209289550780998537e-7f)), new Complex32(-1.19209289550781814689e-7f, 1.57079632679489661923f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(-8.388608e6f, -1.19209289550780998537e-7f)), new Complex32(-1.19209289550781814689e-7f, -1.57079632679489661923f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(8.388608e6f, 5.0e-1f)), new Complex32(1.19209289550781391172e-7f, 1.5707963267948895138f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(8.388608e6f, -5.0e-1f)), new Complex32(1.19209289550781391172e-7f, -1.5707963267948895138f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(-8.388608e6f, 5.0e-1f)), new Complex32(-1.19209289550781391172e-7f, 1.5707963267948895138f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(-8.388608e6f, -5.0e-1f)), new Complex32(-1.19209289550781391172e-7f, -1.5707963267948895138f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(8.388608e6f, 1.0f)), new Complex32(1.19209289550780120623e-7f, 1.57079632679488240838f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(8.388608e6f, -1.0f)), new Complex32(1.19209289550780120623e-7f, -1.57079632679488240838f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(-8.388608e6f, 1.0f)), new Complex32(-1.19209289550780120623e-7f, 1.57079632679488240838f), 6);
            //TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(-8.388608e6f, -1.0f)), new Complex32(-1.19209289550780120623e-7f, -1.57079632679488240838f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(8.388608e6f, 2.0f)), new Complex32(1.19209289550775038425e-7f, 1.57079632679486819752f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(8.388608e6f, -2.0f)), new Complex32(1.19209289550775038425e-7f, -1.57079632679486819752f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(-8.388608e6f, 2.0f)), new Complex32(-1.19209289550775038425e-7f, 1.57079632679486819752f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(-8.388608e6f, -2.0f)), new Complex32(-1.19209289550775038425e-7f, -1.57079632679486819752f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(8.388608e6f, 8.388608e6f)), new Complex32(5.96046447753904838278e-8f, 1.57079626719025184384f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(8.388608e6f, -8.388608e6f)), new Complex32(5.96046447753904838278e-8f, -1.57079626719025184384f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(-8.388608e6f, 8.388608e6f)), new Complex32(-5.96046447753904838278e-8f, 1.57079626719025184384f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Atanh(new Complex32(-8.388608e6f, -8.388608e6f)), new Complex32(-5.96046447753904838278e-8f, -1.57079626719025184384f), 6);
        }
    }
}