using dnAnalytics.Statistics.Distributions;
using NUnit.Framework;

namespace dnAnalytics.Tests.Statistics.Distributions
{
    [TestFixture]
    public class DirichletTests
    {
        private const double mAcceptableError = 1e-12;

        [Test]
        public void SymmetricDirichlet()
        {
            Dirichlet d = new Dirichlet(0.3, 5);

            for (int i = 0; i < 5; i++)
            {
                Assert.AreEqual(0.3, d.Mean[i], mAcceptableError);
                Assert.AreEqual(0.3 * (1.5 - 0.3) / (1.5 * 1.5 * 2.5), d.Variance[i], mAcceptableError);
            }
        }

        [Test]
        public void GetSetRNG()
        {
            Dirichlet d = new Dirichlet(0.3, 5);

            // Try getting the random number generator.
            System.Random rnd = d.RandomNumberGenerator;
            // Try setting the random number generator.
            d.RandomNumberGenerator = new System.Random();
        }
    }
}