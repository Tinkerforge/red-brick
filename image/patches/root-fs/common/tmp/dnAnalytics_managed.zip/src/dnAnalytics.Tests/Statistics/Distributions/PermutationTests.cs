using dnAnalytics.Statistics.Distributions;
using NUnit.Framework;

namespace dnAnalytics.Tests.Statistics.Distributions
{
    [TestFixture]
    public class PermutationTests
    {
        private const double mAcceptableError = 1e-12;

        [Test]
        public void Permutation()
        {
            Permutation perm = new Permutation(5);
        }

        [Test]
        public void GetSetRNG()
        {
            Permutation perm = new Permutation(5);

            // Try getting the random number generator.
            System.Random rnd = perm.RandomNumberGenerator;
            // Try setting the random number generator.
            perm.RandomNumberGenerator = new System.Random();
        }

        [Test]
        public void Sample()
        {
            Permutation perm = new Permutation(5);
            int[] sample = perm.Sample();

            Assert.AreEqual(sample.Length, 5);
        }
    }
}