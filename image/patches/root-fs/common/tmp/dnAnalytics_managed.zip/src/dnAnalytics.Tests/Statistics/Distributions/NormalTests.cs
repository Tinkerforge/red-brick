using dnAnalytics.Statistics.Distributions;
using NUnit.Framework;

namespace dnAnalytics.Tests.Statistics.Distributions
{
    [TestFixture]
    public class NormalTests
    {
        private const double mAcceptableError = 1e-12;

        [Test]
        public void StandardNormal()
        {
            Normal normal = new Normal();

            Assert.AreEqual(0.0, normal.Mean, mAcceptableError);
            Assert.AreEqual(1.0, normal.StdDev, mAcceptableError);
            Assert.AreEqual(1.0, normal.Variance, mAcceptableError);
            Assert.AreEqual(0.0, normal.Mode, mAcceptableError);
            Assert.AreEqual(0.0, normal.Median, mAcceptableError);
            Assert.AreEqual(1.4189385332046727417803297364056, normal.Entropy, mAcceptableError);

            Assert.AreEqual(0.398942280401432, normal.Density(0.0), mAcceptableError);

            Assert.AreEqual(0.5, normal.CumulativeDistribution(0.0), mAcceptableError);

            Assert.AreEqual(0.0, normal.InverseCumulativeDistribution(0.5), mAcceptableError);
        }

        [Test]
        public void GetSetRNG()
        {
            Normal normal = new Normal();

            // Try getting the random number generator.
            System.Random rnd = normal.RandomNumberGenerator;
            // Try setting the random number generator.
            normal.RandomNumberGenerator = new System.Random();
        }
    }
}