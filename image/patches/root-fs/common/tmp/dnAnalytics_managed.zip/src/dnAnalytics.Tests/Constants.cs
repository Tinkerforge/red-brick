namespace dnAnalytics.Tests
{
    internal class Constants
    {
        //the L1 Norm Condition number is just an estimate, not an exact result.
        public const double AcceptableL1normConditionNumberError = 1e-5;

        // Cholesky solve can have a large error.
        public const double AcceptableCholeskySolveError = 1e-3;

        public const double AcceptableError = 1e-10;
        public const float AcceptableError32 = 1e-6f;
        public const double IOAcceptableError = 1e-5;
    }
}
