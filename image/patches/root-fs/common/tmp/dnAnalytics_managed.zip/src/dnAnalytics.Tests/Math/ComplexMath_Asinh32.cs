﻿using dnAnalytics.Math;
using NUnit.Framework;

namespace dnAnalytics.Tests.Math
{
    [TestFixture]
    public class ComplexMath_Asinh32Test
    {
        [Test]
        public void Asinh()
        {
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(0.0f, 1.19209289550780998537e-7f)), new Complex32(0.0f, 1.19209289550781280881e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(0.0f, -1.19209289550780998537e-7f)), new Complex32(0.0f, -1.19209289550781280881e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(0.0f, 5.0e-1f)), new Complex32(0.0f, 5.23598775598298873077e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(0.0f, -5.0e-1f)), new Complex32(0.0f, -5.23598775598298873077e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(0.0f, 1.0f)), new Complex32(0.0f, 1.57079632679489661923f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(0.0f, -1.0f)), new Complex32(0.0f, -1.57079632679489661923f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(0.0f, 2.0f)), new Complex32(1.31695789692481670863f, 1.57079632679489661923f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Asinh(new Complex32(1.19209289550780998537e-7f, 0.0f)), new Complex32(1.19209289550780716193e-7f, 0.0f), 6);
            //TestHelper.TestLogRelativeError(ComplexMath.Asinh(new Complex32(-1.19209289550780998537e-7f, 0.0f)), new Complex32(-1.19209289550780716193e-7f, 0.0f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Asinh(new Complex32(1.19209289550780998537e-7f, 1.19209289550780998537e-7f)), new Complex32(1.19209289550781563226e-7f, 1.19209289550780433848e-7f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Asinh(new Complex32(1.19209289550780998537e-7f, -1.19209289550780998537e-7f)), new Complex32(1.19209289550781563226e-7f, -1.19209289550780433848e-7f), 6);
  //          TestHelper.TestLogRelativeError(ComplexMath.Asinh(new Complex32(-1.19209289550780998537e-7f, 1.19209289550780998537e-7f)), new Complex32(-1.19209289550781563226e-7f, 1.19209289550780433848e-7f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Asinh(new Complex32(-1.19209289550780998537e-7f, -1.19209289550780998537e-7f)), new Complex32(-1.19209289550781563226e-7f, -1.19209289550780433848e-7f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Asinh(new Complex32(1.19209289550780998537e-7f, 5.0e-1f)), new Complex32(1.37651030824094033271e-7f, 5.23598775598293403317e-1f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Asinh(new Complex32(1.19209289550780998537e-7f, -5.0e-1f)), new Complex32(1.37651030824094033271e-7f, -5.23598775598293403317e-1f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Asinh(new Complex32(-1.19209289550780998537e-7f, 5.0e-1f)), new Complex32(-1.37651030824094033271e-7f, 5.23598775598293403317e-1f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Asinh(new Complex32(-1.19209289550780998537e-7f, -5.0e-1f)), new Complex32(-1.37651030824094033271e-7f, -5.23598775598293403317e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-1.19209289550780998537e-7f, 1.0f)), new Complex32(-3.45266986431162764654e-4f, 1.57045105981532529509f), 4);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-1.19209289550780998537e-7f, -1.0f)), new Complex32(-3.45266986431162764654e-4f, -1.57045105981532529509f), 4);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(1.19209289550780998537e-7f, 2.0f)), new Complex32(1.31695789692481944351f, 1.57079625796938120718f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(1.19209289550780998537e-7f, -2.0f)), new Complex32(1.31695789692481944351f, -1.57079625796938120718f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-1.19209289550780998537e-7f, 2.0f)), new Complex32(-1.31695789692481944351f, 1.57079625796938120718f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-1.19209289550780998537e-7f, -2.0f)), new Complex32(-1.31695789692481944351f, -1.57079625796938120718f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-1.19209289550780998537e-7f, 8.388608e6f)), new Complex32(-1.66355323334386838733e1f, 1.57079632679488240838f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-1.19209289550780998537e-7f, -8.388608e6f)), new Complex32(-1.66355323334386838733e1f, -1.57079632679488240838f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(5.0e-1f, 0.0f)), new Complex32(4.81211825059603447498e-1f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-5.0e-1f, 0.0f)), new Complex32(-4.81211825059603447498e-1f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(5.0e-1f, 1.19209289550780998537e-7f)), new Complex32(4.81211825059605989613e-1f, 1.06624029994000753133e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(5.0e-1f, -1.19209289550780998537e-7f)), new Complex32(4.81211825059605989613e-1f, -1.06624029994000753133e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-5.0e-1f, 1.19209289550780998537e-7f)), new Complex32(-4.81211825059605989613e-1f, 1.06624029994000753133e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-5.0e-1f, -1.19209289550780998537e-7f)), new Complex32(-4.81211825059605989613e-1f, -1.06624029994000753133e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(5.0e-1f, 5.0e-1f)), new Complex32(5.30637530952517826017e-1f, 4.52278447151190682064e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(5.0e-1f, -5.0e-1f)), new Complex32(5.30637530952517826017e-1f, -4.52278447151190682064e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-5.0e-1f, 5.0e-1f)), new Complex32(-5.30637530952517826017e-1f, 4.52278447151190682064e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-5.0e-1f, -5.0e-1f)), new Complex32(-5.30637530952517826017e-1f, -4.52278447151190682064e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(5.0e-1f, 1.0f)), new Complex32(7.32857675973645260889e-1f, 8.95907481208890239067e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(5.0e-1f, -1.0f)), new Complex32(7.32857675973645260889e-1f, -8.95907481208890239067e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-5.0e-1f, 1.0f)), new Complex32(-7.32857675973645260889e-1f, 8.95907481208890239067e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-5.0e-1f, -1.0f)), new Complex32(-7.32857675973645260889e-1f, -8.95907481208890239067e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(5.0e-1f, 2.0f)), new Complex32(1.36180090085784578821f, 1.29304207023718265905f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(5.0e-1f, -2.0f)), new Complex32(1.36180090085784578821f, -1.29304207023718265905f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-5.0e-1f, 2.0f)), new Complex32(-1.36180090085784578821f, 1.29304207023718265905f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-5.0e-1f, -2.0f)), new Complex32(-1.36180090085784578821f, -1.29304207023718265905f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-5.0e-1f, 8.388608e6f)), new Complex32(-1.66355323334386856497e1f, 1.57079626719025184384f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-5.0e-1f, -8.388608e6f)), new Complex32(-1.66355323334386856497e1f, -1.57079626719025184384f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(1.0f, 0.0f)), new Complex32(8.81373587019543025233e-1f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-1.0f, 0.0f)), new Complex32(-8.81373587019543025233e-1f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(1.0f, 1.19209289550780998537e-7f)), new Complex32(8.81373587019545537381e-1f, 8.42936970217878358509e-8f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(1.0f, -1.19209289550780998537e-7f)), new Complex32(8.81373587019545537381e-1f, -8.42936970217878358509e-8f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-1.0f, 1.19209289550780998537e-7f)), new Complex32(-8.81373587019545537381e-1f, 8.42936970217878358509e-8f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-1.0f, -1.19209289550780998537e-7f)), new Complex32(-8.81373587019545537381e-1f, -8.42936970217878358509e-8f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-1.0f, 5.0e-1f)), new Complex32(-9.2613303135018242455e-1f, 3.49439062857213293627e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-1.0f, -5.0e-1f)), new Complex32(-9.2613303135018242455e-1f, -3.49439062857213293627e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(1.0f, 1.0f)), new Complex32(1.06127506190503565203f, 6.66239432492515255104e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(1.0f, -1.0f)), new Complex32(1.06127506190503565203f, -6.66239432492515255104e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-1.0f, 1.0f)), new Complex32(-1.06127506190503565203f, 6.66239432492515255104e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-1.0f, -1.0f)), new Complex32(-1.06127506190503565203f, -6.66239432492515255104e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(1.0f, 2.0f)), new Complex32(1.46935174436818527326f, 1.06344002357775205619f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(1.0f, -2.0f)), new Complex32(1.46935174436818527326f, -1.06344002357775205619f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-1.0f, 2.0f)), new Complex32(-1.46935174436818527326f, 1.06344002357775205619f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-1.0f, -2.0f)), new Complex32(-1.46935174436818527326f, -1.06344002357775205619f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-1.0f, 8.388608e6f)), new Complex32(-1.66355323334386909787e1f, 1.57079620758560706845f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-1.0f, -8.388608e6f)), new Complex32(-1.66355323334386909787e1f, -1.57079620758560706845f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(2.0f, 0.0f)), new Complex32(1.44363547517881034249f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-2.0f, 0.0f)), new Complex32(-1.44363547517881034249f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(2.0f, 1.19209289550780998537e-7f)), new Complex32(1.44363547517881161355f, 5.33120149970003008054e-8f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(2.0f, -1.19209289550780998537e-7f)), new Complex32(1.44363547517881161355f, -5.33120149970003008054e-8f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-2.0f, 1.19209289550780998537e-7f)), new Complex32(-1.44363547517881161355f, 5.33120149970003008054e-8f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-2.0f, -1.19209289550780998537e-7f)), new Complex32(-1.44363547517881161355f, -5.33120149970003008054e-8f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(2.0f, 5.0e-1f)), new Complex32(1.46571535194729052178f, 2.21018635622883858902e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(2.0f, -5.0e-1f)), new Complex32(1.46571535194729052178f, -2.21018635622883858902e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-2.0f, 5.0e-1f)), new Complex32(-1.46571535194729052178f, 2.21018635622883858902e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-2.0f, -5.0e-1f)), new Complex32(-1.46571535194729052178f, -2.21018635622883858902e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(2.0f, -1.0f)), new Complex32(1.52857091948099816127f, -4.27078586392476125481e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-2.0f, 1.0f)), new Complex32(-1.52857091948099816127f, 4.27078586392476125481e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-2.0f, -1.0f)), new Complex32(-1.52857091948099816127f, -4.27078586392476125481e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-2.0f, 2.0f)), new Complex32(-1.73432452148796644796f, 7.54249144698046040708e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-2.0f, -2.0f)), new Complex32(-1.73432452148796644796f, -7.54249144698046040708e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-2.0f, 8.388608e6f)), new Complex32(-1.6635532333438712295e1f, 1.57079608837631751767f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-2.0f, -8.388608e6f)), new Complex32(-1.6635532333438712295e1f, -1.57079608837631751767f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-8.388608e6f, 0.0f)), new Complex32(-1.66355323334386909787e1f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-8.388608e6f, 1.19209289550780998537e-7f)), new Complex32(-1.66355323334386909787e1f, 1.42108547152018727665e-14f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-8.388608e6f, -1.19209289550780998537e-7f)), new Complex32(-1.66355323334386909787e1f, -1.42108547152018727665e-14f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-8.388608e6f, 5.0e-1f)), new Complex32(-1.66355323334386927551e1f, 5.96046447753901308974e-8f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-8.388608e6f, -5.0e-1f)), new Complex32(-1.66355323334386927551e1f, -5.96046447753901308974e-8f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-8.388608e6f, 1.0f)), new Complex32(-1.66355323334386980842e1f, 1.19209289550779838278e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-8.388608e6f, -1.0f)), new Complex32(-1.66355323334386980842e1f, -1.19209289550779838278e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-8.388608e6f, 2.0f)), new Complex32(-1.66355323334387194004e1f, 2.38418579101556288425e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-8.388608e6f, -2.0f)), new Complex32(-1.66355323334387194004e1f, -2.38418579101556288425e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-8.388608e6f, 8.388608e6f)), new Complex32(-1.69821059237186600807e1f, 7.85398163397446533259e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Asinh(new Complex32(-8.388608e6f, -8.388608e6f)), new Complex32(-1.69821059237186600807e1f, -7.85398163397446533259e-1f), 6);
        }
    }
}