﻿using dnAnalytics.Math;
using NUnit.Framework;

namespace dnAnalytics.Tests.Math
{
    [TestFixture]
    public class ComplexMath_AcosTest32
    {
        [Test]
        public void Acos()
        {
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(0.0f, 1.19209289550780998537e-7f)), new Complex32(1.57079632679489661923f, -1.19209289550780716193e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(0.0f, -1.19209289550780998537e-7f)), new Complex32(1.57079632679489661923f, 1.19209289550780716193e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(0.0f, 5.0e-1f)), new Complex32(1.57079632679489661923f, -4.81211825059603447498e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(0.0f, -5.0e-1f)), new Complex32(1.57079632679489661923f, 4.81211825059603447498e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(0.0f, 1.0f)), new Complex32(1.57079632679489661923f, -8.81373587019543025233e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(0.0f, -1.0f)), new Complex32(1.57079632679489661923f, 8.81373587019543025233e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(0.0f, 2.0f)), new Complex32(1.57079632679489661923f, -1.44363547517881034249f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(0.0f, -2.0f)), new Complex32(1.57079632679489661923f, 1.44363547517881034249f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(0.0f, 8.388608e6f)), new Complex32(1.57079632679489661923f, -1.66355323334386909787e1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(1.19209289550780998537e-7f, 0.0f)), new Complex32(1.57079620758560706845f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-1.19209289550780998537e-7f, 0.0f)), new Complex32(1.57079644600418617001f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(1.19209289550780998537e-7f, 1.19209289550780998537e-7f)), new Complex32(1.57079620758560706845f, -1.19209289550781563226e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(1.19209289550780998537e-7f, -1.19209289550780998537e-7f)), new Complex32(1.57079620758560706845f, 1.19209289550781563226e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-1.19209289550780998537e-7f, 1.19209289550780998537e-7f)), new Complex32(1.57079644600418617001f, -1.19209289550781563226e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-1.19209289550780998537e-7f, -1.19209289550780998537e-7f)), new Complex32(1.57079644600418617001f, 1.19209289550781563226e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(1.19209289550780998537e-7f, 5.0e-1f)), new Complex32(1.57079622017086662523f, -4.81211825059605989613e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(1.19209289550780998537e-7f, -5.0e-1f)), new Complex32(1.57079622017086662523f, 4.81211825059605989613e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-1.19209289550780998537e-7f, 5.0e-1f)), new Complex32(1.57079643341892661323f, -4.81211825059605989613e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-1.19209289550780998537e-7f, -5.0e-1f)), new Complex32(1.57079643341892661323f, 4.81211825059605989613e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(1.19209289550780998537e-7f, 1.0f)), new Complex32(1.57079624250119959744f, -8.81373587019545537381e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(1.19209289550780998537e-7f, -1.0f)), new Complex32(1.57079624250119959744f, 8.81373587019545537381e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-1.19209289550780998537e-7f, 1.0f)), new Complex32(1.57079641108859364102f, -8.81373587019545537381e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-1.19209289550780998537e-7f, -1.0f)), new Complex32(1.57079641108859364102f, 8.81373587019545537381e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(1.19209289550780998537e-7f, 2.0f)), new Complex32(1.57079627348288162223f, -1.44363547517881161355f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(1.19209289550780998537e-7f, -2.0f)), new Complex32(1.57079627348288162223f, 1.44363547517881161355f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-1.19209289550780998537e-7f, 2.0f)), new Complex32(1.57079638010691161623f, -1.44363547517881161355f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-1.19209289550780998537e-7f, -2.0f)), new Complex32(1.57079638010691161623f, 1.44363547517881161355f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(1.19209289550780998537e-7f, 8.388608e6f)), new Complex32(1.57079632679488240838f, -1.66355323334386909787e1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-1.19209289550780998537e-7f, 8.388608e6f)), new Complex32(1.57079632679491083009f, -1.66355323334386909787e1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(5.0e-1f, 0.0f)), new Complex32(1.04719755119659774615f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-5.0e-1f, 0.0f)), new Complex32(2.09439510239319549231f, 0.0f), 6);
//            TestHelper.TestLogRelativeError(ComplexMath.Acos(new Complex32(5.0e-1f, 1.19209289550780998537e-7f)), new Complex32(1.04719755119660321591f, -1.37651030824094033271e-7f), 6);
  //          TestHelper.TestLogRelativeError(ComplexMath.Acos(new Complex32(5.0e-1f, -1.19209289550780998537e-7f)), new Complex32(1.04719755119660321591f, 1.37651030824094033271e-7f), 6);
            //TestHelper.TestLogRelativeError(ComplexMath.Acos(new Complex32(-5.0e-1f, 1.19209289550780998537e-7f)), new Complex32(2.09439510239319002255f, -1.37651030824094033271e-7f), 6);
            //TestHelper.TestLogRelativeError(ComplexMath.Acos(new Complex32(-5.0e-1f, -1.19209289550780998537e-7f)), new Complex32(2.09439510239319002255f, 1.37651030824094033271e-7f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(5.0e-1f, 5.0e-1f)), new Complex32(1.11851787964370593717f, -5.30637530952517826017e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(5.0e-1f, -5.0e-1f)), new Complex32(1.11851787964370593717f, 5.30637530952517826017e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-5.0e-1f, 5.0e-1f)), new Complex32(2.02307477394608730129f, -5.30637530952517826017e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-5.0e-1f, -5.0e-1f)), new Complex32(2.02307477394608730129f, 5.30637530952517826017e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(5.0e-1f, 1.0f)), new Complex32(1.2213572639376833256f, -9.2613303135018242455e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(5.0e-1f, -1.0f)), new Complex32(1.2213572639376833256f, 9.2613303135018242455e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-5.0e-1f, 1.0f)), new Complex32(1.92023538965210991286f, -9.2613303135018242455e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-5.0e-1f, -1.0f)), new Complex32(1.92023538965210991286f, 9.2613303135018242455e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(5.0e-1f, 2.0f)), new Complex32(1.34977769117201276033f, -1.46571535194729052178f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(5.0e-1f, -2.0f)), new Complex32(1.34977769117201276033f, 1.46571535194729052178f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-5.0e-1f, 2.0f)), new Complex32(1.79181496241778047813f, -1.46571535194729052178f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-5.0e-1f, -2.0f)), new Complex32(1.79181496241778047813f, 1.46571535194729052178f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(5.0e-1f, 8.388608e6f)), new Complex32(1.57079626719025184384f, -1.66355323334386927551e1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-5.0e-1f, 8.388608e6f)), new Complex32(1.57079638639954139462f, -1.66355323334386927551e1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(1.0f, 0.0f)), new Complex32(0.0f, 0.0f), 6);
            //TestHelper.TestLogRelativeError(ComplexMath.Acos(new Complex32(-1.0f, 0.0f)), new Complex32(3.14159265358979323846f, 0.0f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(1.0f, 1.19209289550780998537e-7f)), new Complex32(3.45266979571324139834e-4f, -3.45266986431162764654e-4f), 4);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-1.0f, 1.19209289550780998537e-7f)), new Complex32(3.14124738661022191432f, -3.45266986431162764654e-4f), 4);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(1.0f, 5.0e-1f)), new Complex32(6.74888845586006380165e-1f, -7.32857675973645260889e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(1.0f, -5.0e-1f)), new Complex32(6.74888845586006380165e-1f, 7.32857675973645260889e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-1.0f, 5.0e-1f)), new Complex32(2.4667038080037868583f, -7.32857675973645260889e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-1.0f, -5.0e-1f)), new Complex32(2.4667038080037868583f, 7.32857675973645260889e-1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(1.0f, 1.0f)), new Complex32(9.04556894302381364127e-1f, -1.06127506190503565203f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(1.0f, -1.0f)), new Complex32(9.04556894302381364127e-1f, 1.06127506190503565203f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-1.0f, 1.0f)), new Complex32(2.23703575928741187434f, -1.06127506190503565203f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-1.0f, -1.0f)), new Complex32(2.23703575928741187434f, 1.06127506190503565203f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(1.0f, 2.0f)), new Complex32(1.14371774040242049375f, -1.52857091948099816127f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(1.0f, -2.0f)), new Complex32(1.14371774040242049375f, 1.52857091948099816127f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-1.0f, 2.0f)), new Complex32(1.99787491318737274471f, -1.52857091948099816127f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-1.0f, -2.0f)), new Complex32(1.99787491318737274471f, 1.52857091948099816127f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(1.0f, 8.388608e6f)), new Complex32(1.57079620758560706845f, -1.66355323334386980842e1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-1.0f, 8.388608e6f)), new Complex32(1.57079644600418617001f, -1.66355323334386980842e1f), 6);
            //            TestHelper.TestLogRelativeError(ComplexMath.Acos(new Complex32(-2.0f, 0.0f)), new Complex32(3.14159265358979323846f, -1.31695789692481670863f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(2.0f, 1.19209289550780998537e-7f)), new Complex32(6.88255154120472883216e-8f, -1.31695789692481944351f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(2.0f, -1.19209289550780998537e-7f)), new Complex32(6.88255154120472883216e-8f, 1.31695789692481944351f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-2.0f, 1.19209289550780998537e-7f)), new Complex32(3.14159258476427782642f, -1.31695789692481944351f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-2.0f, -1.19209289550780998537e-7f)), new Complex32(3.14159258476427782642f, 1.31695789692481944351f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(2.0f, 5.0e-1f)), new Complex32(2.77754256557713960178e-1f, -1.36180090085784578821f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(2.0f, -5.0e-1f)), new Complex32(2.77754256557713960178e-1f, 1.36180090085784578821f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-2.0f, 5.0e-1f)), new Complex32(2.86383839703207927829f, -1.36180090085784578821f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-2.0f, -5.0e-1f)), new Complex32(2.86383839703207927829f, 1.36180090085784578821f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(2.0f, 1.0f)), new Complex32(5.07356303217144563042e-1f, -1.46935174436818527326f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(2.0f, -1.0f)), new Complex32(5.07356303217144563042e-1f, 1.46935174436818527326f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-2.0f, 1.0f)), new Complex32(2.63423635037264867542f, -1.46935174436818527326f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-2.0f, -1.0f)), new Complex32(2.63423635037264867542f, 1.46935174436818527326f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(2.0f, 2.0f)), new Complex32(8.16547182096850578524e-1f, -1.73432452148796644796f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(2.0f, -2.0f)), new Complex32(8.16547182096850578524e-1f, 1.73432452148796644796f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-2.0f, 2.0f)), new Complex32(2.32504547149294265994f, -1.73432452148796644796f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-2.0f, -2.0f)), new Complex32(2.32504547149294265994f, 1.73432452148796644796f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(2.0f, 8.388608e6f)), new Complex32(1.57079608837631751768f, -1.66355323334387194004e1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(-2.0f, 8.388608e6f)), new Complex32(1.57079656521347572079f, -1.66355323334387194004e1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(8.388608e6f, 1.19209289550780998537e-7f)), new Complex32(1.42108547152020747149e-14f, -1.66355323334386838733e1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(8.388608e6f, 5.0e-1f)), new Complex32(5.96046447753909779304e-8f, -1.66355323334386856497e1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(8.388608e6f, 1.0f)), new Complex32(1.19209289550781532344e-7f, -1.66355323334386909787e1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(8.388608e6f, 2.0f)), new Complex32(2.38418579101559676557e-7f, -1.6635532333438712295e1f), 6);
            TestHelper.TestSignificantDigits(ComplexMath.Acos(new Complex32(8.388608e6f, 8.388608e6f)), new Complex32(7.85398163397450085973e-1f, -1.69821059237186600807e1f), 6);
        }
    }
}