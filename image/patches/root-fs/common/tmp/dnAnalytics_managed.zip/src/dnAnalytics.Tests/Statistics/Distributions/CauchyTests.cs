using System;
using dnAnalytics.Statistics.Distributions;
using NUnit.Framework;

namespace dnAnalytics.Tests.Statistics.Distributions
{
    [TestFixture]
    public class CauchyTests
    {
        private const double mAcceptableError = 1e-12;

        [Test]
        public void CauchyTest()
        {
            Cauchy cauchy = new Cauchy(5.0, 1.0);

            Assert.AreEqual(5.0, cauchy.Mode, mAcceptableError);
            Assert.AreEqual(5.0, cauchy.Median, mAcceptableError);
            Assert.AreEqual(1.0, cauchy.Scale, mAcceptableError);

            Assert.AreEqual(System.Math.Log(4.0 * System.Math.PI), cauchy.Entropy, mAcceptableError);

            Assert.AreEqual(1.0 / (26.0 * System.Math.PI), cauchy.Density(0.0), mAcceptableError);

            Assert.AreEqual(0.5 + System.Math.Atan(-5.0) / System.Math.PI, cauchy.CumulativeDistribution(0.0), mAcceptableError);

            Assert.AreEqual(5.0 + System.Math.Tan(-0.5 * System.Math.PI), cauchy.InverseCumulativeDistribution(0.0), mAcceptableError);
        }

        [Test]
        public void GetSetRNG()
        {
            Normal normal = new Normal();

            // Try getting the random number generator.
            System.Random rnd = normal.RandomNumberGenerator;
            // Try setting the random number generator.
            normal.RandomNumberGenerator = new System.Random();
        }

        [Test]
        [ExpectedException(typeof(NotSupportedException))]
        public void UndefinedMean()
        {
            Cauchy cauchy = new Cauchy(5.0, 1.0);
            double m = cauchy.Mean;
        }

        [Test]
        [ExpectedException(typeof(NotSupportedException))]
        public void UndefinedVariance()
        {
            Cauchy cauchy = new Cauchy(5.0, 1.0);
            double v = cauchy.Variance;
        }

        [Test]
        [ExpectedException(typeof(NotSupportedException))]
        public void UndefinedStdDev()
        {
            Cauchy cauchy = new Cauchy(5.0, 1.0);
            double s = cauchy.StdDev;
        }
    }
}