using dnAnalytics.Math;
using NUnit.Framework;

namespace dnAnalytics.Tests.Math
{
    [TestFixture]
    public class ComplexMath_CoshTest
    {
        [Test]
        public void Cosh()
        {
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(0.0, 1.19209289550780998537e-7)), new Complex(9.99999999999992894573e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(0.0, -1.19209289550780998537e-7)), new Complex(9.99999999999992894573e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(0.0, 5.0e-1)), new Complex(8.77582561890372716116e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(0.0, -5.0e-1)), new Complex(8.77582561890372716116e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(0.0, 1.0)), new Complex(5.40302305868139717401e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(0.0, -1.0)), new Complex(5.40302305868139717401e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(0.0, 2.0)), new Complex(-4.16146836547142386998e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(0.0, -2.0)), new Complex(-4.16146836547142386998e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(0.0, 8.388608e6)), new Complex(-9.01754673758759322321e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(0.0, -8.388608e6)), new Complex(-9.01754673758759322321e-1, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.19209289550780998537e-7, 0.0)), new Complex(1.00000000000000710543, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.19209289550780998537e-7, 0.0)), new Complex(1.00000000000000710543, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.19209289550780998537e-7, 1.19209289550780998537e-7)), new Complex(1.0, 1.4210854715201943764e-14), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.19209289550780998537e-7, -1.19209289550780998537e-7)), new Complex(1.0, -1.4210854715201943764e-14), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.19209289550780998537e-7, 1.19209289550780998537e-7)), new Complex(1.0, -1.4210854715201943764e-14), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.19209289550780998537e-7, -1.19209289550780998537e-7)), new Complex(1.0, 1.4210854715201943764e-14), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.19209289550780998537e-7, 5.0e-1)), new Complex(8.77582561890378951715e-1, 5.71519778495077043139e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.19209289550780998537e-7, -5.0e-1)), new Complex(8.77582561890378951715e-1, -5.71519778495077043139e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.19209289550780998537e-7, 5.0e-1)), new Complex(8.77582561890378951715e-1, -5.71519778495077043139e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.19209289550780998537e-7, -5.0e-1)), new Complex(8.77582561890378951715e-1, 5.71519778495077043139e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.19209289550780998537e-7, 1.0)), new Complex(5.4030230586814355648e-1, 1.00311158276545610981e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.19209289550780998537e-7, -1.0)), new Complex(5.4030230586814355648e-1, -1.00311158276545610981e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.19209289550780998537e-7, 1.0)), new Complex(5.4030230586814355648e-1, -1.00311158276545610981e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.19209289550780998537e-7, -1.0)), new Complex(5.4030230586814355648e-1, 1.00311158276545610981e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.19209289550780998537e-7, 2.0)), new Complex(-4.16146836547145343899e-1, 1.08396700242243043298e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.19209289550780998537e-7, -2.0)), new Complex(-4.16146836547145343899e-1, -1.08396700242243043298e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.19209289550780998537e-7, 2.0)), new Complex(-4.16146836547145343899e-1, -1.08396700242243043298e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.19209289550780998537e-7, -2.0)), new Complex(-4.16146836547145343899e-1, 1.08396700242243043298e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.19209289550780998537e-7, 8.388608e6)), new Complex(-9.01754673758765729674e-1, 5.15280011006352744858e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.19209289550780998537e-7, -8.388608e6)), new Complex(-9.01754673758765729674e-1, -5.15280011006352744858e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.19209289550780998537e-7, 8.388608e6)), new Complex(-9.01754673758765729674e-1, -5.15280011006352744858e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.19209289550780998537e-7, -8.388608e6)), new Complex(-9.01754673758765729674e-1, 5.15280011006352744858e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(5.0e-1, 0.0)), new Complex(1.12762596520638078523, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-5.0e-1, 0.0)), new Complex(1.12762596520638078523, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(5.0e-1, 1.19209289550780998537e-7)), new Complex(1.12762596520637277296, 6.21194011561566624892e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(5.0e-1, -1.19209289550780998537e-7)), new Complex(1.12762596520637277296, -6.21194011561566624892e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-5.0e-1, 1.19209289550780998537e-7)), new Complex(1.12762596520637277296, -6.21194011561566624892e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-5.0e-1, -1.19209289550780998537e-7)), new Complex(1.12762596520637277296, 6.21194011561566624892e-8), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(5.0e-1, 5.0e-1)), new Complex(9.89584883399919936444e-1, 2.4982639750046153149e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(5.0e-1, -5.0e-1)), new Complex(9.89584883399919936444e-1, -2.4982639750046153149e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-5.0e-1, 5.0e-1)), new Complex(9.89584883399919936444e-1, -2.4982639750046153149e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-5.0e-1, -5.0e-1)), new Complex(9.89584883399919936444e-1, 2.4982639750046153149e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(5.0e-1, 1.0)), new Complex(6.09258909157794225734e-1, 4.38486579892595275173e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(5.0e-1, -1.0)), new Complex(6.09258909157794225734e-1, -4.38486579892595275173e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-5.0e-1, 1.0)), new Complex(6.09258909157794225734e-1, -4.38486579892595275173e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-5.0e-1, -1.0)), new Complex(6.09258909157794225734e-1, 4.38486579892595275173e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(5.0e-1, 2.0)), new Complex(-4.69257978229053413027e-1, 4.73830620416406990321e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(5.0e-1, -2.0)), new Complex(-4.69257978229053413027e-1, -4.73830620416406990321e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-5.0e-1, 2.0)), new Complex(-4.69257978229053413027e-1, -4.73830620416406990321e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-5.0e-1, -2.0)), new Complex(-4.69257978229053413027e-1, 4.73830620416406990321e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(5.0e-1, 8.388608e6)), new Complex(-1.01684198437658599569, 2.2524250900412912476e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(5.0e-1, -8.388608e6)), new Complex(-1.01684198437658599569, -2.2524250900412912476e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-5.0e-1, 8.388608e6)), new Complex(-1.01684198437658599569, -2.2524250900412912476e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-5.0e-1, -8.388608e6)), new Complex(-1.01684198437658599569, 2.2524250900412912476e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.0, 0.0)), new Complex(1.54308063481524377848, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.0, 0.0)), new Complex(1.54308063481524377848, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.0, 1.19209289550780998537e-7)), new Complex(1.54308063481523281423, 1.40094899373507046038e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.0, -1.19209289550780998537e-7)), new Complex(1.54308063481523281423, -1.40094899373507046038e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.0, 1.19209289550780998537e-7)), new Complex(1.54308063481523281423, -1.40094899373507046038e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.0, -1.19209289550780998537e-7)), new Complex(1.54308063481523281423, 1.40094899373507046038e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.0, 5.0e-1)), new Complex(1.35418065670458429296, 5.63421465230981780955e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.0, -5.0e-1)), new Complex(1.35418065670458429296, -5.63421465230981780955e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.0, 5.0e-1)), new Complex(1.35418065670458429296, -5.63421465230981780955e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.0, -5.0e-1)), new Complex(1.35418065670458429296, 5.63421465230981780955e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.0, 1.0)), new Complex(8.33730025131149048884e-1, 9.88897705762865096382e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.0, -1.0)), new Complex(8.33730025131149048884e-1, -9.88897705762865096382e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.0, 1.0)), new Complex(8.33730025131149048884e-1, -9.88897705762865096382e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.0, -1.0)), new Complex(8.33730025131149048884e-1, 9.88897705762865096382e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.0, 2.0)), new Complex(-6.42148124715519964845e-1, 1.0686074213827783396), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.0, -2.0)), new Complex(-6.42148124715519964845e-1, -1.0686074213827783396), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.0, 2.0)), new Complex(-6.42148124715519964845e-1, -1.0686074213827783396), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.0, -2.0)), new Complex(-6.42148124715519964845e-1, 1.0686074213827783396), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.0, 8.388608e6)), new Complex(-1.39148017443127938564, 5.07978603242576038333e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(1.0, -8.388608e6)), new Complex(-1.39148017443127938564, -5.07978603242576038333e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.0, 8.388608e6)), new Complex(-1.39148017443127938564, -5.07978603242576038333e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-1.0, -8.388608e6)), new Complex(-1.39148017443127938564, 5.07978603242576038333e-1), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(2.0, 0.0)), new Complex(3.76219569108363145956, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-2.0, 0.0)), new Complex(3.76219569108363145956, 0.0), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(2.0, 1.19209289550780998537e-7)), new Complex(3.76219569108360472755, 4.32355452519297901029e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(2.0, -1.19209289550780998537e-7)), new Complex(3.76219569108360472755, -4.32355452519297901029e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-2.0, 1.19209289550780998537e-7)), new Complex(3.76219569108360472755, -4.32355452519297901029e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-2.0, -1.19209289550780998537e-7)), new Complex(3.76219569108360472755, 4.32355452519297901029e-7), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(2.0, 5.0e-1)), new Complex(3.30163733291409455749, 1.73880950447431633438), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(2.0, -5.0e-1)), new Complex(3.30163733291409455749, -1.73880950447431633438), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-2.0, 5.0e-1)), new Complex(3.30163733291409455749, -1.73880950447431633438), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-2.0, -5.0e-1)), new Complex(3.30163733291409455749, 1.73880950447431633438), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(2.0, 1.0)), new Complex(2.03272300701966552944, 3.05189779915180005751), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(2.0, -1.0)), new Complex(2.03272300701966552944, -3.05189779915180005751), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-2.0, 1.0)), new Complex(2.03272300701966552944, -3.05189779915180005751), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-2.0, -1.0)), new Complex(2.03272300701966552944, 3.05189779915180005751), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(2.0, 2.0)), new Complex(-1.56562583531574337406, 3.29789483631123661773), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(2.0, -2.0)), new Complex(-1.56562583531574337406, -3.29789483631123661773), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-2.0, 2.0)), new Complex(-1.56562583531574337406, -3.29789483631123661773), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-2.0, -2.0)), new Complex(-1.56562583531574337406, 3.29789483631123661773), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(2.0, 8.388608e6)), new Complex(-3.39257754802973015548, 1.56770389112823016984), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(2.0, -8.388608e6)), new Complex(-3.39257754802973015548, -1.56770389112823016984), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-2.0, 8.388608e6)), new Complex(-3.39257754802973015548, -1.56770389112823016984), 13);
            TestHelper.TestSignificantDigits(ComplexMath.Cosh(new Complex(-2.0, -8.388608e6)), new Complex(-3.39257754802973015548, 1.56770389112823016984), 13);
        }
    }
}