﻿using dnAnalytics.Statistics;
using NUnit.Framework;

namespace dnAnalytics.Tests.Statistics
{
    [TestFixture]
    public class HistogramTest
    {
        private double[] smallDataset = { 0.5, 1.5, 2.5, 3.5, 4.5, 5.5, 6.5, 7.5, 8.5, 9.5 };

        [Test]
        public void HistogramWithoutBounds()
        {
            Histogram hist = new Histogram(smallDataset, 9);

            Assert.AreEqual(9, hist.BinCount);

            for (int i = 0; i < 8; i++)
            {
                Assert.AreEqual(1.0, hist[i]);
            }
            Assert.AreEqual(2.0, hist[8]);

            Assert.AreEqual(hist.LowerBound, 0.5);
            Assert.AreEqual(hist.UpperBound, 9.5);
        }

        [Test]
        public void HistogramWithBounds()
        {
            Histogram hist = new Histogram(smallDataset, 10, 0.0, 10.0);

            Assert.AreEqual(10, hist.BinCount);

            for (int i = 0; i < 10; i++)
            {
                Assert.AreEqual(1.0, hist[i]);
            }

            Assert.AreEqual(hist.LowerBound, 0.0);
            Assert.AreEqual(hist.UpperBound, 10.0);
        }
    }
}
