using dnAnalytics.Math;
using NUnit.Framework;

namespace dnAnalytics.Tests.Math
{
    [TestFixture]
    public class ComplexMath_Sin32Test
    {
        [Test]
        public void Sin()
        {
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(0.0f, 1.19209289550780998537e-7f)), new Complex32(0.0f, 1.19209289550781280881e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(0.0f, -1.19209289550780998537e-7f)), new Complex32(0.0f, -1.19209289550781280881e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(0.0f, 5.0e-1f)), new Complex32(0.0f, 5.21095305493747361622e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(0.0f, -5.0e-1f)), new Complex32(0.0f, -5.21095305493747361622e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(0.0f, 1.0f)), new Complex32(0.0f, 1.17520119364380145688f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(0.0f, -1.0f)), new Complex32(0.0f, -1.17520119364380145688f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(0.0f, 2.0f)), new Complex32(0.0f, 3.62686040784701876767f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(0.0f, -2.0f)), new Complex32(0.0f, -3.62686040784701876767f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(1.19209289550780998537e-7f, 0.0f)), new Complex32(1.19209289550780716193e-7f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-1.19209289550780998537e-7f, 0.0f)), new Complex32(-1.19209289550780716193e-7f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(1.19209289550780998537e-7f, 1.19209289550780998537e-7f)), new Complex32(1.19209289550781563226e-7f, 1.19209289550780433848e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(1.19209289550780998537e-7f, -1.19209289550780998537e-7f)), new Complex32(1.19209289550781563226e-7f, -1.19209289550780433848e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-1.19209289550780998537e-7f, 1.19209289550780998537e-7f)), new Complex32(-1.19209289550781563226e-7f, 1.19209289550780433848e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-1.19209289550780998537e-7f, -1.19209289550780998537e-7f)), new Complex32(-1.19209289550781563226e-7f, -1.19209289550780433848e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(1.19209289550780998537e-7f, 5.0e-1f)), new Complex32(1.34423490191266028384e-7f, 5.21095305493743659018e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(1.19209289550780998537e-7f, -5.0e-1f)), new Complex32(1.34423490191266028384e-7f, -5.21095305493743659018e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-1.19209289550780998537e-7f, 5.0e-1f)), new Complex32(-1.34423490191266028384e-7f, 5.21095305493743659018e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-1.19209289550780998537e-7f, -5.0e-1f)), new Complex32(-1.34423490191266028384e-7f, -5.21095305493743659018e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(1.19209289550780998537e-7f, 1.0f)), new Complex32(1.83949546195892914381e-7f, 1.17520119364379310658f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(1.19209289550780998537e-7f, -1.0f)), new Complex32(1.83949546195892914381e-7f, -1.17520119364379310658f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-1.19209289550780998537e-7f, 1.0f)), new Complex32(-1.83949546195892914381e-7f, 1.17520119364379310658f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-1.19209289550780998537e-7f, -1.0f)), new Complex32(-1.83949546195892914381e-7f, -1.17520119364379310658f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(1.19209289550780998537e-7f, 2.0f)), new Complex32(4.48488675485088183025e-7f, 3.62686040784699299728f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(1.19209289550780998537e-7f, -2.0f)), new Complex32(4.48488675485088183025e-7f, -3.62686040784699299728f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-1.19209289550780998537e-7f, 2.0f)), new Complex32(-4.48488675485088183025e-7f, 3.62686040784699299728f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-1.19209289550780998537e-7f, -2.0f)), new Complex32(-4.48488675485088183025e-7f, -3.62686040784699299728f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(5.0e-1f, 0.0f)), new Complex32(4.79425538604203000273e-1f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-5.0e-1f, 0.0f)), new Complex32(-4.79425538604203000273e-1f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(5.0e-1f, 1.19209289550780998537e-7f)), new Complex32(4.79425538604206406797e-1f, 1.0461599372510587495e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(5.0e-1f, -1.19209289550780998537e-7f)), new Complex32(4.79425538604206406797e-1f, -1.0461599372510587495e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-5.0e-1f, 1.19209289550780998537e-7f)), new Complex32(-4.79425538604206406797e-1f, 1.0461599372510587495e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-5.0e-1f, -1.19209289550780998537e-7f)), new Complex32(-4.79425538604206406797e-1f, -1.0461599372510587495e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(5.0e-1f, 5.0e-1f)), new Complex32(5.40612685713153380354e-1f, 4.57304153184249221608e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(5.0e-1f, -5.0e-1f)), new Complex32(5.40612685713153380354e-1f, -4.57304153184249221608e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-5.0e-1f, 5.0e-1f)), new Complex32(-5.40612685713153380354e-1f, 4.57304153184249221608e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-5.0e-1f, -5.0e-1f)), new Complex32(-5.40612685713153380354e-1f, -4.57304153184249221608e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(5.0e-1f, 1.0f)), new Complex32(7.39792264456013728317e-1f, 1.03133607425455128307f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(5.0e-1f, -1.0f)), new Complex32(7.39792264456013728317e-1f, -1.03133607425455128307f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-5.0e-1f, 1.0f)), new Complex32(-7.39792264456013728317e-1f, 1.03133607425455128307f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-5.0e-1f, -1.0f)), new Complex32(-7.39792264456013728317e-1f, -1.03133607425455128307f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(5.0e-1f, 2.0f)), new Complex32(1.80369269553218173966f, 3.18286944833714877865f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(5.0e-1f, -2.0f)), new Complex32(1.80369269553218173966f, -3.18286944833714877865f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-5.0e-1f, 2.0f)), new Complex32(-1.80369269553218173966f, 3.18286944833714877865f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-5.0e-1f, -2.0f)), new Complex32(-1.80369269553218173966f, -3.18286944833714877865f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(1.0f, 0.0f)), new Complex32(8.41470984807896506653e-1f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-1.0f, 0.0f)), new Complex32(-8.41470984807896506653e-1f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(1.0f, 1.19209289550780998537e-7f)), new Complex32(8.41470984807902485663e-1f, 6.44090540251898595533e-8f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(1.0f, -1.19209289550780998537e-7f)), new Complex32(8.41470984807902485663e-1f, -6.44090540251898595533e-8f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-1.0f, 1.19209289550780998537e-7f)), new Complex32(-8.41470984807902485663e-1f, 6.44090540251898595533e-8f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-1.0f, -1.19209289550780998537e-7f)), new Complex32(-8.41470984807902485663e-1f, -6.44090540251898595533e-8f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(1.0f, 5.0e-1f)), new Complex32(9.48864531437168080524e-1f, 2.81548995135334393823e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(1.0f, -5.0e-1f)), new Complex32(9.48864531437168080524e-1f, -2.81548995135334393823e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-1.0f, 5.0e-1f)), new Complex32(-9.48864531437168080524e-1f, 2.81548995135334393823e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-1.0f, -5.0e-1f)), new Complex32(-9.48864531437168080524e-1f, -2.81548995135334393823e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(1.0f, 1.0f)), new Complex32(1.29845758141597729483f, 6.34963914784736108255e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(1.0f, -1.0f)), new Complex32(1.29845758141597729483f, -6.34963914784736108255e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-1.0f, 1.0f)), new Complex32(-1.29845758141597729483f, 6.34963914784736108255e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-1.0f, -1.0f)), new Complex32(-1.29845758141597729483f, -6.34963914784736108255e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(1.0f, 2.0f)), new Complex32(3.16577851321616814674f, 1.95960104142160589707f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(1.0f, -2.0f)), new Complex32(3.16577851321616814674f, -1.95960104142160589707f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-1.0f, 2.0f)), new Complex32(-3.16577851321616814674f, 1.95960104142160589707f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-1.0f, -2.0f)), new Complex32(-3.16577851321616814674f, -1.95960104142160589707f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(2.0f, 0.0f)), new Complex32(9.09297426825681695396e-1f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-2.0f, 0.0f)), new Complex32(-9.09297426825681695396e-1f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(2.0f, 1.19209289550780998537e-7f)), new Complex32(9.09297426825688156343e-1f, -4.96085687335899466039e-8f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(2.0f, -1.19209289550780998537e-7f)), new Complex32(9.09297426825688156343e-1f, 4.96085687335899466039e-8f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-2.0f, 1.19209289550780998537e-7f)), new Complex32(-9.09297426825688156343e-1f, -4.96085687335899466039e-8f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-2.0f, -1.19209289550780998537e-7f)), new Complex32(-9.09297426825688156343e-1f, 4.96085687335899466039e-8f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(2.0f, 5.0e-1f)), new Complex32(1.02534738858398772551f, -2.16852162920789711624e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(2.0f, -5.0e-1f)), new Complex32(1.02534738858398772551f, 2.16852162920789711624e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-2.0f, 5.0e-1f)), new Complex32(-1.02534738858398772551f, -2.16852162920789711624e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-2.0f, -5.0e-1f)), new Complex32(-1.02534738858398772551f, 2.16852162920789711624e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(2.0f, 1.0f)), new Complex32(1.40311925062204058802f, -4.89056259041293673586e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(2.0f, -1.0f)), new Complex32(1.40311925062204058802f, 4.89056259041293673586e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-2.0f, 1.0f)), new Complex32(-1.40311925062204058802f, -4.89056259041293673586e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-2.0f, -1.0f)), new Complex32(-1.40311925062204058802f, 4.89056259041293673586e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(2.0f, 2.0f)), new Complex32(3.42095486111701335354f, -1.50930648532361549305f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(2.0f, -2.0f)), new Complex32(3.42095486111701335354f, 1.50930648532361549305f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-2.0f, 2.0f)), new Complex32(-3.42095486111701335354f, -1.50930648532361549305f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-2.0f, -2.0f)), new Complex32(-3.42095486111701335354f, 1.50930648532361549305f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(8.388608e6f, 0.0f)), new Complex32(4.32248202256797756659e-1f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-8.388608e6f, 0.0f)), new Complex32(-4.32248202256797756659e-1f, 0.0f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(8.388608e6f, 1.19209289550780998537e-7f)), new Complex32(4.32248202256800827967e-1f, -1.0749753400787825059e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(8.388608e6f, -1.19209289550780998537e-7f)), new Complex32(4.32248202256800827967e-1f, 1.0749753400787825059e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-8.388608e6f, 1.19209289550780998537e-7f)), new Complex32(-4.32248202256800827967e-1f, -1.0749753400787825059e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-8.388608e6f, -1.19209289550780998537e-7f)), new Complex32(-4.32248202256800827967e-1f, 1.0749753400787825059e-7f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(8.388608e6f, 5.0e-1f)), new Complex32(4.87414296278544471557e-1f, -4.69900127202735176486e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(8.388608e6f, -5.0e-1f)), new Complex32(4.87414296278544471557e-1f, 4.69900127202735176486e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-8.388608e6f, 5.0e-1f)), new Complex32(-4.87414296278544471557e-1f, -4.69900127202735176486e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-8.388608e6f, -5.0e-1f)), new Complex32(-4.87414296278544471557e-1f, 4.69900127202735176486e-1f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(8.388608e6f, 1.0f)), new Complex32(6.66993830336167370804e-1f, -1.05974316897517072251f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(8.388608e6f, -1.0f)), new Complex32(6.66993830336167370804e-1f, 1.05974316897517072251f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-8.388608e6f, 1.0f)), new Complex32(-6.66993830336167370804e-1f, -1.05974316897517072251f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-8.388608e6f, -1.0f)), new Complex32(-6.66993830336167370804e-1f, 1.05974316897517072251f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(8.388608e6f, 2.0f)), new Complex32(1.62620232400917054361f, -3.27053832384664918808f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(8.388608e6f, -2.0f)), new Complex32(1.62620232400917054361f, 3.27053832384664918808f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-8.388608e6f, 2.0f)), new Complex32(-1.62620232400917054361f, -3.27053832384664918808f), 7);
            TestHelper.TestSignificantDigits(ComplexMath.Sin(new Complex32(-8.388608e6f, -2.0f)), new Complex32(-1.62620232400917054361f, 3.27053832384664918808f), 7);
        }
    }
}