using dnAnalytics.LinearAlgebra;
using dnAnalytics.LinearAlgebra.IO;
using NUnit.Framework;

namespace dnAnalytics.Tests.LinearAlgebra.Decomposition
{
    [TestFixture]
    public class BaseLUTests : LUTests
    {
        protected override Matrix GetMatrix(string file)
        {
            MatrixMarketReader mmr = new MatrixMarketReader();
            Matrix matrix = mmr.ReadMatrix(file, StorageType.Dense);
            return new BaseMatrix(matrix);
        }

        protected override Matrix GetIdentityMatrix(int size)
        {
            BaseMatrix matrix = new BaseMatrix(size);
            for (int i = 0; i < size; i++)
            {
                matrix[i, i] = 1.0;
            }
            return matrix;
        }

        protected override Matrix GetMatrix(int size)
        {
            return new BaseMatrix(size);
        }

        protected override Vector GetVector(int size)
        {
            return new BaseVector(size);
        }
    }
}