﻿using System.IO;
using dnAnalytics.LinearAlgebra;
using dnAnalytics.LinearAlgebra.IO;
using NUnit.Framework;

namespace dnAnalytics.Tests.LinearAlgebra.IO
{
    [TestFixture]
    public class DelimitedMatrixWriterTest
    {
        [Test]
        public void WriteMatrixStream()
        {
            //white space
            DelimitedMatrixReader dmr = new DelimitedMatrixReader();
            Matrix matrix = dmr.ReadMatrix("./TestData/Matrices/random_real_general_dense_10_20.space", StorageType.Dense);

            DelimitedMatrixWriter dmw = new DelimitedMatrixWriter(',');
            dmw.WriteMatrix(matrix, File.OpenWrite("./TestData/Matrices/temp_stream.comma"));
            dmr = new DelimitedMatrixReader(",");
            Matrix test = dmr.ReadMatrix("./TestData/Matrices/temp_stream.comma", StorageType.Dense);
            Assert.AreEqual(10, test.Rows);
            Assert.AreEqual(20, test.Columns);
            const double expected = 767.35692;
            double actual = matrix.FrobeniusNorm();
            double error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);

            dmw = new DelimitedMatrixWriter("\t");
            dmw.WriteMatrix(matrix, File.OpenWrite("./TestData/Matrices/temp_stream.tab"));
            dmr = new DelimitedMatrixReader("\t");
            test = dmr.ReadMatrix("./TestData/Matrices/temp_stream.tab", StorageType.Dense);
            Assert.AreEqual(10, test.Rows);
            Assert.AreEqual(20, test.Columns);
            actual = matrix.FrobeniusNorm();
            error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);

            dmw = new DelimitedMatrixWriter(" ");
            dmr = new DelimitedMatrixReader();
            dmw.WriteMatrix(matrix, File.OpenWrite("./TestData/Matrices/temp_stream.space"));
            test = dmr.ReadMatrix("./TestData/Matrices/temp_stream.space", StorageType.Dense);
            Assert.AreEqual(10, test.Rows);
            Assert.AreEqual(20, test.Columns);
            actual = matrix.FrobeniusNorm();
            error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);
        }

        [Test]
        public void WriteMatrixStreamFormat()
        {
            const string format = "E";
            //white space
            DelimitedMatrixReader dmr = new DelimitedMatrixReader();
            Matrix matrix = dmr.ReadMatrix("./TestData/Matrices/random_real_general_dense_10_20.space", StorageType.Dense);

            DelimitedMatrixWriter dmw = new DelimitedMatrixWriter(',');
            dmw.WriteMatrix(matrix, File.OpenWrite("./TestData/Matrices/temp_stream_format.comma"), format);
            dmr = new DelimitedMatrixReader(",");
            Matrix test = dmr.ReadMatrix("./TestData/Matrices/temp_stream_format.comma", StorageType.Dense);
            Assert.AreEqual(10, test.Rows);
            Assert.AreEqual(20, test.Columns);
            const double expected = 767.35692;
            double actual = matrix.FrobeniusNorm();
            double error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);

            dmw = new DelimitedMatrixWriter("\t");
            dmw.WriteMatrix(matrix, File.OpenWrite("./TestData/Matrices/temp_stream_format.tab"), format);
            dmr = new DelimitedMatrixReader("\t");
            test = dmr.ReadMatrix("./TestData/Matrices/temp_stream_format.tab", StorageType.Dense);
            Assert.AreEqual(10, test.Rows);
            Assert.AreEqual(20, test.Columns);
            actual = matrix.FrobeniusNorm();
            error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);

            dmw = new DelimitedMatrixWriter(" ");
            dmr = new DelimitedMatrixReader();
            dmw.WriteMatrix(matrix, File.OpenWrite("./TestData/Matrices/temp_stream_format.space"), format);
            test = dmr.ReadMatrix("./TestData/Matrices/temp_stream_format.space", StorageType.Dense);
            Assert.AreEqual(10, test.Rows);
            Assert.AreEqual(20, test.Columns);
            actual = matrix.FrobeniusNorm();
            error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);
        }

        [Test]
        public void WriteMatrixString()
        {
            //white space
            DelimitedMatrixReader dmr = new DelimitedMatrixReader();
            Matrix matrix = dmr.ReadMatrix("./TestData/Matrices/random_real_general_dense_10_20.space", StorageType.Dense);

            DelimitedMatrixWriter dmw = new DelimitedMatrixWriter(',');
            dmw.WriteMatrix(matrix, "./TestData/Matrices/temp_string.comma");
            dmr = new DelimitedMatrixReader(",");
            Matrix test = dmr.ReadMatrix("./TestData/Matrices/temp_string.comma", StorageType.Dense);
            Assert.AreEqual(10, test.Rows);
            Assert.AreEqual(20, test.Columns);
            const double expected = 767.35692;
            double actual = matrix.FrobeniusNorm();
            double error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);

            dmw = new DelimitedMatrixWriter("\t");
            dmw.WriteMatrix(matrix, "./TestData/Matrices/temp_string.tab");
            dmr = new DelimitedMatrixReader("\t");
            test = dmr.ReadMatrix("./TestData/Matrices/temp_string.tab", StorageType.Dense);
            Assert.AreEqual(10, test.Rows);
            Assert.AreEqual(20, test.Columns);
            actual = matrix.FrobeniusNorm();
            error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);

            dmw = new DelimitedMatrixWriter(" ");
            dmr = new DelimitedMatrixReader();
            dmw.WriteMatrix(matrix, "./TestData/Matrices/temp_string.space");
            test = dmr.ReadMatrix("./TestData/Matrices/temp_string.space", StorageType.Dense);
            Assert.AreEqual(10, test.Rows);
            Assert.AreEqual(20, test.Columns);
            actual = matrix.FrobeniusNorm();
            error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);
        }

        [Test]
        public void WriteMatrixStringFormat()
        {
            const string format = "E";
            //white space
            DelimitedMatrixReader dmr = new DelimitedMatrixReader();
            Matrix matrix = dmr.ReadMatrix("./TestData/Matrices/random_real_general_dense_10_20.space", StorageType.Dense);

            DelimitedMatrixWriter dmw = new DelimitedMatrixWriter(',');
            dmw.WriteMatrix(matrix, "./TestData/Matrices/temp_string_format.comma", format);
            dmr = new DelimitedMatrixReader(",");
            Matrix test = dmr.ReadMatrix("./TestData/Matrices/temp_string_format.comma", StorageType.Dense);
            Assert.AreEqual(10, test.Rows);
            Assert.AreEqual(20, test.Columns);
            const double expected = 767.35692;
            double actual = matrix.FrobeniusNorm();
            double error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);

            dmw = new DelimitedMatrixWriter("\t");
            dmw.WriteMatrix(matrix, "./TestData/Matrices/temp_string_format.tab", format);
            dmr = new DelimitedMatrixReader("\t");
            test = dmr.ReadMatrix("./TestData/Matrices/temp_string_format.tab", StorageType.Dense);
            Assert.AreEqual(10, test.Rows);
            Assert.AreEqual(20, test.Columns);
            actual = matrix.FrobeniusNorm();
            error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);

            dmw = new DelimitedMatrixWriter(" ");
            dmr = new DelimitedMatrixReader();
            dmw.WriteMatrix(matrix, "./TestData/Matrices/temp_string_format.space", format);
            test = dmr.ReadMatrix("./TestData/Matrices/temp_string_format.space", StorageType.Dense);
            Assert.AreEqual(10, test.Rows);
            Assert.AreEqual(20, test.Columns);
            actual = matrix.FrobeniusNorm();
            error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);
        }

        [Test]
        public void WriteMatrixTextWriter()
        {
            //white space
            DelimitedMatrixReader dmr = new DelimitedMatrixReader();
            Matrix matrix = dmr.ReadMatrix("./TestData/Matrices/random_real_general_dense_10_20.space", StorageType.Dense);

            DelimitedMatrixWriter dmw = new DelimitedMatrixWriter(',');
            using (TextWriter tw = new StreamWriter("./TestData/Matrices/temp_writer.comma"))
            {
                dmw.WriteMatrix(matrix, tw);
            }
            dmr = new DelimitedMatrixReader(",");
            Matrix test = dmr.ReadMatrix("./TestData/Matrices/temp_writer.comma", StorageType.Dense);
            Assert.AreEqual(10, test.Rows);
            Assert.AreEqual(20, test.Columns);
            const double expected = 767.35692;
            double actual = matrix.FrobeniusNorm();
            double error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);

            dmw = new DelimitedMatrixWriter("\t");
            using (TextWriter tw = new StreamWriter("./TestData/Matrices/temp_writer.tab"))
            {
                dmw.WriteMatrix(matrix, tw);
            }
            dmr = new DelimitedMatrixReader("\t");
            test = dmr.ReadMatrix("./TestData/Matrices/temp_writer.tab", StorageType.Dense);
            Assert.AreEqual(10, test.Rows);
            Assert.AreEqual(20, test.Columns);
            actual = matrix.FrobeniusNorm();
            error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);

            dmw = new DelimitedMatrixWriter(" ");
            dmr = new DelimitedMatrixReader();
            using (TextWriter tw = new StreamWriter("./TestData/Matrices/temp_writer.space"))
            {
                dmw.WriteMatrix(matrix, tw);
            }
            test = dmr.ReadMatrix("./TestData/Matrices/temp_writer.space", StorageType.Dense);
            Assert.AreEqual(10, test.Rows);
            Assert.AreEqual(20, test.Columns);
            actual = matrix.FrobeniusNorm();
            error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);
        }

        [Test]
        public void WriteMatrixTextWriterFormat()
        {
            const string format = "E";
            //white space
            DelimitedMatrixReader dmr = new DelimitedMatrixReader();
            Matrix matrix = dmr.ReadMatrix("./TestData/Matrices/random_real_general_dense_10_20.space", StorageType.Dense);

            DelimitedMatrixWriter dmw = new DelimitedMatrixWriter(',');
            using (TextWriter tw = new StreamWriter("./TestData/Matrices/temp_writer.comma"))
            {
                dmw.WriteMatrix(matrix, tw, format);
            }
            dmr = new DelimitedMatrixReader(",");
            Matrix test = dmr.ReadMatrix("./TestData/Matrices/temp_writer.comma", StorageType.Dense);
            Assert.AreEqual(10, test.Rows);
            Assert.AreEqual(20, test.Columns);
            const double expected = 767.35692;
            double actual = matrix.FrobeniusNorm();
            double error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);

            dmw = new DelimitedMatrixWriter("\t");
            using (TextWriter tw = new StreamWriter("./TestData/Matrices/temp_writer.tab"))
            {
                dmw.WriteMatrix(matrix, tw, format);
            }
            dmr = new DelimitedMatrixReader("\t");
            test = dmr.ReadMatrix("./TestData/Matrices/temp_writer.tab", StorageType.Dense);
            Assert.AreEqual(10, test.Rows);
            Assert.AreEqual(20, test.Columns);
            actual = matrix.FrobeniusNorm();
            error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);

            dmw = new DelimitedMatrixWriter(" ");
            dmr = new DelimitedMatrixReader();
            using (TextWriter tw = new StreamWriter("./TestData/Matrices/temp_writer.space"))
            {
                dmw.WriteMatrix(matrix, tw, format);
            }
            test = dmr.ReadMatrix("./TestData/Matrices/temp_writer.space", StorageType.Dense);
            Assert.AreEqual(10, test.Rows);
            Assert.AreEqual(20, test.Columns);
            actual = matrix.FrobeniusNorm();
            error = System.Math.Abs((actual - expected)/expected);
            Assert.IsTrue(error < Constants.IOAcceptableError);
        }
    }
}