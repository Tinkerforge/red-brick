﻿using dnAnalytics.Random;
using NUnit.Framework;

namespace dnAnalytics.Tests.Random
{
    [TestFixture]
    public class MersenneTwisterTests : RandomTests
    {
        public MersenneTwisterTests() : base(typeof (MersenneTwister))
        {
        }

#if MANAGED
        [Test]
        public void Sample_KnownValues()
        {
            MersenneTwister mt = new MersenneTwister(0);
            Assert.That(mt.NextDouble(), Is.EqualTo(0.5488135024320365));
            Assert.That(mt.NextDouble(), Is.EqualTo(0.5928446165269344));
            Assert.That(mt.NextDouble(), Is.EqualTo(0.7151893651381110));
            Assert.That(mt.NextDouble(), Is.EqualTo(0.8442657442866512));
        }

#endif
    }
}