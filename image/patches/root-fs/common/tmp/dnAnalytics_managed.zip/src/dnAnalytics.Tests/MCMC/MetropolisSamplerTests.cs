﻿using System;
using dnAnalytics.Mcmc;
using dnAnalytics.Statistics.Distributions;
using NUnit.Framework;

namespace dnAnalytics.Tests.MCMC
{
    [TestFixture]
    public class MetropolisSamplerTests
    {
        [Test]
        public void MetropolisConstructor()
        {
            var normal = new Normal(0.0, 1.0);
            var rnd = new dnAnalytics.Random.MersenneTwister();

            var ms = new MetropolisSampler<double>(0.2, normal.Density, x => Normal.Sample(rnd, x, 0.1), 10);
            Assert.IsNotNull(ms.RandomNumberGenerator);

            ms.RandomNumberGenerator = rnd;
            Assert.IsNotNull(ms.RandomNumberGenerator);
        }

        [Test]
        public void SampleTest()
        {
            var normal = new Normal(0.0, 1.0);
            var rnd = new dnAnalytics.Random.MersenneTwister();

            var ms = new MetropolisSampler<double>(0.2, normal.Density, x => Normal.Sample(rnd, x, 0.1), 10);
            ms.RandomNumberGenerator = rnd;

            double sample = ms.Sample();
        }

        [Test]
        public void SampleArrayTest()
        {
            var normal = new Normal(0.0, 1.0);
            var rnd = new dnAnalytics.Random.MersenneTwister();

            var ms = new MetropolisSampler<double>(0.2, normal.Density, x => Normal.Sample(rnd, x, 0.1), 10);
            ms.RandomNumberGenerator = rnd;

            double[] sample = ms.Sample(5);
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullRandomNumberGenerator()
        {
            var normal = new Normal(0.0, 1.0);
            var ms = new MetropolisSampler<double>(0.2, normal.Density, x => Normal.Sample(new System.Random(), x, 0.1), 10);
            ms.RandomNumberGenerator = null;
        }
    }
}
