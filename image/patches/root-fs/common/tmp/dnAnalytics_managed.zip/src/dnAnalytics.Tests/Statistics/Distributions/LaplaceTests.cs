using dnAnalytics.Statistics.Distributions;
using NUnit.Framework;

namespace dnAnalytics.Tests.Statistics.Distributions
{
    [TestFixture]
    public class LaplaceTests
    {
        private const double mAcceptableError = 1e-12;

        [Test]
        public void StandardLaplace()
        {
            Laplace laplace = new Laplace();

            Assert.AreEqual(0.0, laplace.Mean, mAcceptableError);
            Assert.AreEqual(System.Math.Sqrt(2.0), laplace.StdDev, mAcceptableError);
            Assert.AreEqual(2.0, laplace.Variance, mAcceptableError);

            Assert.AreEqual(0.5, laplace.Density(0.0), mAcceptableError);

            Assert.AreEqual(0.5, laplace.CumulativeDistribution(0.0), mAcceptableError);

            Assert.AreEqual(0.0, laplace.InverseCumulativeDistribution(0.5), mAcceptableError);
        }

        [Test]
        public void GetSetRNG()
        {
            Laplace laplace = new Laplace();

            // Try getting the random number generator.
            System.Random rnd = laplace.RandomNumberGenerator;
            // Try setting the random number generator.
            laplace.RandomNumberGenerator = new System.Random();
        }
    }
}