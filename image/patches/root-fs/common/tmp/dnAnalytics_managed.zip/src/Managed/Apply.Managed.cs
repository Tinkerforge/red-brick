﻿/* Copyright 2009 dnAnalytics Project.
 *
 * Contributors to this file:
 * Marcus Cuda
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this 
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * * Neither the name of the dnAnalytics Project nor the names of its contributors
 *   may be used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


using dnAnalytics.LinearAlgebra;
using dnAnalytics.Math;
using dnAnalytics.Threading;

namespace dnAnalytics
{
    public static partial class Apply
    {
        /// <summary>
        /// Raises each element to the given <paramref name="power"/>.
        /// </summary>
        /// <param name="vector">The list to apply power function to.</param>
        /// <param name="power">The power to raise each element to.</param>
        public static void Pow(this Vector vector, double power)
        {
            Parallel.For(0, vector.Count, i => { vector[i] = System.Math.Pow(vector[i], power); });
        }

        /// <summary>
        /// Raises each element to the given <paramref name="power"/>.
        /// </summary>
        /// <param name="matrix">The list to apply power function to.</param>
        /// <param name="power">The power to raise each element to.</param>
        public static void Pow(this Matrix matrix, double power)
        {
            Parallel.For(0, matrix.Rows, i =>
                                             {
                                                 for (var j = 0; j < matrix.Columns; j++)
                                                 {
                                                     matrix.ValueAt(i, j, System.Math.Pow(matrix.ValueAt(i, j), power));
                                                 }
                                             });
        }

        /// <summary>
        /// Applies the given <see cref="MapAction"/> to each element of the <paramref name="vector"/>.
        /// </summary>
        /// <param name="vector">The vector to apply the function to.</param>
        /// <param name="action">The function to apply.</param>
        public static void Map(this Vector vector, MapAction action)
        {
            Parallel.For(0, vector.Count, i => { vector[i] = action(vector[i]); });
        }

        /// <summary>
        /// Applies the given <see cref="MapAction"/> to each element of the <paramref name="matrix"/>.
        /// </summary>
        /// <param name="matrix">The list to apply the function to.</param>
        /// <param name="action">The function to apply.</param>
        public static void Map(this Matrix matrix, MapAction action)
        {
            Parallel.For(0, matrix.Rows, i =>
            {
                for (var j = 0; j < matrix.Columns; j++)
                {
                    matrix.ValueAt(i, j, action(matrix.ValueAt(i, j)));
                }
            });
        }
    }
}