/* Copyright 2008 dnAnalytics Project.
 *
 * Contributors to this file:
 * Marcus Cuda
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this 
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * * Neither the name of the dnAnalytics Project nor the names of its contributors
 *   may be used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

namespace dnAnalytics.LinearAlgebra
{
    /// <summary>
    /// Computes the Householder transformation of a vector.
    /// </summary>
    public partial class HouseholderTransformation
    {
        private Vector mVector;
        private double mBeta;

        /// <summary>
        /// The Householder reflection as a vector.  The vector is normalized so that V[0] = 1.
        /// </summary>
        /// <returns>The reflection vector.</returns>
        public Vector ReflectionVector()
        {
            return mVector.Clone();
        }

        /// <summary>
        /// The Householder reflection as a matrix.
        /// H = I - ( (2/v^Tv)*(vv^T)
        /// where v is Householder.Vector.
        /// </summary>
        /// <returns>The reflection matrix.</returns>
        public Matrix ReflectionMatrix()
        {
            Matrix I = mVector.CreateMatrix(mVector.Count, mVector.Count);
            for (int i = 0; i < mVector.Count; i++)
            {
                I[i,i] = 1.0;
            }
            double constant = 2.0 / mVector.DotProduct(mVector);
            Matrix vt = mVector.Multiply(mVector);
            return I - (constant*vt);
        }

        /// <summary>
        /// The transformation of the original vector. 
        /// transformation = H*v
        /// where H = Householder.Matrix and v is the original vector.
        /// </summary>
        /// <returns>The transformed vector.</returns>
        /// <remarks>All elements except the first are zero.</remarks>
        public Vector Transformation()
        {
            Vector ret = new DenseVector(mVector.Count);
            ret[0] = mBeta;
            return ret;
        }
    }
}
