﻿/* Copyright 2007 dnAnalytics Project.
 *
 * Contributors to this file:
 * Jurgen Van Gael
 * Marcus Cuda
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this 
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * * Neither the name of the dnAnalytics Project nor the names of its contributors
 *   may be used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

namespace dnAnalytics.Math
{
    /// <summary>
    /// This class contains a number of frequently used mathematical constants.
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// The Euler-Mascheroni Constant.
        /// </summary>
        public const double EulerMascheroni = 0.57721566490153286060651209008240243104215933593992;

        /// <summary>
        /// Pi.
        /// </summary>
        public const double Pi = System.Math.PI;

        /// <summary>
        /// 1.0 / Pi.
        /// </summary>
        public const double OneOverPi = 1.0 / System.Math.PI;

        /// <summary>
        /// The square root of 2*Pi.
        /// </summary>
        public static readonly double Sqrt2Pi = System.Math.Sqrt(2.0 * Pi);

        /// <summary>
        /// The square root of 2*Pi*E.
        /// </summary>
        public static readonly double Sqrt2PiE = System.Math.Sqrt(2.0 * Pi * E);

        /// <summary>
        /// The square root of log(2*Pi).
        /// </summary>
        public static readonly double LogSqrt2Pi = System.Math.Log(System.Math.Sqrt(2.0 * Pi));

        /// <summary>
        /// The square root of log(2*Pi*E).
        /// </summary>
        public static readonly double LogSqrt2PiE = System.Math.Log(System.Math.Sqrt(2.0 * Pi * E));

        /// <summary>
        /// E.
        /// </summary>
        public const double E = System.Math.E;

        /// <summary>
        /// The Golden ration.
        /// </summary>
        public const double GoldenRatio = 1.61803398874989484820458683436563811;
    }
}
