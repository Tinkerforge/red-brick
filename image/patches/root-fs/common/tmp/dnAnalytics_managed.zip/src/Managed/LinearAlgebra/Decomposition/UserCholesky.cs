﻿/* Copyright 2007-2008 dnAnalytics Project.
 *
 * Contributors to this file:
 * Patrick van der Velde
 * Marcus Cuda
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this 
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * * Neither the name of the dnAnalytics Project nor the names of its contributors
 *   may be used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
namespace dnAnalytics.LinearAlgebra.Decomposition
{
    internal class UserCholesky : AbstractCholesky
    {
        public UserCholesky(Matrix matrix) : base(matrix) {}

        protected override bool DoCompute(Matrix data, int order)
        {
            Matrix factor = data.CreateMatrix(order, order);
            for (int j = 0; j < order; j++)
            {
                double d = 0.0;
                for (int k = 0; k < j; k++)
                {
                    double s = 0.0;
                    int i;
                    for (i = 0; i < k; i++)
                    {
                        s += factor.ValueAt(k, i)*factor.ValueAt(j, i);
                    }
                    s = (data.ValueAt(j, k) - s)/factor.ValueAt(k, k);
                    factor.ValueAt(j, k, s);
                    d += s*s;
                }
                d = data.ValueAt(j, j) - d;
                if (d <= 0.0)
                {
                    return false;
                }
                factor.ValueAt(j, j, System.Math.Sqrt(d));
                for (int k = j + 1; k < order; k++)
                {
                    factor.ValueAt(j, k, 0.0);
                }
            }

            factor.CopyTo(data);
            return true;
        }

        protected override void DoSolve(Matrix factor, Matrix result)
        {
            int order = factor.Rows;

            for (int c = 0; c < result.Columns; c++)
            {
                // Solve L*Y = B;
                double sum;
                for (int i = 0; i < order; i++)
                {
                    sum = result.ValueAt(i, c);
                    for (int k = i - 1; k >= 0; k--)
                    {
                        sum -= factor.ValueAt(i, k)*result.ValueAt(k, c);
                    }
                    result.ValueAt(i, c, sum/factor.ValueAt(i, i));
                }

                // Solve L'*X = Y;
                for (int i = order - 1; i >= 0; i--)
                {
                    sum = result.ValueAt(i, c);
                    for (int k = i + 1; k < order; k++)
                    {
                        sum -= factor.ValueAt(k, i)*result.ValueAt(k, c);
                    }
                    result.ValueAt(i, c, sum/factor.ValueAt(i, i));
                }
            }
        }

        protected override void DoSolve(Matrix factor, Vector result)
        {
            int order = factor.Rows;

            // Solve L*Y = B;
            double sum;
            for (int i = 0; i < order; i++)
            {
                sum = result[i];
                for (int k = i - 1; k >= 0; k--)
                {
                    sum -= factor.ValueAt(i, k)*result[k];
                }
                result[i] = sum/factor.ValueAt(i, i);
            }

            // Solve L'*X = Y;
            for (int i = order - 1; i >= 0; i--)
            {
                sum = result[i];
                for (int k = i + 1; k < order; k++)
                {
                    sum -= factor.ValueAt(k, i)*result[k];
                }
                result[i] = sum/factor.ValueAt(i, i);
            }
        }
    }
}