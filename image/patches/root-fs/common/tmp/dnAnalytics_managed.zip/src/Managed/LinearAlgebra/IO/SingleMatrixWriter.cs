/* Copyright 2007-2008 dnAnalytics Project.
 *
 * Contributors to this file:
 * Patrick van der Velde
 * Marcus Cuda
 * Jurgen Van Gael
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this 
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * * Neither the name of the dnAnalytics Project nor the names of its contributors
 *   may be used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
using System;
using System.IO;

namespace dnAnalytics.LinearAlgebra.IO
{
    /// <summary>
    /// Base class to write a single <see cref="Matrix"/> to a file or stream.
    /// </summary>
    public abstract class SingleMatrixWriter : ISingleMatrixWriter
    {
        /// <summary>
        /// Writes the given <see cref="Matrix"/> to the given file. If the file already exists, 
        /// the file will be overwritten.
        /// </summary>
        /// <param name="matrix">The matrix to write.</param>
        /// <param name="file">The file to write the matrix to.</param>
        /// <exception cref="ArgumentNullException">If either <paramref name="matrix"/> or <paramref name="file"/> is null.</exception>
        public void WriteMatrix(Matrix matrix, string file)
        {
            if (matrix == null)
            {
                throw new ArgumentNullException("matrix");
            }
            if (file == null)
            {
                throw new ArgumentNullException("file");
            }

            using (StreamWriter writer = new StreamWriter(file))
            {
                DoWriteMatrix(matrix, writer, null);
            }
        }

        /// <summary>
        /// Writes the given <see cref="Matrix"/> to the given file. If the file already exists, 
        /// the file will be overwritten.
        /// </summary>
        /// <param name="matrix">the matrix to write.</param>
        /// <param name="file">The file to write the matrix to.</param>
        /// <param name="format">The format to use on each element.</param>
        /// <exception cref="ArgumentNullException">If either <paramref name="matrix"/> or <paramref name="file"/> is null.</exception>
        public void WriteMatrix(Matrix matrix, string file, string format)
        {
            if (matrix == null)
            {
                throw new ArgumentNullException("matrix");
            }
            if (file == null)
            {
                throw new ArgumentNullException("file");
            }

            if (File.Exists(file))
            {
                File.Delete(file);
            }

            using (StreamWriter writer = new StreamWriter(file) )
            {
                DoWriteMatrix(matrix, writer, format);
            }
        }

        /// <summary>
        /// Writes the given <see cref="Matrix"/> to the given stream.
        /// </summary>
        /// <param name="matrix">The matrix to write.</param>
        /// <param name="stream">The <see cref="Stream"/> to write the matrix to.</param>
        /// <exception cref="ArgumentNullException">If either <paramref name="matrix"/> or <paramref name="stream"/> is null.</exception>
        public void WriteMatrix(Matrix matrix, Stream stream)
        {
            if (matrix == null)
            {
                throw new ArgumentNullException("matrix");
            }
            if (stream == null)
            {
                throw new ArgumentNullException("stream");
            }

            using (StreamWriter writer = new StreamWriter(new BufferedStream(stream)))
            {
                DoWriteMatrix(matrix, writer, null);
            }
        }

        /// <summary>
        /// Writes the given <see cref="Matrix"/> to the given stream.
        /// </summary>
        /// <param name="matrix">The <see cref="TextWriter"/> to write.</param>
        /// <param name="stream">The <see cref="Stream"/> to write the matrix to.</param>
        /// <param name="format">The format to use on each element.</param>
        /// <exception cref="ArgumentNullException">If either <paramref name="matrix"/> or <paramref name="stream"/> is null.</exception>
        public void WriteMatrix(Matrix matrix, Stream stream, string format)
        {
            if (matrix == null)
            {
                throw new ArgumentNullException("matrix");
            }
            if (stream == null)
            {
                throw new ArgumentNullException("stream");
            }

            using (StreamWriter writer = new StreamWriter(new BufferedStream(stream)))
            {
                DoWriteMatrix(matrix, writer, format);
            }
        }

        /// <summary>
        /// Writes the given <see cref="Matrix"/> to the given <b>TextWriter</b>.
        /// </summary>
        /// <param name="matrix">The matrix to write.</param>
        /// <param name="writer">The <see cref="TextWriter"/> to write the matrix to.</param>
        /// <exception cref="ArgumentNullException">If either <paramref name="matrix"/> or <paramref name="writer"/> is null.</exception>
        public void WriteMatrix(Matrix matrix, TextWriter writer)
        {
            if (matrix == null)
            {
                throw new ArgumentNullException("matrix");
            }
            if (writer == null)
            {
                throw new ArgumentNullException("writer");
            }
            DoWriteMatrix(matrix, writer, null);
        }

        /// <summary>
        /// Writes the given <see cref="Matrix"/> to the given <b>TextWriter</b>.
        /// </summary>
        /// <param name="matrix">The matrix to write.</param>
        /// <param name="writer">The <see cref="TextWriter"/> to write the matrix to.</param>
        /// <param name="format">The format to use on each element.</param>
        /// <exception cref="ArgumentNullException">If either <paramref name="matrix"/> or <paramref name="writer"/> is null.</exception>
        public void WriteMatrix(Matrix matrix, TextWriter writer, string format)
        {
            if (matrix == null)
            {
                throw new ArgumentNullException("matrix");
            }
            if (writer == null)
            {
                throw new ArgumentNullException("writer");
            }
            DoWriteMatrix(matrix, writer, format);
        }

        /// <summary>
        /// Subclasses must implement this method to do the actually writing.
        /// </summary>
        /// <param name="matrix">The matrix to serialize.</param>
        /// <param name="writer">The <see cref="TextWriter"/> to write the matrix to.</param>
        /// <param name="format">The format for the new matrix.</param>
        protected abstract void DoWriteMatrix(Matrix matrix, TextWriter writer, string format);
    }
}
