﻿/* Copyright 2007-2008 dnAnalytics Project.
 *
 * Contributors to this file:
 * Jurgen Van Gael
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this 
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * * Neither the name of the dnAnalytics Project nor the names of its contributors
 *   may be used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

using System;
using dnAnalytics.Properties;

namespace dnAnalytics.Statistics.Distributions
{
    /// <summary>
    /// The continuous uniform distribution is a distribution over real numbers. The distribution
    /// is parameterized by a lower and upper bound.
    /// </summary>
    /// <remarks>The distribution will use the <see cref="System.Random"/> by default. 
    /// Users can set the random number generator by using the <see cref="RandomNumberGenerator"/> property.
    /// 
    /// The statistics classes will check all the incoming parameters whether they are in the allowed
    /// range. This might involve heavy computation. Optionally, by setting Control.CheckDistributionParameters
    /// to false, all parameter checks can be turned off.</remarks>
    public class ContinuousUniform : IContinuousDistribution
    {
        /// <summary>
        /// The distribution's lower bound.
        /// </summary>
        protected double mLower;

        /// <summary>
        /// The distribution's upper bound.
        /// </summary>
        protected double mUpper;

        /// <summary>
        /// Construct a new uniform distribution between 0 and 1.
        /// </summary>
        public ContinuousUniform() : this(0.0, 1.0)
        {
        }

        /// <summary>
        /// Construct a new uniform distribution with given lower and upper bounds.
        /// </summary>
        /// <param name="lower">Lower bound.</param>
        /// <param name="upper">Upper bound; must be at least as large as <paramref name="lower"/>.</param>
        /// <exception cref="ArgumentException">If the upper bound is smaller than the lower bound.</exception>
        public ContinuousUniform(double lower, double upper)
        {
            if (Control.CheckDistributionParameters)
            {
                CheckParameters(lower, upper);
            }

            mLower = lower;
            mUpper = upper;
            RandomNumberGenerator = new System.Random();
        }

        /// <summary>
        /// A string representation of the distribution.
        /// </summary>
        public override string ToString()
        {
            return "ContinuousUniform(Lower = " + mLower + ", Upper = " + mUpper + ")";
        }

        #region IDistribution Members

        /// <summary>
        /// The mean of the distribution.
        /// </summary>
        /// <value></value>
        public double Mean
        {
            get { return (mLower + mUpper)/2.0; }
        }

        /// <summary>
        /// The standard deviation of the distribution.
        /// </summary>
        /// <value></value>
        public double StdDev
        {
            get { return (mUpper - mLower)/System.Math.Sqrt(12.0); }
        }

        /// <summary>
        /// The variance of the distribution.
        /// </summary>
        /// <value></value>
        public double Variance
        {
            get { return (mUpper - mLower)*(mUpper - mLower)/12.0; }
        }

        /// <summary>
        /// The entropy of the distribution.
        /// </summary>
        /// <value></value>
        public double Entropy
        {
            get { return System.Math.Log(mUpper - mLower); }
        }

        /// <summary>
        /// Gets or sets the random number generator.
        /// </summary>
        /// <value>The random number generator used to generate a random sample.</value>
        public System.Random RandomNumberGenerator { get; set; }

        #endregion

        #region IContinuousDistribution Members

        /// <summary>
        /// The mode of the distribution.
        /// </summary>
        /// <value></value>
        public double Mode
        {
            get { return (mLower + mUpper)/2.0; }
        }

        /// <summary>
        /// The median of the distribution.
        /// </summary>
        /// <value></value>
        public double Median
        {
            get { return (mLower + mUpper)/2.0; }
        }

        /// <summary>
        /// Computes values of the probability density function.
        /// </summary>
        /// <param name="x">The location in the domain where we want to evaluate the probability density function.</param>
        /// <returns></returns>
        public double Density(double x)
        {
            if (x >= mLower && x <= mUpper)
            {
                return 1.0/(mUpper - mLower);
            }
            return 0.0;
        }

        /// <summary>
        /// Samples a uniformly distributed random variable.
        /// </summary>
        public double Sample()
        {
            return DoSample(RandomNumberGenerator, mLower, mUpper);
        }

        /// <summary>
        /// Samples an array of uniformly distributed random variables.
        /// </summary>
        /// <param name="n">The number of variables needed.</param>
        public double[] Sample(int n)
        {
            return DoSample(RandomNumberGenerator, n, mLower, mUpper);
        }

        #endregion

        /// <summary>
        /// Samples a uniformly distributed random variable.
        /// </summary>
        /// <param name="rnd">The random number generator to use.</param>
        /// <param name="lower">The lower bound of the uniform random variable.</param>
        /// <param name="upper">The upper bound of the uniform random variable.</param>
        public static double Sample(System.Random rnd, double lower, double upper)
        {
            CheckParameters(lower, upper);
            return DoSample(rnd, lower, upper);
        }

        /// <summary>
        /// Samples an array of uniformly distributed random variables.
        /// </summary>
        /// <param name="rnd">The random number generator to use.</param>
        /// <param name="n">The number of variables needed.</param>
        /// <param name="lower">The lower bound of the uniform random variable.</param>
        /// <param name="upper">The upper bound of the uniform random variable.</param>
        public static double[] Sample(System.Random rnd, int n, double lower, double upper)
        {
            if (Control.CheckDistributionParameters)
            {
                CheckParameters(lower, upper);
            }

            return DoSample(rnd, n, lower, upper);
        }

        private static void CheckParameters(double lower, double upper)
        {
            if (upper < lower)
            {
                throw new ArgumentException(Resources.UpperMustBeAtleastAsLargeAsLower);
            }
        }

        private static double DoSample(System.Random rnd, double lower, double upper)
        {
            return lower + rnd.NextDouble()*(upper - lower);
        }

        private static double[] DoSample(System.Random rnd, int n, double lower, double upper)
        {
            if (Control.CheckDistributionParameters)
            {
                CheckParameters(lower, upper);
            }

            double[] arr = new double[n];
            for (int i = 0; i < n; i++)
            {
                arr[i] = DoSample(rnd, lower, upper);
            }
            return arr;
        }
    }
}