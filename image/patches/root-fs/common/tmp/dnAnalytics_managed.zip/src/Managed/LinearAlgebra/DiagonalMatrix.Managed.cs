/* Copyright 2009 dnAnalytics Project.
 *
 * Contributors to this file:
 * Jurgen Van Gael
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this 
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * * Neither the name of the dnAnalytics Project nor the names of its contributors
 *   may be used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
using System;
using dnAnalytics.Math;
using dnAnalytics.Properties;

namespace dnAnalytics.LinearAlgebra
{
    public partial class DiagonalMatrix
    {
        /// <summary>
        /// Adds another matrix to this matrix.
        /// </summary>
        /// <param name="other">The matrix to add to this matrix.</param>
        /// <exception cref="ArgumentNullException">If the other matrix is <see langword="null"/>.</exception>
        /// <exception cref="NotConformableException">If the two matrices don't have the same dimensions.</exception>
        public override void Add(Matrix other)
        {
            if (other == null)
            {
                throw new ArgumentNullException("other");
            }

            if ((other.Rows != Rows) || (other.Columns != Columns))
            {
                throw new NotConformableException("other", Resources.ParameterNotConformable);
            }

            if (ReferenceEquals(this, other))
            {
                Multiply(2);
                return;
            }

            DiagonalMatrix matrix = other as DiagonalMatrix;
            if (matrix == null)
            {
                throw new ArgumentException("Cannot add a non diagonal matrix to a diagonal matrix: the types are incompatible.");
            }
                for (int i = 0; i < mData.Length; i++)
                {
                    mData[i] += matrix.mData[i];
                }
        }

        /// <summary>
        /// Negates each element of this matrix.
        /// </summary>        
        public override void Negate()
        {
            for (int i = 0; i < mData.Length; i++)
            {
                mData[i] = -mData[i];
            }
        }

        /// <summary>
        /// Subtracts another matrix from this matrix.
        /// </summary>
        /// <param name="other">The matrix to subtract.</param>
        /// <exception cref="ArgumentNullException">If the other matrix is <see langword="null"/>.</exception>
        /// <exception cref="NotConformableException">If the two matrices don't have the same dimensions.</exception>
        public override void Subtract(Matrix other)
        {
            if (other == null)
            {
                throw new ArgumentNullException("other");
            }

            if ((other.Rows != Rows) || (other.Columns != Columns))
            {
                throw new NotConformableException("other", Resources.ParameterNotConformable);
            }

            if (ReferenceEquals(this, other))
            {
                Clear();
                return;
            }

            DiagonalMatrix matrix = other as DiagonalMatrix;
            if (matrix != null)
            {
                for (int i = 0; i < mData.Length; i++)
                {
                    mData[i] -= matrix.mData[i];
                }
            }
            else
            {
                throw new ArgumentException("Cannot subtract a non diagonal matrix from a diagonal matrix: the types are incompatible.");
            }
        }

        /// <summary>
        /// Multiplies each element of this matrix with a scalar overwriting the values of this matrix.
        /// </summary>
        /// <param name="scalar">the scalar to multiply with.</param>
        public override void Multiply(double scalar)
        {
            // if double = 0.0 then just reset the
            // value count to zero
            // Check if the value is not zero.
            if (scalar == 0.0)
            {
                Clear();
                return;
            }

            if (scalar == 1.0)
            {
                return;
            }

            for (int i = 0; i < mData.Length; i++)
            {
                mData[i] *= scalar;
            }
        }

        /// <summary>
        /// Multiplies two matrices.
        /// </summary>
        /// <param name="leftSide">One of the matrices to multiply.</param>
        /// <param name="rightSide">One of the matrices to multiply.</param>
        /// <returns>The result of multiplication.</returns>
        /// <exception cref="ArgumentNullException">If <paramref name="leftSide"/> or <paramref name="rightSide"/> is <see langword="null" />.</exception>
        /// <exception cref="NotConformableException">If the dimensions of <paramref name="leftSide"/> or <paramref name="rightSide"/> don't conform.</exception>
        public static DiagonalMatrix operator *(DiagonalMatrix leftSide, DiagonalMatrix rightSide)
        {
            if (leftSide == null)
            {
                throw new ArgumentNullException("leftSide");
            }

            if (rightSide == null)
            {
                throw new ArgumentNullException("rightSide");
            }

            if (leftSide.Columns != rightSide.Rows)
            {
                throw new NotConformableException(Resources.ParametersNotConformable);
            }

            DiagonalMatrix D = new DiagonalMatrix(leftSide.Rows, rightSide.Columns);
            for (int i = 0; i < System.Math.Min(leftSide.mData.Length, rightSide.mData.Length); i++)
            {
                D[i, i] = leftSide.mData[i] * rightSide.mData[i];
            }
            return D;
        }
    }
}