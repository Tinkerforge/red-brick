/* Copyright 2007 dnAnalytics Project.
 *
 * Contributors to this file:
 * Patrick van der Velde
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this 
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * * Neither the name of the dnAnalytics Project nor the names of its contributors
 *   may be used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

using System;
using System.Diagnostics;
using System.Collections.Generic;

namespace dnAnalytics.Math
{
    /// <summary>
    /// Utilities for working with floating point numbers.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Useful links:
    /// <list type="bullet">
    /// <item>
    /// http://docs.sun.com/source/806-3568/ncg_goldberg.html#689 - What every computer scientist should know about floating-point arithmetic
    /// </item>
    /// <item>
    /// http://en.wikipedia.org/wiki/Machine_epsilon - Gives the definition of machine epsilon
    /// </item>
    /// </list>
    /// </para>
    /// </remarks>
    public static class Precision
    {
        #region Internal class - DoubleComparer
        
        /// <summary>
        /// An <c>IComparer</c> used to compare double precision floating points based
        /// on either the ULPs (Units in Last Place) or the number of significant digits.
        /// </summary>
        public sealed class DoubleComparer : IComparer<double>
        {
            /// <summary>
            /// The number of ULPs for the comparison. Set to -1 if not in use.
            /// </summary>
            private long m_Ulps = -1;

            /// <summary>
            /// The number of significant digits used for the comparison. Set to -1 if not in use.
            /// </summary>
            private int m_NumberOfSignificantDigits = -1;

            /// <summary>
            /// Creates a new <c>DoubleComparer</c> which will compare floating points
            /// based on the number of ULPs (Units in Last Place).
            /// </summary>
            /// <param name="ulps">
            ///   The number of ULPs used in the comparison
            /// </param>
            public DoubleComparer(long ulps)
            {
                if (ulps < 0)
                {
                    throw new ArgumentOutOfRangeException("ulps");
                }

                m_Ulps = ulps;
            }

            /// <summary>
            /// Creates a new <c>DoubleComparer</c> which will compare floating points
            /// based on the number of significant digits.
            /// </summary>
            /// <param name="numberOfSignificantDigits">
            ///   The number of significant digits used in the comparison.
            /// </param>
            public DoubleComparer(int numberOfSignificantDigits)
            {
                if (numberOfSignificantDigits < 1)
                {
                    throw new ArgumentOutOfRangeException("numberOfSignificantDigits");
                }

                m_NumberOfSignificantDigits = numberOfSignificantDigits;
            }

            /// <summary>
            /// Gets or sets the number of ULPs (Units in Last Place) with which to compare
            /// floating point values.
            /// </summary>
            public long Ulps
            {
                get
                {
                    return m_Ulps;
                }
                set
                {
                    if (value < 0)
                    {
                        throw new ArgumentOutOfRangeException("value");
                    }

                    // Reset the significant digits number
                    m_NumberOfSignificantDigits = -1;
                    // Store the ulps
                    m_Ulps = value;
                }
            }

            /// <summary>
            /// Gets or sets the number of significant decimals with which to compare
            /// floating point values.
            /// </summary>
            public int NumberOfSignificantDecimals
            {
                get
                {
                    return m_NumberOfSignificantDigits;
                }
                set
                {
                    if (value < 1)
                    {
                        throw new ArgumentOutOfRangeException("value");
                    }

                    // Reset the ulps number
                    m_Ulps = -1;
                    // Store the number of significant digits.
                    m_NumberOfSignificantDigits = value;
                }
            }

            /// <summary>
            /// Compares two double values based on the selected comparison method.
            /// </summary>
            /// <param name="x">The first double to compare.</param>
            /// <param name="y">The second double to compare.</param>
            /// <returns>
            /// A 32-bit signed integer that indicates the relative order of the objects being compared. The return 
            /// value has the following meanings: 
            /// Value Meaning Less than zero This object is less than the other parameter.
            /// Zero This object is equal to other. 
            /// Greater than zero This object is greater than other. 
            /// </returns>
            /// <seealso cref="Ulps"/>
            /// <seealso cref="NumberOfSignificantDecimals"/>
            public int Compare(double x, double y)
            {
                return (m_Ulps > -1) ? CompareWithTolerance(x, y, m_Ulps)
                    : CompareWithDecimalPlaces(x, y, m_NumberOfSignificantDigits);
            }
        } 
        #endregion

        #region Constants

        /// <summary>
        /// The base number for binary values
        /// </summary>
        private const int s_BinaryBaseNumber = 2;

        /// <summary>
        /// The number of binary digits used to represent the binary number for a double precision floating
        /// point value. i.e. there are this many digits used to represent the
        /// actual number, where in a number as: 0.134556 * 10^5 the digits are 0.134556 and the exponent is 5.
        /// </summary>
        private const int s_DoublePrecision = 53;

        /// <summary>
        /// The number of binary digits used to represent the binary number for a single precision floating
        /// point value. i.e. there are this many digits used to represent the
        /// actual number, where in a number as: 0.134556 * 10^5 the digits are 0.134556 and the exponent is 5.
        /// </summary>
        private const int s_SinglePrecision = 24;

        /// <summary>
        /// The maximum relative precision of a double
        /// </summary>
        private static readonly double _doubleMachinePrecision = System.Math.Pow(s_BinaryBaseNumber, -s_DoublePrecision);

 
        #endregion

        #region Fields
        
        /// <summary>
        /// The maximum relative precision of a double
        /// </summary>
        private static readonly double s_DoubleMachinePrecision = System.Math.Pow(s_BinaryBaseNumber, -s_DoublePrecision);

        /// <summary>
        /// The maximum relative precision of a single
        /// </summary>
        private static readonly double s_SingleMachinePrecision = System.Math.Pow(s_BinaryBaseNumber, -s_SinglePrecision);

        /// <summary>
        /// The number of significant figures that a double-precision floating point has.
        /// </summary>
        private static readonly int s_NumberOfDecimalPlacesForDoubles;

        /// <summary>
        /// The number of significant figures that a single-precision floating point has.
        /// </summary>
        private static readonly int s_NumberOfDecimalPlacesForFloats; 

        #endregion

        /// <summary>
        /// Initializes the <see cref="Precision"/> class.
        /// </summary>
        static Precision()
        {
            s_NumberOfDecimalPlacesForFloats = (int)System.Math.Ceiling(System.Math.Abs(System.Math.Log10(s_SingleMachinePrecision)));
            s_NumberOfDecimalPlacesForDoubles = (int)System.Math.Ceiling(System.Math.Abs(System.Math.Log10(s_DoubleMachinePrecision)));
        }

        /// <summary>
        /// Gets the number of decimal places for floats.
        /// </summary>
        /// <value>The number of decimal places for floats.</value>
        public static int NumberOfDecimalPlacesForFloats
        {
            get
            {
                return s_NumberOfDecimalPlacesForFloats;
            }
        }

        /// <summary>
        /// Gets the number of decimal places for doubles.
        /// </summary>
        /// <value>The number of decimal places for doubles.</value>
        public static int NumberOfDecimalPlacesForDoubles
        {
            get
            {
                return s_NumberOfDecimalPlacesForDoubles;
            }
        }

        /// <summary>
        /// Returns the magnitude of the number.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public static int Magnitude(double value)
        {
            // Can't do this with zero because the 10-log of zero doesn't exist.
            if (value.Equals(0.0))
            {
                return 0;
            }

            // Note that we need the absolute value of the input because Log10 doesn't
            // work for negative numbers (obviously).
            double magnitude = System.Math.Log10(System.Math.Abs(value));

            // To get the right number we need to know if the value is negative or positive
            // truncating a positive number will always give use the correct magnitude
            // truncating a negative number will give us a magnitude that is off by 1
            if (magnitude < 0)
            {
                return ((int)(System.Math.Truncate(magnitude - 1)));
            }
            return ((int)(System.Math.Truncate(magnitude)));
        }

        /// <summary>
        /// Returns the number divided by it's magnitude, effectively returning a number between -10 and 10.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public static double Value(double value)
        {
            if (value.Equals(0.0))
            {
                return value;
            }

            int magnitude = Magnitude(value);
            return value * (System.Math.Pow(10, -magnitude));
        }

        /// <summary>
        /// Determines the range of floating point numbers that will match the specified value with the given tolerance.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="ulpsDifference">The ulps difference.</param>
        /// <param name="topRangeEnd">The top range end.</param>
        /// <param name="bottomRangeEnd">The bottom range end.</param>
        public static void RangeOfMatchingFloatingPointNumbers(double value, long ulpsDifference, out double bottomRangeEnd, out double topRangeEnd)
        {
            // Make sure ulpDifference is non-negative
            if (ulpsDifference < 1)
            {
                throw new ArgumentOutOfRangeException("ulpsDifference");
            }

            // If the value is infinity (positive or negative) just
            // return the same infinity for the range.
            if ((double.IsInfinity(value)))
            {
                topRangeEnd = value;
                bottomRangeEnd = value;
                return;
            }

            // If the value is a NaN then the range is a NaN too.
            if (double.IsNaN(value))
            {
                topRangeEnd = double.NaN;
                bottomRangeEnd = double.NaN;
                return;
            }

            // Translate the bit pattern of the double to an integer.
            // Note that this leads to:
            // double > 0 --> long > 0, growing as the double value grows
            // double < 0 --> long < 0, increasing in absolute magnitude as the double 
            //                          gets closer to zero!
            //                          i.e. 0 - double.epsilon will give the largest long value!
            long intValue = GetLongFromDouble(value);

            // We need to protect against over- and under-flow of the intValue when
            // we start to add the ulpsDifference.
            if (intValue < 0)
            {
                // Note that long.MinValue has the same bit pattern as
                // -0.0. Therefore we're working in opposite direction (i.e. add if we want to
                // go more negative and subtract if we want to go less negative)
                if (System.Math.Abs(long.MinValue - intValue) < ulpsDifference)
                {
                    // Got underflow, which can be fixed by splitting the calculation into two bits
                    // first get the remainder of the intValue after subtracting it from the long.MinValue
                    // and add that to the ulpsDifference. That way we'll turn positive without underflow
                    topRangeEnd = BitConverter.Int64BitsToDouble(ulpsDifference + (long.MinValue - intValue));
                }
                else
                {
                    // No problems here, move along.
                    topRangeEnd = BitConverter.Int64BitsToDouble(intValue - ulpsDifference);
                }

                if (System.Math.Abs(intValue) < ulpsDifference)
                {
                    // Underflow, which means we'd have to go further than a long would allow us.
                    // Also we couldn't translate it back to a double, so we'll return -Double.MaxValue
                    bottomRangeEnd = -double.MaxValue;
                }
                else
                {
                    // intValue is negative. Adding the positive ulpsDifference means that it gets less negative.
                    // However due to the conversion way this means that the actual double value gets more negative :-S
                    bottomRangeEnd = BitConverter.Int64BitsToDouble(intValue + ulpsDifference);
                }
            }
            else
            {
                // IntValue is positive
                if (long.MaxValue - intValue < ulpsDifference)
                {
                    // Overflow, which means we'd have to go further than a long would allow us.
                    // Also we couldn't translate it back to a double, so we'll return Double.MaxValue 
                    topRangeEnd = double.MaxValue;
                }
                else
                {
                    // No troubles here
                    topRangeEnd = BitConverter.Int64BitsToDouble(intValue + ulpsDifference);
                }

                // Check the bottom range end for underflows
                if (intValue > ulpsDifference)
                {
                    // No problems here. IntValue is larger than ulpsDifference so we'll end up with a
                    // positive number.
                    bottomRangeEnd = BitConverter.Int64BitsToDouble(intValue - ulpsDifference);
                }
                else
                {
                    // Int value is bigger than zero but smaller than the ulpsDifference. So we'll need to deal with
                    // the reversal at the negative end
                    bottomRangeEnd = BitConverter.Int64BitsToDouble(long.MinValue + (ulpsDifference - intValue));
                }
            }
        }

        /// <summary>
        /// Returns the floating point number that will match the value with the tolerance on the maximum size (i.e. the result is
        /// always bigger than the value)
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="ulpsDifference">The ulps difference.</param>
        /// <returns></returns>
        public static double MaximumMatchingFloatingPointNumber(double value, long ulpsDifference)
        {
            double topRangeEnd, bottomRangeEnd;
            RangeOfMatchingFloatingPointNumbers(value, ulpsDifference, out bottomRangeEnd, out topRangeEnd);
            return topRangeEnd;
        }

        /// <summary>
        /// Returns the floating point number that will match the value with the tolerance on the minimum size (i.e. the result is
        /// always smaller than the value)
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="ulpsDifference">The ulps difference.</param>
        /// <returns></returns>
        public static double MinimumMatchingFloatingPointNumber(double value, long ulpsDifference)
        {
            double topRangeEnd, bottomRangeEnd;
            RangeOfMatchingFloatingPointNumbers(value, ulpsDifference, out bottomRangeEnd, out topRangeEnd);
            return bottomRangeEnd;
        }

        /// <summary>
        /// Determines the range of ulps that will match the specified value with the given tolerance.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="relativeDifference">The relative difference.</param>
        /// <param name="topRangeEnd">The number of ULPS between the <c>value</c> and the <c>value + relativeDifference</c>.</param>
        /// <param name="bottomRangeEnd">The number of ULPS between the <c>value</c> and the <c>value - relativeDifference</c>.</param>
        public static void RangeOfMatchingUlps(double value, double relativeDifference, out long bottomRangeEnd, out long topRangeEnd)
        {
            // Make sure the relative is non-negative 
            if (relativeDifference < 0)
            {
                throw new ArgumentOutOfRangeException("relativeDifference");
            }

            // If the value is infinity (positive or negative) then
            // we can't determine the range.
            if ((double.IsInfinity(value)))
            {
                throw new ArgumentOutOfRangeException();
            }

            // If the value is a NaN then we can't determine the range.
            if (double.IsNaN(value))
            {
                throw new ArgumentOutOfRangeException();
            }

            // If the value is zero (0.0) then we can't calculate the relative difference
            // so return the ulps counts for the difference.
            if (value.Equals(0))
            {
                topRangeEnd = GetLongFromDouble(relativeDifference);
                bottomRangeEnd = topRangeEnd;
                return;
            }

            // Calculate the ulps for the maximum and minimum values
            // Note that these can overflow
            long max = GetDirectionalLongFromDouble(value + relativeDifference * System.Math.Abs(value));
            long min = GetDirectionalLongFromDouble(value - relativeDifference * System.Math.Abs(value));

            // Calculate the ulps from the value
            long intValue = GetDirectionalLongFromDouble(value);

            // Determine the ranges
            topRangeEnd = System.Math.Abs(max - intValue);
            bottomRangeEnd = System.Math.Abs(intValue - min);
        }

        /// <summary>
        /// Compares two doubles and determines if they are equal to within the tolerance or not. Equality comparison is based on the binary representation.
        /// </summary>
        /// <remarks>
        /// <para>
        /// Determines the 'number' of floating point numbers between two values (i.e. the number of discrete steps 
        /// between the two numbers) and then checks if that is within the specified tolerance. So if a tolerance 
        /// of 1 is passed then the result will be true only if the two numbers have the same binary representation 
        /// OR if they are two adjacent numbers that only differ by one step.
        /// </para>
        /// <para>
        /// The comparison method used is explained in http://www.cygnus-software.com/papers/comparingfloats/comparingfloats.htm . The article
        /// at http://www.extremeoptimization.com/resources/Articles/FPDotNetConceptsAndFormats.aspx explains how to transform the C code to 
        /// .NET enabled code without using pointers and unsafe code.
        /// </para>
        /// </remarks>
        /// <param name="first">The first value.</param>
        /// <param name="second">The second value.</param>
        /// <param name="maxUlps">The maximum error in terms of Units in Last Place (ulps), i.e. the maximum number of decimals that may be different. Must be 1 or larger.</param>
        /// <returns><see langword="true" /> if both doubles are equal to each other within the specified tolerance; otherwise <see langword="false" />.</returns>
        public static bool EqualsWithTolerance(double first, double second, long maxUlps)
        {
            // Make sure maxUlps is non-negative and small enough that the
            // default NAN won't compare as equal to anything.
            if (maxUlps < 1)
            {
                throw new ArgumentOutOfRangeException("maxUlps");
            }

            // If A or B are infinity (positive or negative) then
            // only return true if they are exactly equal to each other -
            // that is, if they are both infinities of the same sign.
            if ((double.IsInfinity(first)) || (double.IsInfinity(second)))
            {
                return (first == second);
            }

            // If A or B are a NAN, return false. NANs are equal to nothing,
            // not even themselves.
            if (double.IsNaN(first) || double.IsNaN(second))
            {
                return false;
            }

            // Get the first double and convert it to an integer value (by using the binary representation)
            long firstUlong = GetDirectionalLongFromDouble(first);

            // Get the second double and convert it to an integer value (by using the binary representation)
            long secondUlong = GetDirectionalLongFromDouble(second);

            // Now compare the values. 
            // Note that this comparison can overflow so we'll approach this differently
            // Do note that we could overflow this way too. We should probably check that we don't.
            return (first > second) ? (secondUlong + maxUlps >= firstUlong) : (firstUlong + maxUlps >= secondUlong);
        }

        private static long GetLongFromDouble(double value)
        {
            return BitConverter.DoubleToInt64Bits(value);
        }

        private static long GetDirectionalLongFromDouble(double value)
        {
            // Convert in the normal way.
            long result = GetLongFromDouble(value);
            // Now find out where we're at in the range
            // If the value is larger/equal to zero then we can just return the value
            // if the value is negative we subtract long.MinValue from it.
            return (result >= 0) ? result : (long.MinValue - result);
        }

        /// <summary>
        /// Compares two doubles and determines if they are equal to within the specified number of decimal places or not. If the numbers
        /// are very close to zero an absolute difference is compared, otherwise the relative difference is compared.
        /// </summary>
        /// <remarks>
        /// <para>
        /// The values are equal if the difference between the two numbers is smaller than 10^(-numberOfDecimalPlaces). We divide by 
        /// two so that we have half the range on each side of the numbers, e.g. if decimalPlaces == 2, then 0.01 will equal between 
        /// 0.005 and 0.015, but not 0.02 and not 0.00
        /// </para>
        /// </remarks>
        /// <param name="first">The first value.</param>
        /// <param name="second">The second value.</param>
        /// <param name="numberOfDecimalPlaces">The number of decimal places.</param>
        /// <returns><see langword="true" /> if both doubles are equal to each other within the specified number of decimal places; otherwise <see langword="false" />.</returns>
        public static bool EqualsWithinDecimalPlaces(double first, double second, int numberOfDecimalPlaces)
        {
            // If A or B are a NAN, return false. NANs are equal to nothing,
            // not even themselves.
            if ((double.IsNaN(first)) || (double.IsNaN(second)))
            {
                return false;
            }

            // If A or B are infinity (positive or negative) then
            // only return true if they are exactly equal to each other -
            // that is, if they are both infinities of the same sign.
            if ((double.IsInfinity(first)) || (double.IsInfinity(second)))
            {
                return (first == second);
            }

            if (numberOfDecimalPlaces <= 0)
            {
                // Can't have a negative number of decimal places
                throw new ArgumentOutOfRangeException("numberOfSignificantFigures");
            }

            // If both numbers are equal, get out now. This should remove the possibility of both numbers being zero
            // and any problems associated with that.
            if (first.Equals(second))
            {
                return true;
            }

            // If the numbers are very close to zero, use absolute comparison, otherwise use relative comparison
            if ((System.Math.Abs(first) < (10 * s_DoubleMachinePrecision)) || (System.Math.Abs(second) < (10 * s_DoubleMachinePrecision)))
            {
                return EqualsWithinAbsoluteDecimalPlaces(first, second, numberOfDecimalPlaces);
            }
            return EqualsWithinRelativeDecimalPlaces(first, second, numberOfDecimalPlaces);
        }

        /// <summary>
        /// Compares two doubles and determines if they are equal to within the specified number of decimal places or not. 
        /// </summary>
        /// <remarks>
        /// <para>
        /// The values are equal if the difference between the two numbers is smaller than 10^(-numberOfDecimalPlaces). We divide by 
        /// two so that we have half the range on each side of the numbers, e.g. if decimalPlaces == 2, then 0.01 will equal between 
        /// 0.005 and 0.015, but not 0.02 and not 0.00
        /// </para>
        /// </remarks>
        /// <param name="first">The first value.</param>
        /// <param name="second">The second value.</param>
        /// <param name="numberOfDecimalPlaces">The number of decimal places.</param>
        /// <returns><see langword="true" /> if both doubles are equal to each other within the specified number of decimal places; otherwise <see langword="false" />.</returns>
        private static bool EqualsWithinRelativeDecimalPlaces(double first, double second, int numberOfDecimalPlaces)
        {
            // If the magnitudes of the two numbers are equal to within one magnitude the numbers could potentially be equal
            int magnitudeOfFirst = Magnitude(first);
            int magnitudeOfSecond = Magnitude(second);
            if (System.Math.Max(magnitudeOfFirst, magnitudeOfSecond) > (System.Math.Min(magnitudeOfFirst, magnitudeOfSecond) + 1))
            {
                return false;
            }

            // Get the power of the number of decimalPlaces
            double decimalPlaceMagnitude = System.Math.Pow(10, -(numberOfDecimalPlaces - 1));

            // The values are equal if the difference between the two numbers is smaller than
            // 10^(-numberOfDecimalPlaces). We divide by two so that we have half the range
            // on each side of the numbers, e.g. if decimalPlaces == 2, 
            // then 0.01 will equal between 0.005 and 0.015, but not 0.02 and not 0.00
            double maxDifference = decimalPlaceMagnitude / 2.0;
            if (first > second)
            {
                return (first * System.Math.Pow(10, -magnitudeOfFirst) - maxDifference < second * System.Math.Pow(10, -magnitudeOfFirst));
            }
            else
            {
                return (second * System.Math.Pow(10, -magnitudeOfSecond) - maxDifference < first * System.Math.Pow(10, -magnitudeOfSecond));
            }
        }

        /// <summary>
        /// Compares two doubles and determines if they are equal to within the specified number of decimal places or not, using the 
        /// number of decimal places as an absolute measure.
        /// </summary>
        /// <remarks>
        /// <para>
        /// The values are equal if the difference between the two numbers is smaller than 10^(-numberOfDecimalPlaces). We divide by 
        /// two so that we have half the range on each side of the numbers, e.g. if decimalPlaces == 2, then 0.01 will equal between 
        /// 0.005 and 0.015, but not 0.02 and not 0.00
        /// </para>
        /// </remarks>
        /// <param name="first">The first value.</param>
        /// <param name="second">The second value.</param>
        /// <param name="numberOfDecimalPlaces">The number of decimal places.</param>
        /// <returns><see langword="true" /> if both doubles are equal to each other within the specified number of decimal places; otherwise <see langword="false" />.</returns>
        private static bool EqualsWithinAbsoluteDecimalPlaces(double first, double second, int numberOfDecimalPlaces)
        {
            double decimalPlaceMagnitude = System.Math.Pow(10, -(numberOfDecimalPlaces - 1));
            // The values are equal if the difference between the two numbers is smaller than
            // 10^(-numberOfDecimalPlaces). We divide by two so that we have half the range
            // on each side of the numbers, e.g. if decimalPlaces == 2, 
            // then 0.01 will equal between 0.005 and 0.015, but not 0.02 and not 0.00
            return (System.Math.Abs((first - second)) < decimalPlaceMagnitude / 2.0);
        }

        /// <summary>
        /// Compares two doubles and determines if the <c>first</c> value is larger than the <c>second</c>
        /// value to within the tolerance or not. Equality comparison is based on the binary representation.
        /// </summary>
        /// <param name="first">The first value.</param>
        /// <param name="second">The second value.</param>
        /// <param name="maxUlps">The maximum error in terms of Units in Last Place (ulps), i.e. the maximum number of decimals that may be different. Must be 1 or larger.</param>
        /// <returns><c>true</c> if the first value is larger than the second value; otherwise <c>false</c>.</returns>
        public static bool IsLargerWithTolerance(double first, double second, long maxUlps)
        {
            // If A or B are a NAN, return false. NANs are equal to nothing,
            // not even themselves, and thus they're not bigger or
            // smaller than anything either
            if ((double.IsNaN(first)) || (double.IsNaN(second)))
            {
                return false;
            }

            return (CompareWithTolerance(first, second, maxUlps) > 0);
        }

        /// <summary>
        /// Compares two doubles and determines if the <c>first</c> value is larger than the <c>second</c>
        /// value to within the specified number of decimal places or not.
        /// </summary>
        /// <remarks>
        /// <para>
        /// The values are equal if the difference between the two numbers is smaller than 10^(-numberOfDecimalPlaces). We divide by 
        /// two so that we have half the range on each side of the numbers, e.g. if decimalPlaces == 2, then 0.01 will equal between 
        /// 0.005 and 0.015, but not 0.02 and not 0.00
        /// </para>
        /// </remarks>
        /// <param name="first">The first value.</param>
        /// <param name="second">The second value.</param>
        /// <param name="numberOfDecimalPlaces">The number of decimal places.</param>
        /// <returns><c>true</c> if the first value is larger than the second value; otherwise <c>false</c>.</returns>
        public static bool IsLargerWithDecimalPlaces(double first, double second, int numberOfDecimalPlaces)
        {
            // If A or B are a NAN, return false. NANs are equal to nothing,
            // not even themselves, and thus they're not bigger or
            // smaller than anything either
            if ((double.IsNaN(first)) || (double.IsNaN(second)))
            {
                return false;
            }

            return (CompareWithDecimalPlaces(first, second, numberOfDecimalPlaces) > 0);
        }

        /// <summary>
        /// Compares two doubles and determines if the <c>first</c> value is smaller than the <c>second</c>
        /// value to within the tolerance or not. Equality comparison is based on the binary representation.
        /// </summary>
        /// <param name="first">The first value.</param>
        /// <param name="second">The second value.</param>
        /// <param name="maxUlps">The maximum error in terms of Units in Last Place (ulps), i.e. the maximum number of decimals that may be different. Must be 1 or larger.</param>
        /// <returns><c>true</c> if the first value is smaller than the second value; otherwise <c>false</c>.</returns>
        public static bool IsSmallerWithTolerance(double first, double second, long maxUlps)
        {
            // If A or B are a NAN, return false. NANs are equal to nothing,
            // not even themselves, and thus they're not bigger or
            // smaller than anything either
            if ((double.IsNaN(first)) || (double.IsNaN(second)))
            {
                return false;
            }

            return (CompareWithTolerance(first, second, maxUlps) < 0);
        }

        /// <summary>
        /// Compares two doubles and determines if the <c>first</c> value is smaller than the <c>second</c>
        /// value to within the specified number of decimal places or not.
        /// </summary>
        /// <remarks>
        /// <para>
        /// The values are equal if the difference between the two numbers is smaller than 10^(-numberOfDecimalPlaces). We divide by 
        /// two so that we have half the range on each side of the numbers, e.g. if decimalPlaces == 2, then 0.01 will equal between 
        /// 0.005 and 0.015, but not 0.02 and not 0.00
        /// </para>
        /// </remarks>
        /// <param name="first">The first value.</param>
        /// <param name="second">The second value.</param>
        /// <param name="numberOfDecimalPlaces">The number of decimal places.</param>
        /// <returns><c>true</c> if the first value is smaller than the second value; otherwise <c>false</c>.</returns>
        public static bool IsSmallerWithDecimalPlaces(double first, double second, int numberOfDecimalPlaces)
        {
            // If A or B are a NAN, return false. NANs are equal to nothing,
            // not even themselves, and thus they're not bigger or
            // smaller than anything either
            if ((double.IsNaN(first)) || (double.IsNaN(second)))
            {
                return false;
            }
            
            return (CompareWithDecimalPlaces(first, second, numberOfDecimalPlaces) < 0);
        }

        /// <summary>
        /// Compares two doubles and determines which double is bigger.
        /// </summary>
        /// <param name="first">The first value.</param>
        /// <param name="second">The second value.</param>
        /// <param name="maxUlps">The maximum error in terms of Units in Last Place (ulps), i.e. the maximum number of decimals that may be different. Must be 1 or larger.</param>
        /// <returns>
        /// <list type="table">
        ///     <listheader>
        ///         <term>Return value</term>
        ///         <description>Meaning</description>
        ///     </listheader>
        ///     <item>
        ///         <term>-1</term>
        ///         <description><paramref name="first"/> is smaller than <paramref name="second"/> by more than the <paramref name="maxUlps"/> tolerance.</description>
        ///     </item>
        ///     <item>
        ///         <term>0</term>
        ///         <description><paramref name="first"/> is equal to <paramref name="second"/> within the <paramref name="maxUlps"/> tolerance.</description>
        ///     </item>
        ///     <item>
        ///         <term>1</term>
        ///         <description><paramref name="first"/> is bigger than <paramref name="second"/> by more than the <paramref name="maxUlps"/> tolerance.</description>
        ///     </item>
        /// </list>
        /// </returns>
        public static int CompareWithTolerance(double first, double second, long maxUlps)
        {
            // If A or B are a NAN, return false. NANs are equal to nothing,
            // not even themselves, and thus they're not bigger or
            // smaller than anything either
            if ((double.IsNaN(first)) || (double.IsNaN(second)))
            {
                return first.CompareTo(second);
            }

            // If A or B are infinity (positive or negative) then
            // only return true if first is smaller
            if ((double.IsInfinity(first)) || (double.IsInfinity(second)))
            {
                return first.CompareTo(second);
            }

            // If the numbers are equal to within the tolerance then
            // there's technically no difference
            if (EqualsWithTolerance(first, second, maxUlps))
            {
                return 0;
            }
                        
            return first.CompareTo(second);
        }

        /// <summary>
        /// Compares two doubles and determines which double is bigger.
        /// </summary>
        /// <param name="first">The first value.</param>
        /// <param name="second">The second value.</param>
        /// <param name="numberOfDecimalPlaces">The number of decimal places on which the values must be compared. Must be 1 or larger.</param>
        /// <returns>
        /// <list type="table">
        ///     <listheader>
        ///         <term>Return value</term>
        ///         <description>Meaning</description>
        ///     </listheader>
        ///     <item>
        ///         <term>-1</term>
        ///         <description><paramref name="first"/> is smaller than <paramref name="second"/> by more than a magnitude equal to <paramref name="numberOfDecimalPlaces"/>.</description>
        ///     </item>
        ///     <item>
        ///         <term>0</term>
        ///         <description><paramref name="first"/> is equal to <paramref name="second"/> within a magnitude equal to <paramref name="numberOfDecimalPlaces"/>.</description>
        ///     </item>
        ///     <item>
        ///         <term>1</term>
        ///         <description><paramref name="first"/> is bigger than <paramref name="second"/> by more than a magnitude equal to <paramref name="numberOfDecimalPlaces"/>.</description>
        ///     </item>
        /// </list>
        /// </returns>
        public static int CompareWithDecimalPlaces(double first, double second, int numberOfDecimalPlaces)
        {
            // If A or B are a NAN, return false. NANs are equal to nothing,
            // not even themselves, and thus they're not bigger or
            // smaller than anything either
            if ((double.IsNaN(first)) || (double.IsNaN(second)))
            {
                return first.CompareTo(second);
            }

            // If A or B are infinity (positive or negative) then
            // only return true if first is smaller
            if ((double.IsInfinity(first)) || (double.IsInfinity(second)))
            {
                return first.CompareTo(second);
            }

            // If the numbers are equal to within the number of decimal places
            // then there's technically no difference
            if (EqualsWithinDecimalPlaces(first, second, numberOfDecimalPlaces))
            {
                return 0;
            }

            // The numbers differ by more than the decimal places, so
            // we can check the normal way to see if the first is
            // larger than the second.
            return first.CompareTo(second);
        }
    }
}