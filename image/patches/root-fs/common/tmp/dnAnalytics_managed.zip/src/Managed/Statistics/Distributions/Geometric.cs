﻿/* Copyright 2007-2008 dnAnalytics Project.
 *
 * Contributors to this file:
 * Jurgen Van Gael
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this 
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * * Neither the name of the dnAnalytics Project nor the names of its contributors
 *   may be used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

using System;
using dnAnalytics.Properties;

namespace dnAnalytics.Statistics.Distributions
{
    /// <summary>
    /// The Geometric distribution is a distribution over positive integers parameterized by one positive real number.
    /// This implementation of the Geometric distribution will never generate 0's.
    /// </summary>
    /// <remarks>The distribution will use the <see cref="System.Random"/> by default. 
    /// Users can set the random number generator by using the <see cref="RandomNumberGenerator"/> property.
    /// 
    /// The statistics classes will check all the incoming parameters whether they are in the allowed
    /// range. This might involve heavy computation. Optionally, by setting Control.CheckDistributionParameters
    /// to false, all parameter checks can be turned off.</remarks>
    public class Geometric : IDiscreteDistribution
    {
        // The geometric distribution parameter.
        private readonly double mP;

        /// <summary>
        /// Initializes a new instance of the <see cref="Geometric"/> class.
        /// </summary>
        /// <param name="p">The p parameter.</param>
        public Geometric(double p)
        {
            if (Control.CheckDistributionParameters)
            {
                CheckParameters(p);
            }

            mP = p;
            RandomNumberGenerator = new System.Random();
        }

        /// <summary>
        /// A string representation of the distribution.
        /// </summary>
        public override string ToString()
        {
            return "Geometric(P = " + mP + ")";
        }

        #region IDistribution Members

        /// <summary>
        /// The mean of the distribution.
        /// </summary>
        /// <value></value>
        public double Mean
        {
            get { return 1.0/mP; }
        }

        /// <summary>
        /// The standard deviation of the distribution.
        /// </summary>
        /// <value></value>
        public double StdDev
        {
            get { return System.Math.Sqrt(1.0 - mP)/mP; }
        }

        /// <summary>
        /// The variance of the distribution.
        /// </summary>
        /// <value></value>
        public double Variance
        {
            get { return (1.0 - mP)/(mP*mP); }
        }

        /// <summary>
        /// The entropy of the distribution.
        /// </summary>
        /// <value></value>
        public double Entropy
        {
            get { return (-mP*System.Math.Log(mP, 2.0) - (1.0 - mP)*System.Math.Log(1.0 - mP, 2.0))/mP; }
        }

        /// <summary>
        /// Gets or sets the random number generator.
        /// </summary>
        /// <value>The random number generator used to generate a random sample.</value>
        public System.Random RandomNumberGenerator { get; set; }

        #endregion

        #region IDiscreteDistribution Members

        /// <summary>
        /// The mode of the distribution.
        /// </summary>
        /// <value></value>
        public int Mode
        {
            get { return 1; }
        }

        /// <summary>
        /// The median of the distribution.
        /// </summary>
        /// <value></value>
        public int Median
        {
            get { return (int) System.Math.Ceiling(-System.Math.Log(2.0)/System.Math.Log(1 - mP)); }
        }

        /// <summary>
        /// Computes values of the probability mass function.
        /// </summary>
        /// <param name="k">The location in the domain where we want to evaluate the probability mass function.</param>
        /// <returns></returns>
        public double Probability(int k)
        {
            if (k <= 0)
            {
                return 0.0;
            }

            return System.Math.Pow(1.0 - mP, k - 1)*mP;
        }

        /// <summary>
        /// Samples a Geometric distributed random variable.
        /// </summary>
        public int Sample()
        {
            return DoSample(RandomNumberGenerator, mP);
        }

        /// <summary>
        /// Samples an array of Geometric distributed random variables.
        /// </summary>
        /// <param name="n">The number of variables needed.</param>
        public int[] Sample(int n)
        {
            return DoSample(RandomNumberGenerator, n, mP);
        }

        #endregion

        /// <summary>
        /// Computes the cumulative distribution function.
        /// </summary>
        public double CumulativeDistribution(int k)
        {
            return 1.0 - System.Math.Pow(1.0 - mP, k);
        }

        /// <summary>
        /// Check the parameters of the Geometric distribution.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">If the parameter is not in [0,1].</exception>
        private static void CheckParameters(double p)
        {
            if (p <= 0.0 || p > 1.0)
            {
                throw new ArgumentOutOfRangeException("p", Resources.ZeroOneRange);
            }
        }

        /// <summary>
        /// Samples a Geometric distributed random variable.
        /// </summary>
        /// <param name="rnd">The random number generator to use.</param>
        /// <param name="p">The parameter of the Geometric distribution.</param>
        public static int Sample(System.Random rnd, double p)
        {
            if (Control.CheckDistributionParameters)
            {
                CheckParameters(p);
            }

            return DoSample(rnd, p);
        }

        /// <summary>
        /// Samples an array of Geometric distributed random variables.
        /// </summary>
        /// <param name="rnd">The random number generator to use.</param>
        /// <param name="n">The number of variables needed.</param>
        /// <param name="p">The parameter of the Geometric distribution.</param>
        public static int[] Sample(System.Random rnd, int n, double p)
        {
            if (Control.CheckDistributionParameters)
            {
                CheckParameters(p);
            }

            return DoSample(rnd, n, p);
        }

        private static int DoSample(System.Random rnd, double p)
        {
            return (int) System.Math.Ceiling(-System.Math.Log(rnd.NextDouble())/p);
        }

        private static int[] DoSample(System.Random rnd, int n, double p)
        {
            int[] arr = new int[n];
            for (int i = 0; i < n; i++)
            {
                arr[i] = DoSample(rnd, p);
            }
            return arr;
        }
    }
}