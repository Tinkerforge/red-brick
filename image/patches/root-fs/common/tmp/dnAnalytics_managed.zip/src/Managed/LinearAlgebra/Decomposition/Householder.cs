﻿/* Copyright 2008 dnAnalytics Project.
 *
 * Contributors to this file:
 * Marcus Cuda
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this 
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * * Neither the name of the dnAnalytics Project nor the names of its contributors
 *   may be used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

using System;
using dnAnalytics.Properties;

namespace dnAnalytics.LinearAlgebra.Decomposition
{
    /// <summary>
    /// Computes the QR decomposition of a <see cref="Matrix"/> using the Householder method.
    /// </summary>
    /// <remarks>The actual decomposition is not done until one of the class'
    /// methods is invoked.</remarks>
    public class Householder : IQR
    {
        private readonly AbstractHouseholder mQR;
        
        /// <summary>
        /// Constructs the QR object for the given matrix.
        /// </summary>
        /// <param name="matrix">The matrix to decompose.</param>
        /// <remarks>The actual decomposition is not done until one of the class'
        /// methods is invoked.</remarks>
        public Householder(Matrix matrix)
        {
            if (matrix == null)
            {
                throw new ArgumentNullException("matrix");
            }
            if (matrix.Rows < matrix.Columns)
            {
                throw new InvalidMatrixOperationException(Resources.RowsLessThanColumns);
            }
            if (matrix.GetType() == typeof(DenseMatrix))
            {
                mQR = new DenseHouseholder(matrix);
            }
            else
            {
                mQR = new UserHouseholder(matrix);
            }
        }

 
        /// <summary>
        /// Returns the orthogonal Q matrix.
        /// </summary>
        /// <returns>The orthogonal Q matrix.</returns>
        public Matrix Q()
        {
            return mQR.Q();
        }

        /// <summary>
        /// Returns the upper triangular factor R.
        /// </summary>
        /// <returns>The upper triangular factor R.</returns>
        public Matrix R()
        {
            return mQR.R();
        }

        /// <summary>
        /// Determines whether the matrix is full rank or not.
        /// </summary>
        /// <returns><b>true</b> if the matrix is full rank; otherwise <b>false</b>.</returns>         
        public bool IsFullRank()
        {
            return mQR.IsFullRank();
        }

        ///<summary>Calculates the determinant (absolute value) of the matrix.</summary>
        ///<returns>The determinant of the matrix.</returns>
        ///<exception cref="MatrixNotSquareException">If the matrix is not square.</exception>
        public double Determinant()
        {
            return mQR.Determinant();
        }

        /// <summary>
        /// Solves a system of linear equations, <b>AX = B</b>.
        /// </summary>
        /// <param name="input">The right hand side <see cref="Matrix"/>, <b>B</b>.</param>
        /// <returns>
        /// The left hand side <see cref="Matrix"/>, <b>X</b>.
        /// </returns>
        public Matrix Solve(Matrix input)
        {
            return mQR.Solve(input);
        }

        /// <summary>
        /// Solves a system of linear equations, <b>AX = B</b>.
        /// </summary>
        /// <param name="input">The right hand side <see cref="Matrix"/>, <b>B</b>.</param>
        /// <param name="result">The left hand side <see cref="Matrix"/>, <b>X</b>.</param>
        public void Solve(Matrix input, Matrix result)
        {
            mQR.Solve(input, result);
        }

        /// <summary>
        /// Solves a system of linear equations, <b>Ax = b</b>.
        /// </summary>
        /// <param name="input">The right hand side vector, <b>b</b>.</param>
        /// <returns>
        /// The left hand side <see cref="Vector"/>, <b>x</b>.
        /// </returns>
        public Vector Solve(Vector input)
        {
            return mQR.Solve(input);
        }

        /// <summary>
        /// Solves a system of linear equations, <b>Ax = b</b>.
        /// </summary>
        /// <param name="input">The right hand side vector, <b>b</b>.</param>
        /// <param name="result">The left hand side <see cref="Matrix"/>, <b>x</b>.</param>
        public void Solve(Vector input, Vector result)
        {
           mQR.Solve(input, result);
        }
    }
}
