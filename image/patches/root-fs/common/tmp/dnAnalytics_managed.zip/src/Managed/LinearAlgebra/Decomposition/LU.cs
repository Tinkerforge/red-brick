/* Copyright 2007-2008 dnAnalytics Project.
 *
 * Contributors to this file:
 * Patrick van der Velde
 * Marcus Cuda
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this 
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * * Neither the name of the dnAnalytics Project nor the names of its contributors
 *   may be used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

using System;
using dnAnalytics.Properties;

namespace dnAnalytics.LinearAlgebra.Decomposition
{
    /// <summary>
    /// Calculates the LU decomposition of matrix.
    /// </summary>
    /// <remarks>The actual decomposition is not done until one of the class'
    /// methods is invoked.</remarks>
    public class LU
    {
        private readonly AbstractLU mLU;

        /// <summary>
        /// Constructs a LU form an <see cref="Matrix"/> object.
        /// </summary>
        /// <param name="matrix">The matrix to use.</param>
        /// <remarks>The actual decomposition is not done until one of the class'
        /// methods is invoked.</remarks>
        public LU(Matrix matrix)
        {
            if (matrix == null)
            {
                throw new ArgumentNullException("matrix", Resources.NullParameterException);
            }

            if (matrix.Rows != matrix.Columns)
            {
                throw new MatrixNotSquareException(Resources.NotSqurare);
            }

            if (matrix.GetType() == typeof(DenseMatrix))
            {
                mLU = new DenseLU(matrix);
            }
            else
            {
                mLU = new UserLU(matrix);
            }
        }

        /// <summary>
        /// Returns a value indicating whether the matrix is singular.
        /// </summary>
        /// <returns><b>true</b> if the matrix is singular; otherwise, <b>false</b>.</returns>
        public bool IsSingular()
        {
            return mLU.IsSingular();
        }

        /// <summary>
        /// Returns the lower factor of the factorization.
        /// </summary>
        /// <returns>The lower factor of the factorization.</returns>
        public Matrix LowerFactor()
        {
            return mLU.LowerFactor();
        }


        /// <summary>
        /// Returns the upper factor of the factorization.
        /// </summary>
        /// <returns>The upper factor of the factorization.</returns>
        public Matrix UpperFactor()
        {
            return mLU.UpperFactor();
        }

        /// <summary>
        /// The determinant of the matrix.
        /// </summary>
        /// <returns>The determinant of the matrix.</returns>
        public double Determinant()
        {
            return mLU.Determinant();
        }


        /// <summary>
        /// Returns an <b>int</b> array indicating which rows were interchanged during factorization.
        /// Row i was interchanged with row pivots[i].</summary>
        /// <value>An <b>int</b> array indicating which rows were interchanged during factorization.</value>
        public int[] Pivots()
        {
            return mLU.Pivots();
        }

        /// <summary>
        /// Returns the inverse of the matrix.
        /// </summary>
        /// <returns>The inverse of the matrix.</returns>
        public Matrix Inverse()
        {
            return mLU.Inverse();
        }

        /// <summary>
        ///  Solves a system of linear equations, <b>AX = B</b>.
        /// </summary>
        /// <param name="input">The right hand side <see cref="Matrix"/>, <b>B</b>.</param>
        /// <returns>The left hand side <see cref="Matrix"/>, <b>X</b>.</returns>
        public Matrix Solve(Matrix input)
        {
            return mLU.Solve(input);
        }

        /// <summary>
        ///  Solves a system of linear equations, <b>AX = B</b>.
        /// </summary>
        /// <param name="input">The right hand side <see cref="Matrix"/>, <b>B</b>.</param>
        /// <param name="result">The left hand side <see cref="Matrix"/>, <b>X</b>.</param>
        public void Solve(Matrix input, Matrix result)
        {
            mLU.Solve(input, result);
        }

        /// <summary>
        /// Solves a system of linear equations, <b>Ax = b</b>.
        /// </summary>
        /// <param name="input">The right hand side vector, <b>b</b>.</param>
        /// <returns>The left hand side <see cref="Vector"/>, <b>x</b>.</returns>
        public Vector Solve(Vector input)
        {
            return mLU.Solve(input);
        }

        /// <summary>
        /// Solves a system of linear equations, <b>Ax = b</b>.
        /// </summary>
        /// <param name="input">The right hand side vector, <b>b</b>.</param>
        /// <param name="result">The left hand side <see cref="Matrix"/>, <b>x</b>.</param>
        public void Solve(Vector input, Vector result)
        {
            mLU.Solve(input, result);
        }
    }
}