/* Copyright 2007-2008 dnAnalytics Project.
 *
 * Contributors to this file:
 * Patrick van der Velde
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this 
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * * Neither the name of the dnAnalytics Project nor the names of its contributors
 *   may be used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

using System;
using System.Reflection;
using System.IO;
using System.Collections.Generic;
using dnAnalytics.Math;

namespace dnAnalytics.LinearAlgebra.Solvers.Iterative
{
    /// <summary>
    /// A composite matrix solver. The actual solver is made by a sequence of
    /// matrix solvers. 
    /// </summary>
    /// <remarks>
    /// <para>
    /// Solver based on:<br />
    /// Faster PDE-based simulations using robust composite linear solvers<br />
    /// S. Bhowmicka, P. Raghavan a,*, L. McInnes b, B. Norris<br />
    /// Future Generation Computer Systems, Vol 20, 2004, pp 373�387<br />
    /// </para>
    /// <para>
    /// Note that if an iterator is passed to this solver it will be used for all
    /// the sub-solvers.
    /// </para>
    /// </remarks>
    public sealed class CompositeSolver : IIterativeSolver
    {
        /// <summary>
        /// The default status used if the solver is not running.
        /// </summary>
        private static readonly ICalculationStatus sm_NonRunningStatus = new CalculationIndetermined();

        /// <summary>
        /// The default status used if the solver is running.
        /// </summary>
        private static readonly ICalculationStatus sm_RunningStatus = new CalculationRunning();
        
        /// <summary>
        /// The collection of iterative solver setups. Stored based on the
        /// ratio between the relative speed and relative accuracy.
        /// </summary>
        private static readonly SortedList<double, List<IIterativeSolverSetup>> sm_SolverSetups =
            new SortedList<double, List<IIterativeSolverSetup>>(new Precision.DoubleComparer(Constants.UlpsForComparison));

        #region Solver information loading methods

        /// <summary>
        /// Loads all the available <see cref="IIterativeSolverSetup"/> objects from 
        /// the dnAnalytics assembly.
        /// </summary>
        public static void LoadSolverInformation()
        {
            LoadSolverInformation(new Type[0]);
        }

        /// <summary>
        /// Loads the available <see cref="IIterativeSolverSetup"/> objects from 
        /// the dnAnalytics assembly.
        /// </summary>
        /// <param name="typesToExclude">
        ///   The <see cref="IIterativeSolver"/> types that should not be loaded.
        /// </param>
        public static void LoadSolverInformation(Type[] typesToExclude)
        {
            LoadSolverInformationFromAssembly(Assembly.GetExecutingAssembly(), typesToExclude);
        }

        /// <summary>
        /// Loads the available <see cref="IIterativeSolverSetup"/> objects from the
        /// assembly specified by the file location.
        /// </summary>
        /// <param name="assemblyLocation">The fully qualified path to the assembly.</param>
        public static void LoadSolverInformationFromAssembly(string assemblyLocation)
        {
            LoadSolverInformationFromAssembly(assemblyLocation, new Type[0]);
        }

        /// <summary>
        /// Loads the available <see cref="IIterativeSolverSetup"/> objects from the
        /// assembly specified by the file location.
        /// </summary>
        /// <param name="assemblyLocation">The fully qualified path to the assembly.</param>
        /// <param name="typesToExclude">
        ///   The <see cref="IIterativeSolver"/> types that should not be loaded.
        /// </param>
        public static void LoadSolverInformationFromAssembly(string assemblyLocation, params Type[] typesToExclude)
        {
            if (assemblyLocation == null)
            {
                throw new ArgumentNullException("assemblyLocation");
            }

            if (assemblyLocation.Length == 0)
            {
                throw new ArgumentException();
            }

            if (!File.Exists(assemblyLocation))
            {
                throw new FileNotFoundException();
            }

            // Get the assembly name
            string assemblyFileName = Path.GetFileNameWithoutExtension(assemblyLocation);
            // Now load the assembly with an AssemblyName
            AssemblyName assemblyName = new AssemblyName(assemblyFileName);

            Assembly assembly = null;
            try
            {
                assembly = Assembly.Load(assemblyName);
            }
            // Throws:
            // ArgumentNullException --> Can't get this because we checked that the file exists.
            // FileNotFoundException --> Can't get this because we checked that the file exists.
            // FileLoadException
            // BadImageFormatException
            catch (FileLoadException)
            {
                throw;
            }
            catch (BadImageFormatException)
            {
                throw;
            }

            // Now we can load the solver information.
            LoadSolverInformationFromAssembly(assembly, typesToExclude);
        }

        /// <summary>
        /// Loads the available <see cref="IIterativeSolverSetup"/> objects from the
        /// assembly specified by the assembly name.
        /// </summary>
        /// <param name="assemblyName">
        ///   The <see cref="AssemblyName"/> of the assembly that should be searched for setup objects.
        /// </param>
        public static void LoadSolverInformationFromAssembly(AssemblyName assemblyName)
        {
            LoadSolverInformationFromAssembly(assemblyName, new Type[0]);
        }

        /// <summary>
        /// Loads the available <see cref="IIterativeSolverSetup"/> objects from the
        /// assembly specified by the assembly name.
        /// </summary>
        /// <param name="assemblyName">
        ///   The <see cref="AssemblyName"/> of the assembly that should be searched for setup objects.
        /// </param>
        /// <param name="typesToExclude">
        ///   The <see cref="IIterativeSolver"/> types that should not be loaded.
        /// </param>
        public static void LoadSolverInformationFromAssembly(AssemblyName assemblyName, params Type[] typesToExclude)
        {
            if (assemblyName == null)
            {
                throw new ArgumentNullException("assemblyLocation");
            }

            Assembly assembly = null;
            try
            {
                assembly = Assembly.Load(assemblyName);
            }
            // Throws:
            // ArgumentNullException --> Can't get this because we checked it.
            // FileNotFoundException
            // FileLoadException
            // BadImageFormatException
            catch (FileNotFoundException)
            {
                throw;
            }
            catch (FileLoadException)
            {
                throw;
            }
            catch (BadImageFormatException)
            {
                throw;
            }

            // Now we can load the solver information.
            LoadSolverInformationFromAssembly(assembly, typesToExclude);
        }

        /// <summary>
        /// Loads the available <see cref="IIterativeSolverSetup"/> objects from the
        /// assembly specified by the type.
        /// </summary>
        /// <param name="typeInAssembly">The type in the assembly which should be searched for setup objects.</param>
        public static void LoadSolverInformationFromAssembly(Type typeInAssembly)
        {
            LoadSolverInformationFromAssembly(typeInAssembly, new Type[0]);
        }

        /// <summary>
        /// Loads the available <see cref="IIterativeSolverSetup"/> objects from the
        /// assembly specified by the type.
        /// </summary>
        /// <param name="typeInAssembly">The type in the assembly which should be searched for setup objects.</param>
        /// <param name="typesToExclude">
        ///   The <see cref="IIterativeSolver"/> types that should not be loaded.
        /// </param>
        public static void LoadSolverInformationFromAssembly(Type typeInAssembly, params Type[] typesToExclude)
        {
            if (typeInAssembly == null)
            {
                throw new ArgumentNullException("typeInAssembly");
            }

            LoadSolverInformationFromAssembly(typeInAssembly.Assembly, typesToExclude);
        }

        /// <summary>
        /// Loads the available <see cref="IIterativeSolverSetup"/> objects from the
        /// specified assembly.
        /// </summary>
        /// <param name="assembly">The assembly which will be searched for setup objects.</param>
        public static void LoadSolverInformationFromAssembly(Assembly assembly)
        {
            LoadSolverInformationFromAssembly(assembly, new Type[0]);
        }

        /// <summary>
        /// Loads the available <see cref="IIterativeSolverSetup"/> objects from the
        /// specified assembly.
        /// </summary>
        /// <param name="assembly">The assembly which will be searched for setup objects.</param>
        /// <param name="typesToExclude">
        ///   The <see cref="IIterativeSolver"/> types that should not be loaded.
        /// </param>
        public static void LoadSolverInformationFromAssembly(Assembly assembly, params Type[] typesToExclude)
        {
            if (assembly == null)
            {
                throw new ArgumentNullException("Assembly");
            }

            if (typesToExclude == null)
            {
                throw new ArgumentNullException("typesToExclude");
            }
            List<Type> excludedTypes = new List<Type>(typesToExclude);

            // Load all the types in the assembly
            // Find all the types that implement IIterativeSolverSetup
            // Create an object of each of these types
            // Get the type of the iterative solver that will be instantiated by the setup object
            // Check if it's on the excluding list, if so throw the setup object away
            //                                      otherwise keep it.

            List<Type> interfaceTypes = new List<Type>();
            foreach (Type type in assembly.GetTypes())
            {
                // Can only load classes and structs.
                if (type.IsAbstract || type.IsEnum || type.IsInterface || !type.IsVisible)
                {
                    continue;
                }

                interfaceTypes.AddRange(type.GetInterfaces());
                if (!interfaceTypes.Exists(delegate(Type match)
                                           {
                                               return typeof(IIterativeSolverSetup).IsAssignableFrom(match);
                                           }))
                {
                    continue;
                }

                // See if we actually want this type of iterative solver
                IIterativeSolverSetup setup = null;
                try
                {
                    setup = (IIterativeSolverSetup)Activator.CreateInstance(type);
                }
                // If something goes wrong we just ignore it and move on with the next type.
                // There should probably be a log somewhere indicating that something went
                // wrong?
                catch (ArgumentException) { continue; }
                catch (NotSupportedException) { continue; }
                catch (TargetInvocationException) { continue; }
                catch (MethodAccessException) { continue; }
                catch (MissingMethodException) { continue; }
                catch (MemberAccessException) { continue; }
                catch (TypeLoadException) { continue; }

                if (excludedTypes.Exists(delegate(Type match)
                                         {
                                             return match.IsAssignableFrom(setup.SolverType) ||
                                                    match.IsAssignableFrom(setup.PreconditionerType);
                                         }))
                {
                    continue;
                }

                // Ok we want the solver, so store the object
                double ratio = setup.SolutionSpeed / setup.Reliability;
                if (!sm_SolverSetups.ContainsKey(ratio))
                {
                    sm_SolverSetups.Add(ratio, new List<IIterativeSolverSetup>());
                }
                List<IIterativeSolverSetup> list = sm_SolverSetups[ratio];
                list.Add(setup);
            }
        } 

        #endregion

        /// <summary>
        /// The collection of solvers that will be used to 
        /// </summary>
        private readonly List<IIterativeSolver> m_Solvers = new List<IIterativeSolver>();

        /// <summary>
        /// The status of the calculation.
        /// </summary>
        private ICalculationStatus m_Status = sm_NonRunningStatus;

        /// <summary>
        /// The iterator that is used to control the iteration process.
        /// </summary>
        private IIterator m_Iterator;

        /// <summary>
        /// A flag indicating if the solver has been stopped or not.
        /// </summary>
        private bool m_HasBeenStopped;

        /// <summary>
        /// The solver that is currently running. Reference is used to be able to stop the
        /// solver if the user cancels the solve process.
        /// </summary>
        private IIterativeSolver m_CurrentSolver;

        /// <summary>
        /// Creates the <c>CompositeSolver</c> with the default iterator.
        /// </summary>
        public CompositeSolver() : this(null)
        {}

        /// <summary>
        /// Creates the <c>CompositeSolver</c> with the specified iterator.
        /// </summary>
        /// <param name="iterator">
        /// The iterator that will be used to control the iteration process.
        /// </param>
        public CompositeSolver(IIterator iterator)
        {
            m_Iterator = iterator;
        }

        /// <summary>
        /// Sets the <c>IIterator</c> that will be used to track the iterative process.
        /// </summary>
        /// <param name="iterator">The iterator.</param>
        public void SetIterator(IIterator iterator)
        {
            m_Iterator = iterator;
        }

        /// <summary>
        /// Gets the status of the iteration once the calculation is finished.
        /// </summary>
        public ICalculationStatus IterationResult
        {
            get 
            { 
                return m_Status; 
            }
        }

        /// <summary>
        /// Stops the solve process. 
        /// </summary>
        /// <remarks>
        /// Note that it may take an indetermined amount of time for the solver to actually
        /// stop the process.
        /// </remarks>
        public void StopSolve()
        {
            m_HasBeenStopped = true;
            if (m_CurrentSolver != null)
            { 
                m_CurrentSolver.StopSolve();
            }
        }

        /// <summary>
        /// Solves the matrix equation Ax = b, where A is the coefficient matrix, b is the
        /// solution vector and x is the unknown vector.
        /// </summary>
        /// <param name="matrix">The coefficient matrix, <c>A</c>.</param>
        /// <param name="vector">The solution vector, <c>b</c>.</param>
        /// <returns>The result vector, <c>x</c>.</returns>
        public Vector Solve(Matrix matrix, Vector vector)
        {
            if (vector == null)
            {
                throw new ArgumentNullException();
            }

            Vector result = new DenseVector(matrix.Rows);
            Solve(matrix, vector, result);
            return result;
        }

        /// <summary>
        /// Solves the matrix equation Ax = b, where A is the coefficient matrix, b is the
        /// solution vector and x is the unknown vector.
        /// </summary>
        /// <param name="matrix">The coefficient matrix, <c>A</c>.</param>
        /// <param name="input">The solution vector, <c>b</c></param>
        /// <param name="result">The result vector, <c>x</c></param>
        public void Solve(Matrix matrix, Vector input, Vector result)
        {
            // If we were stopped before, we are no longer
            // We're doing this at the start of the method to ensure
            // that we can use these fields immediately.
            {
                m_HasBeenStopped = false;
                m_CurrentSolver = null;
            }

            // Error checks
            {
                if (matrix == null)
                {
                    throw new ArgumentNullException("matrix");
                }

                if (matrix.Rows != matrix.Columns)
                {
                    throw new MatrixNotSquareException();
                }

                if (input == null)
                {
                    throw new ArgumentNullException("input");
                }

                if (result == null)
                {
                    throw new ArgumentNullException("result");
                }

                if (result.Count != input.Count)
                {
                    throw new NotConformableException();
                }
            }

            // Initialize the solver fields
            {
                // Set the convergence monitor
                if (m_Iterator == null)
                {
                    m_Iterator = Iterator.CreateDefault();
                }

                // Load the solvers into our own internal data structure
                // Once we have solvers we can always reuse them.
                if (m_Solvers.Count == 0)
                {
                    LoadSolvers();
                }
            }

            // Create a copy of the solution and result vectors so we can use them
            // later on
            Vector internalInput = input.Clone();
            Vector internalResult = result.Clone();

            foreach (IIterativeSolver solver in m_Solvers)
            {
                // If we have been stopped then stop.
                if (m_HasBeenStopped)
                {
                    break;
                }

                // Store a reference to the solver so we can stop it.
                m_CurrentSolver = solver;

                try
                {
                    // Reset the iterator and pass it to the solver
                    m_Iterator.ResetToPrecalculationState();
                    solver.SetIterator(m_Iterator);

                    // Start the solver
                    solver.Solve(matrix, internalInput, internalResult);
                }
                catch (IterativeSolverException)
                {
                    // The solver broke down. 
                    // Log a message about this

                    // Switch to the next preconditioner. 
                    // Reset the solution vector to the previous solution
                    input.CopyTo(internalInput);
                    m_Status = sm_RunningStatus;
                    continue;
                }

                // There was no fatal breakdown so check the status
                if (m_Iterator.Status is CalculationConverged)
                {
                    // We're done
                    break;
                }

                // We're not done
                // Either:
                // - calculation finished without convergence
                if (m_Iterator.Status is CalculationStoppedWithoutConvergence)
                {
                    // Copy the internal result to the result vector and
                    // continue with the calculation.
                    internalInput.CopyTo(input);
                }
                else
                {
                    // - calculation failed --> restart with the original vector
                    // - calculation diverged --> restart with the original vector
                    // - Some unknown status occurred --> To be safe restart.
                    input.CopyTo(internalInput);
                }
            }

            // Inside the loop we already copied the final results (if there are any)
            // So no need to do that again.
            
            // Clean up
            {
                // No longer need the current solver
                m_CurrentSolver = null;

                // Set the final status
                m_Status = m_Iterator.Status;
            }
        }

        private void LoadSolvers()
        {
            if (sm_SolverSetups.Count == 0)
            {
                throw new MissingSolverException();
            }

            foreach (KeyValuePair<double, List<IIterativeSolverSetup>> pair in sm_SolverSetups)
            {
                List<IIterativeSolverSetup> setups = pair.Value;
                foreach (IIterativeSolverSetup setup in setups)
                {
                    m_Solvers.Add(setup.CreateNew());
                }
            }
        }

        /// <summary>
        /// Solves the matrix equation AX = B, where A is the coefficient matrix, B is the
        /// solution matrix and X is the unknown matrix.
        /// </summary>
        /// <param name="matrix">The coefficient matrix, <c>A</c>.</param>
        /// <param name="input">The solution matrix, <c>B</c>.</param>
        /// <returns>The result matrix, <c>X</c>.</returns>
        public Matrix Solve(Matrix matrix, Matrix input)
        {
            if (matrix == null)
            {
                throw new ArgumentNullException("matrix");
            }
            if (input == null)
            {
                throw new ArgumentNullException("input");
            }
            Matrix result = matrix.CreateMatrix(input.Rows, input.Columns);
            Solve(matrix, input, result);
            return result;
        }

        /// <summary>
        /// Solves the matrix equation AX = B, where A is the coefficient matrix, B is the
        /// solution matrix and X is the unknown matrix.
        /// </summary>
        /// <param name="matrix">The coefficient matrix, <c>A</c>.</param>
        /// <param name="input">The solution matrix, <c>B</c>.</param>
        /// <param name="result">The result matrix, <c>X</c></param>
        public void Solve(Matrix matrix, Matrix input, Matrix result)
        {
            if (matrix == null)
            {
                throw new ArgumentNullException("matrix");
            }
            if (input == null)
            {
                throw new ArgumentNullException("input");
            }
            if (result == null)
            {
                throw new ArgumentNullException("result");
            }

            if (matrix.Rows != input.Rows || input.Rows != result.Rows || input.Columns != result.Columns)
            {
                throw new NotConformableException();
            }

            for (int column = 0; column < input.Columns; column++)
            {
                Vector solution = Solve(matrix, input.GetColumn(column));
                foreach (KeyValuePair<int, double> element in solution.GetIndexedEnumerator())
                {
                    result.ValueAt(element.Key, column, element.Value);
                }
            }
        }
    }
}
