﻿/* Copyright 2007-2008 dnAnalytics Project.
 *
 * Contributors to this file:
 * Patrick van der Velde
 * Marcus Cuda
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this 
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * * Neither the name of the dnAnalytics Project nor the names of its contributors
 *   may be used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
using System;
using dnAnalytics.Properties;

namespace dnAnalytics.LinearAlgebra.Decomposition
{
    /// <summary>
    /// Computes the Cholesky factorization of a symmetric, positive definite <see cref="Matrix"/>.
    /// </summary>
    /// <remarks>Cholesky factorization decomposes symmetric, positive definite matrices.
    /// This class does not check whether a matrix is symmetric or not. It only uses the upper
    /// triangle of the matrix to compute the decomposition.</remarks>
    /// <include file='../../../../FSharpExamples/MultiVariateNormal.xml' path='example'/> 
    /// <remarks>The actual decomposition is not done until one of the class'
    /// methods is invoked.</remarks>
    public class Cholesky
    {
        private readonly AbstractCholesky mCholesky;

        /// <summary>
        /// Constructs an Cholesky object for the given matrix.
        /// </summary>
        /// <param name="matrix">The matrix to factor.</param>
        /// <exception cref="ArgumentNullException">If <paramref name="matrix"/> is <b>null</b>.</exception>
        /// <exception cref="MatrixNotSquareException">If <paramref name="matrix"/> is not a square matrix.</exception>
        /// <remarks>The actual decomposition is not done until one of the class'
        /// methods is invoked.</remarks>
        public Cholesky(Matrix matrix)
        {
            if (matrix == null)
            {
                throw new ArgumentNullException("matrix", Resources.NullParameterException);
            }

            if (matrix.Rows != matrix.Columns)
            {
                throw new MatrixNotSquareException(Resources.NotSqurare);
            }
            if (matrix.GetType() == typeof(DenseMatrix))
            {
                mCholesky = new DenseCholesky(matrix);
            }
            else
            {
                mCholesky = new UserCholesky(matrix);
            }
        }


        ///<summary>Return a value indicating whether the matrix is positive definite.</summary>
        ///<returns><b>true</b> if the matrix is positive definite; otherwise, <b>false</b>.</returns>
        public bool IsPositiveDefinite()
        {
            return mCholesky.IsPositiveDefinite();
        }

        ///<summary>Returns the Cholesky factored matrix (lower triangular form).</summary>
        ///<returns>The lower triangular Cholesky factored matrix.</returns>
        ///<exception cref="NotPositiveDefiniteException">If the matrix is not positive definite.</exception>
        public Matrix Factor()
        {
            return mCholesky.Factor();
        }

        ///<summary>Calculates the determinant of the matrix.</summary>
        ///<returns>The determinant of the matrix.</returns>
        ///<exception cref="NotPositiveDefiniteException">If the matrix is not positive definite.</exception>
        public double Determinant()
        {
            return mCholesky.Determinant();
        }

        /// <summary>
        ///  Solves a system of linear equations, <b>AX = B</b>.
        /// </summary>
        /// <param name="input">The right hand side <see cref="Matrix"/>, <b>B</b>.</param>
        /// <returns>The left hand side <see cref="Matrix"/>, <b>X</b>.</returns>
        public Matrix Solve(Matrix input)
        {
            return mCholesky.Solve(input);
        }

        /// <summary>
        ///  Solves a system of linear equations, <b>AX = B</b>.
        /// </summary>
        /// <param name="input">The right hand side <see cref="Matrix"/>, <b>B</b>.</param>
        /// <param name="result">The left hand side <see cref="Matrix"/>, <b>X</b>.</param>
        public void Solve(Matrix input, Matrix result)
        {
            mCholesky.Solve(input, result);
        }

        /// <summary>
        /// Solves a system of linear equations, <b>Ax = b</b>.
        /// </summary>
        /// <param name="input">The right hand side vector, <b>b</b>.</param>
        /// <returns>The left hand side <see cref="Vector"/>, <b>x</b>.</returns>
        public Vector Solve(Vector input)
        {
            return mCholesky.Solve(input);
        }

        /// <summary>
        /// Solves a system of linear equations, <b>Ax = b</b>.
        /// </summary>
        /// <param name="input">The right hand side vector, <b>b</b>.</param>
        /// <param name="result">The left hand side <see cref="Matrix"/>, <b>x</b>.</param>
        public void Solve(Vector input, Vector result)
        {
            mCholesky.Solve(input, result);
        }
    }
}