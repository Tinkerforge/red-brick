﻿namespace dnAnalytics.DebugVisualizers
{
    partial class VectorVisualizerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvVector = new System.Windows.Forms.DataGridView();
            this.gbxGlobalInfo = new System.Windows.Forms.GroupBox();
            this.pgProperies = new System.Windows.Forms.PropertyGrid();
            this.gbxElements = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVector)).BeginInit();
            this.gbxGlobalInfo.SuspendLayout();
            this.gbxElements.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvVector
            // 
            this.dgvVector.AllowUserToAddRows = false;
            this.dgvVector.AllowUserToDeleteRows = false;
            this.dgvVector.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvVector.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvVector.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVector.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvVector.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvVector.Location = new System.Drawing.Point(3, 16);
            this.dgvVector.MultiSelect = false;
            this.dgvVector.Name = "dgvVector";
            this.dgvVector.ReadOnly = true;
            this.dgvVector.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToDisplayedHeaders;
            this.dgvVector.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvVector.RowTemplate.ReadOnly = true;
            this.dgvVector.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvVector.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvVector.ShowCellErrors = false;
            this.dgvVector.ShowCellToolTips = false;
            this.dgvVector.ShowEditingIcon = false;
            this.dgvVector.ShowRowErrors = false;
            this.dgvVector.Size = new System.Drawing.Size(190, 403);
            this.dgvVector.TabIndex = 0;
            this.dgvVector.VirtualMode = true;
            this.dgvVector.CellValueNeeded += new System.Windows.Forms.DataGridViewCellValueEventHandler(this.dgvMatrix_CellValueNeeded);
            this.dgvVector.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dgvVector_RowsAdded);
            this.dgvVector.ColumnAdded += new System.Windows.Forms.DataGridViewColumnEventHandler(this.dgvVector_ColumnAdded);
            // 
            // gbxGlobalInfo
            // 
            this.gbxGlobalInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.gbxGlobalInfo.Controls.Add(this.pgProperies);
            this.gbxGlobalInfo.Location = new System.Drawing.Point(12, 12);
            this.gbxGlobalInfo.Name = "gbxGlobalInfo";
            this.gbxGlobalInfo.Size = new System.Drawing.Size(406, 422);
            this.gbxGlobalInfo.TabIndex = 0;
            this.gbxGlobalInfo.TabStop = false;
            this.gbxGlobalInfo.Text = "Global information:";
            // 
            // pgProperies
            // 
            this.pgProperies.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pgProperies.Location = new System.Drawing.Point(3, 16);
            this.pgProperies.Name = "pgProperies";
            this.pgProperies.Size = new System.Drawing.Size(400, 403);
            this.pgProperies.TabIndex = 0;
            this.pgProperies.ToolbarVisible = false;
            // 
            // gbxElements
            // 
            this.gbxElements.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gbxElements.Controls.Add(this.dgvVector);
            this.gbxElements.Location = new System.Drawing.Point(424, 12);
            this.gbxElements.Name = "gbxElements";
            this.gbxElements.Size = new System.Drawing.Size(196, 422);
            this.gbxElements.TabIndex = 2;
            this.gbxElements.TabStop = false;
            this.gbxElements.Text = "Elements:";
            // 
            // VectorVisualizerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 446);
            this.Controls.Add(this.gbxElements);
            this.Controls.Add(this.gbxGlobalInfo);
            this.MinimumSize = new System.Drawing.Size(640, 480);
            this.Name = "VectorVisualizerForm";
            this.Text = "Vector view";
            this.Load += new System.EventHandler(this.MatrixViewForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvVector)).EndInit();
            this.gbxGlobalInfo.ResumeLayout(false);
            this.gbxElements.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvVector;
        private System.Windows.Forms.GroupBox gbxGlobalInfo;
        private System.Windows.Forms.GroupBox gbxElements;
        private System.Windows.Forms.PropertyGrid pgProperies;

    }
}