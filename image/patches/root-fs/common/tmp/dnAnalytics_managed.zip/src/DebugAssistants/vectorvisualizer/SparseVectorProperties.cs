/* Copyright 2007-2008 dnAnalytics Project.
 *
 * Contributors to this file:
 * Patrick van der Velde
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this 
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * * Neither the name of the dnAnalytics Project nor the names of its contributors
 *   may be used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
using System;
using dnAnalytics.LinearAlgebra;
using System.ComponentModel;
using System.Diagnostics;

namespace dnAnalytics.DebugVisualizers
{
    /// <summary>
    /// A <c>VectorProperties</c> class for <c>SparseVector</c> objects.
    /// </summary>
    public sealed class SparseVectorProperties : VectorProperties
    {
        /// <summary>
        /// The vector for which the properties are stored.
        /// </summary>
        private SparseVector m_Vector;
        
        /// <summary>
        /// Creates a new instance of the <c>SparseVectorProperties</c> class with the specified
        /// <paramref name="vector"/>.
        /// </summary>
        /// <param name="vector">The vector for which the properties are stored.</param>
        /// <exception cref="ArgumentNullException">
        ///     Thrown if <paramref name="vector"/> is <c>null</c>.
        /// </exception>
        public SparseVectorProperties(SparseVector vector)
        {
            if (vector == null)
            {
                throw new ArgumentNullException();
            }

            m_Vector = vector;
        }

        /// <summary>
        /// Returns the vector.
        /// </summary>
        protected override Vector Vector
        {
            [DebuggerStepThrough]
            get
            {
                return m_Vector;
            }
        }

        /// <summary>
        /// Returns the number of non-zero elements in the vector.
        /// </summary>
        [Category("Dimensions")]
        [DisplayName("Number of non-zero elements")]
        [Description("The number of non-zero elements in the vector.")]
        public int NonZeros
        {
            [DebuggerStepThrough]
            get
            {
                return m_Vector.NonZeros;
            }
        }

        /// <summary>
        /// Returns the number of zero elements in the vector.
        /// </summary>
        [Category("Dimensions")]
        [DisplayName("Number of zero elements")]
        [Description("The number of zero elements in the vector.")]
        public int Zeros
        {
            [DebuggerStepThrough]
            get
            {
                return Count - NonZeros;
            }
        }
    }
}