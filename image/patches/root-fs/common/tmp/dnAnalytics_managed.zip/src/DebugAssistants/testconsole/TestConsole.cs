﻿/* Copyright 2007-2008 dnAnalytics Project.
 *
 * Contributors to this file:
 * Patrick van der Velde
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this 
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * * Neither the name of the dnAnalytics Project nor the names of its contributors
 *   may be used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

using dnAnalytics.DebugVisualizers;
using dnAnalytics.LinearAlgebra;

namespace DebugTester
{
    class TestConsole
    {
        static void Main(string[] args)
        {
            /*Matrix vector = new DenseMatrix(150, 150);
            for (int i = 0; i < vector.Rows; i++)
            {
                for (int j = 0; j < vector.Columns; j++)
                {
                    vector[i, j] = i + j;
                }
            }*/

            // Create the vector
            SparseMatrix matrix = new SparseMatrix(100);
            // Assemble the vector. We assume we're solving the Poisson equation
            // on a rectangular 10 x 10 grid
            int gridSize = 10;
            // The pattern is:
            // 0 .... 0 -1 0 0 0 0 0 0 0 0 -1 4 -1 0 0 0 0 0 0 0 0 -1 0 0 ... 0
            for (int i = 0; i < matrix.Rows; i++)
            {
                // Insert the first set of -1's
                if (i > (gridSize - 1))
                {
                    matrix[i, i - gridSize] = -1;
                }

                // Insert the second set of -1's
                if (i > 0)
                {
                    matrix[i, i - 1] = -1;
                }

                // Insert the centerline values
                matrix[i, i] = 4;

                // Insert the first trailing set of -1's
                if (i < matrix.Rows - 1)
                {
                    matrix[i, i + 1] = -1;
                }

                // Insert the second trailing set of -1's
                if (i < matrix.Rows - gridSize)
                {
                    matrix[i, i + gridSize] = -1;
                }
            }

            MatrixValueVisualizer.TestShowVisualizer(matrix);

            // Create the vector
            var vector = new SparseVector(100);
            // Assemble the vector. 
            gridSize = 5;
            // The pattern is:
            // 1 0 0 0 0 2 0 0 0 0 3 0 0 0 0 4 ... 
            for (int i = 0; i < vector.Count; i++)
            {
                if (i % gridSize == 0)
                {
                    vector[i] = i + 1;
                }
            }

            VectorVisualizer.TestShowVisualizer(vector);
        }
    }
}
