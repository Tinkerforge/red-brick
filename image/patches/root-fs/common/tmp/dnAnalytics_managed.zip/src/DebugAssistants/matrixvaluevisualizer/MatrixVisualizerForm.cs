﻿using System;
using System.Windows.Forms;
using dnAnalytics.LinearAlgebra;
using dnAnalytics.Math;
using System.Drawing;
using System.Diagnostics;

namespace dnAnalytics.DebugVisualizers
{
    public partial class MatrixVisualizerForm : Form
    {
        /// <summary>
        /// The properties object for the specific matrix that is being visualized.
        /// </summary>
        private MatrixProperties m_Matrix;

        public MatrixVisualizerForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Sets the properties object for the matrix.
        /// </summary>
        public MatrixProperties Matrix
        {
            [DebuggerStepThrough]
            set
            {
                m_Matrix = value;
            }
        }

        private void MatrixViewForm_Load(object sender, EventArgs e)
        {
            // Clear the controls
            pgProperies.SelectedObject = null;

            dgvMatrix.Columns.Clear();
            dgvMatrix.Rows.Clear();

            // Load the data into the controls
            if (m_Matrix != null)
            {
                pgProperies.SelectedObject = m_Matrix;

                // Set the column headers
                dgvMatrix.ColumnCount = m_Matrix.Columns;
                dgvMatrix.RowCount = m_Matrix.Rows;
            }
        }

        // Occurs when we need a new value for formatting.
        private void dgvMatrix_CellValueNeeded(object sender, DataGridViewCellValueEventArgs e)
        {
            if (((e.RowIndex < 0) || (e.RowIndex >= m_Matrix.Rows)) ||
               ((e.ColumnIndex < 0) || (e.ColumnIndex >= m_Matrix.Columns)))
            {
                throw new ArgumentOutOfRangeException("e");
            }

            //dgvMatrix.BeginEdit(false);
            try
            {
                e.Value = m_Matrix.Item(e.RowIndex, e.ColumnIndex);

                // If the value is zero (or within 1 ULP of zero) then we color the cell with a 
                // light gray background color to distinquish it from the other (non-zero) cells.
                if (!Precision.EqualsWithTolerance(m_Matrix.Item(e.RowIndex, e.ColumnIndex), 0, 1))
                {
                    dgvMatrix.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = Color.LightGray;
                    dgvMatrix.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.ForeColor = Color.DarkBlue;
                }
                else
                {
                    dgvMatrix.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.ForeColor = Color.LightGray;
                }
            }
            finally
            {
         //       dgvMatrix.EndEdit();
            }
        }

        private void dgvMatrix_ColumnAdded(object sender, DataGridViewColumnEventArgs e)
        {
            int index = dgvMatrix.Columns.IndexOf(e.Column);
            e.Column.Name = index.ToString();
        }

        private void dgvMatrix_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            for (int i = e.RowIndex; i < e.RowIndex + e.RowCount; i++)
            {
                dgvMatrix.Rows[i].HeaderCell.Value = i.ToString();
            }
        }
    }
}
