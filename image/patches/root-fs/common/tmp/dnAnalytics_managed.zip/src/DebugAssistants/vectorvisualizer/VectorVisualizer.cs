﻿/* Copyright 2007-2008 dnAnalytics Project.
 *
 * Contributors to this file:
 * Patrick van der Velde
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this 
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * * Neither the name of the dnAnalytics Project nor the names of its contributors
 *   may be used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

using dnAnalytics.LinearAlgebra;
using Microsoft.VisualStudio.DebuggerVisualizers;

namespace dnAnalytics.DebugVisualizers
{
    /// <summary>
    /// A visualizer which displays the values of a <see cref="Vector"/> object.
    /// </summary>
    public class VectorVisualizer : DialogDebuggerVisualizer
    {
        protected override void Show(IDialogVisualizerService windowService, IVisualizerObjectProvider objectProvider)
        {
            Vector vector = (Vector)objectProvider.GetObject();

            // See if the vector is a sparse one. If so then display
            // it that way because we'll be able to display it on
            // a special form.
            {
                var sparseVector = vector as SparseVector;
                if (sparseVector != null)
                {
                    DisplaySparseVector(windowService, sparseVector);
                    return;
                }
            }

            // The vector is not sparse so it could be dense
            // Check that and display it as a dense one if we
            // can.
            {
                var denseVector = vector as DenseVector;
                if (denseVector != null)
                {
                    DisplayDenseVector(windowService, denseVector);
                    return;
                }
            }

            // We don't know which type the vector is so we'll just
            // turn it into a dense one and display that.
            {
                DisplayGeneralVector(windowService, vector);
            }
        }

        private void DisplaySparseVector(IDialogVisualizerService windowService, SparseVector vector)
        {
            VectorProperties vectorProperties = new SparseVectorProperties(vector);
            DisplayVector(windowService, vectorProperties);
        }

        private void DisplayDenseVector(IDialogVisualizerService windowService, DenseVector vector)
        {
            VectorProperties vectorProperties = new DenseVectorProperties(vector);
            DisplayVector(windowService, vectorProperties);
        }

        private void DisplayGeneralVector(IDialogVisualizerService windowService, Vector vector)
        {
            DenseVector denseVector = new DenseVector(vector);
            DisplayDenseVector(windowService, denseVector);
        }

        private void DisplayVector(IDialogVisualizerService windowService, VectorProperties vector)
        {
            using (var displayForm = new VectorVisualizerForm())
            {
                displayForm.Vector = vector;
                windowService.ShowDialog(displayForm);
            }
        }

        /// <summary>
        /// Tests the visualizer by hosting it outside of the debugger.
        /// </summary>
        /// <param name="objectToVisualize">The object to display in the visualizer.</param>
        public static void TestShowVisualizer(object objectToVisualize)
        {
            VisualizerDevelopmentHost visualizerHost = new VisualizerDevelopmentHost(objectToVisualize, typeof(VectorVisualizer));
            visualizerHost.ShowVisualizer();
        }
    }
}
