﻿using System;
using System.Windows.Forms;
using dnAnalytics.LinearAlgebra;
using dnAnalytics.Math;
using System.Drawing;

namespace dnAnalytics.DebugVisualizers
{
    public partial class VectorVisualizerForm : Form
    {
        private VectorProperties m_Vector;

        public VectorVisualizerForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Sets the properties object for the vector.
        /// </summary>
        public VectorProperties Vector
        {
            set
            {
                m_Vector = value;
            }
        }

        private void MatrixViewForm_Load(object sender, EventArgs e)
        {
            // Clear the controls
            pgProperies.SelectedObject = null;

            dgvVector.Columns.Clear();
            dgvVector.Rows.Clear();

            // Set the vector
            if (m_Vector != null)
            {
                pgProperies.SelectedObject = m_Vector;

                // Set the column headers
                dgvVector.ColumnCount = 1;
                dgvVector.RowCount = m_Vector.Count;
            }
        }

        // Occurs when we need a new value for formatting.
        private void dgvMatrix_CellValueNeeded(object sender, DataGridViewCellValueEventArgs e)
        {
            if (((e.RowIndex < 0) || (e.RowIndex >= m_Vector.Count)) ||
               ((e.ColumnIndex != 0)))
            {
                throw new ArgumentOutOfRangeException("e");
            }

           
            // dgvVector.BeginEdit(false);
            try
            {
                e.Value = m_Vector.Item(e.RowIndex);
                if (!Precision.EqualsWithTolerance(m_Vector.Item(e.RowIndex), 0, 1))
                {
                    dgvVector.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = Color.LightGray;
                    dgvVector.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.ForeColor = Color.DarkBlue;
                }
                else
                {
                    dgvVector.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.ForeColor = Color.LightGray;
                }
            }
            finally
            {
           //     dgvVector.EndEdit();
            }
        }

        private void dgvVector_ColumnAdded(object sender, DataGridViewColumnEventArgs e)
        {
            int index = dgvVector.Columns.IndexOf(e.Column);
            e.Column.Name = index.ToString();
        }

        private void dgvVector_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            for (int i = e.RowIndex; i < e.RowIndex + e.RowCount; i++)
            {
                dgvVector.Rows[i].HeaderCell.Value = i.ToString();
            }
        }
    }
}
