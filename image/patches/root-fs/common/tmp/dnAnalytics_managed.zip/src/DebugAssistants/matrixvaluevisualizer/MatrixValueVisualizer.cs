﻿/* Copyright 2007-2008 dnAnalytics Project.
 *
 * Contributors to this file:
 * Patrick van der Velde
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this 
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * * Neither the name of the dnAnalytics Project nor the names of its contributors
 *   may be used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

using dnAnalytics.LinearAlgebra;
using Microsoft.VisualStudio.DebuggerVisualizers;

namespace dnAnalytics.DebugVisualizers
{
    /// <summary>
    /// A visualizer which displays the values of a <see cref="Matrix"/> object.
    /// </summary>
    public class MatrixValueVisualizer : DialogDebuggerVisualizer
    {
        protected override void Show(IDialogVisualizerService windowService, IVisualizerObjectProvider objectProvider)
        {
            Matrix matrix = (Matrix)objectProvider.GetObject();

            // See if the matrix is a sparse one. If so then display
            // it that way because we'll be able to display it on
            // a special form.
            {
                SparseMatrix sparseMatrix = matrix as SparseMatrix;
                if (sparseMatrix != null)
                {
                    DisplaySparseMatrix(windowService, sparseMatrix);
                    return;
                }
            }

            // The matrix is not sparse so it could be dense
            // Check that and display it as a dense one if we
            // can.
            {
                DenseMatrix denseMatrix = matrix as DenseMatrix;
                if (denseMatrix != null)
                {
                    DisplayDenseMatrix(windowService, denseMatrix);
                    return;
                }
            }

            // We don't know which type the matrix is so we'll just
            // turn it into a dense one and display that.
            {
                DisplayGeneralMatrix(windowService, matrix);
            }
        }

        private void DisplaySparseMatrix(IDialogVisualizerService windowService, SparseMatrix matrix)
        {
            MatrixProperties matrixProperties = new SparseMatrixProperties(matrix);
            DisplayMatrix(windowService, matrixProperties);
        }

        private void DisplayDenseMatrix(IDialogVisualizerService windowService, DenseMatrix matrix)
        {
            MatrixProperties matrixProperties = new DenseMatrixProperties(matrix);
            DisplayMatrix(windowService, matrixProperties);
        }

        private void DisplayGeneralMatrix(IDialogVisualizerService windowService, Matrix matrix)
        {
            DenseMatrix denseMatrix = new DenseMatrix(matrix);
            DisplayDenseMatrix(windowService, denseMatrix);
        }

        private void DisplayMatrix(IDialogVisualizerService windowService, MatrixProperties matrix)
        {
            using (var displayForm = new MatrixVisualizerForm())
            {
                displayForm.Matrix = matrix;
                windowService.ShowDialog(displayForm);
            }
        }

        /// <summary>
        /// Tests the visualizer by hosting it outside of the debugger.
        /// </summary>
        /// <param name="objectToVisualize">The object to display in the visualizer.</param>
        public static void TestShowVisualizer(object objectToVisualize)
        {
            VisualizerDevelopmentHost visualizerHost = new VisualizerDevelopmentHost(objectToVisualize, typeof(MatrixValueVisualizer));
            visualizerHost.ShowVisualizer();
        }
    }
}
